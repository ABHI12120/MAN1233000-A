<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>About Us - Cosplay Costume Store</title>
<link rel="stylesheet" href="styles/styles.css">
</head>
<body>
<header>
  <div class="container top">
    <div class="brand">
      <div class="logo"><a href="index.php">CS</a></div>
      <div>
        <div style="font-weight:700">Cosplay Costume Store</div>
      </div>
    </div>

    <nav class="navbar">
      <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="logout.php">Logout</a></li>
        <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
      </ul>
    </nav>
  </div>
</header>

<div class="content">
  <h1>About Us</h1>

  <p>Welcome to <strong>Cosplay Costume Store</strong>! We are passionate about cosplay and committed to bringing you the best costumes, wigs, and accessories from your favorite anime, manga, movies, and games. Whether you’re a beginner or a pro, our store is your one-stop destination for cosplay needs.</p>

  <div class="highlight">
    <h2>Our Mission</h2>
    <p>To empower fans around the world by providing high-quality, accurate, and affordable cosplay costumes that help bring their favorite characters to life.</p>
  </div>

  <div class="highlight">
    <h2>Our Vision</h2>
    <p>To become the most trusted cosplay costume store worldwide, uniting communities through creativity, self-expression, and the love of fandoms.</p>
  </div>

  <div class="highlight">
    <h2>Why Choose Us?</h2>
    <ul>
      <li>Huge variety of costumes from anime, manga, comics, movies, and games.</li>
      <li>High-quality fabrics and craftsmanship.</li>
      <li>Custom sizing options available.</li>
      <li>Fast and reliable worldwide shipping.</li>
      <li>Dedicated to making cosplay accessible for everyone.</li>
    </ul>
  </div>
</div>

<footer>
  <p>© Cosplay Costume Store | <a href="index.php">Home</a> | <a href="about.php">About</a> | <a href="contact.php">Contact</a></p>
</footer>
</body>
</html>
