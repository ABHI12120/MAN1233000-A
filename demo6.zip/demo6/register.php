<?php
session_start();
include 'db.php';
$msg = '';

if($_SERVER['REQUEST_METHOD']=='POST'){
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $state = mysqli_real_escape_string($conn, $_POST['state']);
    $pincode = mysqli_real_escape_string($conn, $_POST['pincode']);

    $res = mysqli_query($conn, "INSERT INTO users (username, email, password, phone, address, state, pincode) 
                                VALUES ('$username', '$email', '$password', '$phone', '$address', '$state', '$pincode')");
    if($res){ 
        $msg = "Registration successful! <a href='login.php'>Login here</a>"; 
    } else { 
        $msg = "Error: ".mysqli_error($conn); 
    }
}
?>

<!doctype html>
<html>
<head>
<title>Register - Cosplay Costume Store</title>
<link rel="stylesheet" href="styles/styles.css">
</head>
<body>
<div class="in-box">
<h1>Register</h1>
<?php if($msg) echo "<p style='color:green;'>$msg</p>"; ?>
<form method="post">
    <label>Username:</label><br>
    <input type="text" name="username" placeholder="Username" required><br>

    <label>Email:</label><br>
    <input type="email" name="email" placeholder="Email" required><br>

    <label>Password:</label><br>
    <input type="password" name="password" placeholder="Password" required><br>

    <label>Phone:</label><br>
    <input type="text" name="phone" placeholder="Phone" required pattern="[0-9]{10}"><br>

    <label>Address:</label><br>
    <textarea name="address" rows="3" placeholder="Address" required></textarea><br>

    <label>State:</label><br>
    <input type="text" name="state" placeholder="State" required><br>

    <label>Pincode:</label><br>
    <input type="number" name="pincode" placeholder="Pincode" required><br>

    <div class="custom-checkbox">
    <input type="checkbox" id="terms" name="terms">
    <label for="terms">I agree to the Terms and Conditions</label>
    </div>
    	
    <script src="js/main.js"></script>

    <button type="submit">Register</button>
</form>
<p>Already have an account? <a href="login.php">Login here</a></p>
<p><a href="index.php">← Back to Store</a></p>
</div>
</body>
</html>