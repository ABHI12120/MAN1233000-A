<?php
session_start();
include 'db.php';

// Remove product from cart
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['remove'])) {
    $id = intval($_POST['remove']);
    if (isset($_SESSION['cart'][$id])) {
        unset($_SESSION['cart'][$id]);
    }
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

// Checkout (COD)
$msg = '';
if(isset($_POST['checkout'])){
    if(!isset($_SESSION['user_id'])){
        header("Location: login.php?redirect=cart.php");
        exit;
    }

    if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])){
        $msg = "Cart is empty!";
    } else {
        $user_id = $_SESSION['user_id'];
        foreach($_SESSION['cart'] as $pid => $qty){
            mysqli_query($conn, "INSERT INTO orders (user_id, product_id, quantity) 
                                VALUES ($user_id, $pid, $qty)");
        }
        unset($_SESSION['cart']);
        $msg = "Order placed successfully!";
    }
}

// Fetch cart items
$cart_products = [];
$total = 0;
if (!empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id IN ($ids)");
    while ($row = mysqli_fetch_assoc($res)) {
        $row['qty'] = $_SESSION['cart'][$row['id']];
        $row['subtotal'] = $row['price'] * $row['qty'];
        $total += $row['subtotal'];
        $cart_products[] = $row;
    }
}
?>
<!doctype html>
<html>
<head>
<title>Cart - Cosplay Costume Store</title>
<link rel="stylesheet" href="styles/styles.css">
<style>
p { text-align:center; }
button.remove { background:#e74c3c; color:#fff; border:none; padding:3px 6px; cursor:pointer; border-radius:4px; }
button.remove:hover { background:#c0392b; }
</style>
</head>
<body>
<header>
<div class="container top">
  <div class="brand">
    <div class="logo"><a href="index.php">CS</a></div>
    <div>
      <div style="font-weight:700">Cosplay Costume Store</div>
      </div>
  </div>
  <nav class="navbar">
    <ul>
      <li><a href="login.php">Login</a></li>
      <li><a href="logout.php">Logout</a></li>
      <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
    </ul>
  </nav>
</div>
</header>

<h1>Your Cart</h1>
<?php if (!empty($cart_products)): ?>
<table>
<tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th><th>Action</th></tr>
<?php foreach($cart_products as $p): ?>
<tr>
<td><?php echo $p['name']; ?></td>
<td><?php echo $p['qty']; ?></td>
<td>₹<?php echo $p['price']; ?></td>
<td>₹<?php echo $p['subtotal']; ?></td>
<td>
    <form method="post" style="display:inline;">
        <button type="submit" name="remove" value="<?php echo $p['id']; ?>" class="remove">Remove</button>
    </form>
</td>
</tr>
<?php endforeach; ?>
<tr><td colspan="3"><strong>Total</strong></td><td>₹<?php echo $total; ?></td><td></td></tr>
</table>

<form method="post">
    <button type="submit" name="checkout" class="butn">Checkout (COD)</button>
</form>

<?php else: ?>
<?php endif; ?>

<?php if($msg) echo "<p class='msg'>$msg</p>"; ?>
<footer>
<p>© Cosplay Costume Store | <a href="index.php">Home</a> | <a href="about.php">About us</a> | <a href="contact.php">Contact</a></p>
</footer>
</body>
</html>