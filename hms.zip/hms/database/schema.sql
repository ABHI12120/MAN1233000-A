-- Hospital Management System Database Schema
-- This SQL script creates the complete database structure for the HMS

-- Create database
CREATE DATABASE IF NOT EXISTS hospital_management_system;
USE hospital_management_system;

-- Users table for authentication
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('admin', 'doctor', 'nurse', 'receptionist') NOT NULL DEFAULT 'receptionist',
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Departments table
CREATE TABLE departments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT,
    head_doctor_id INT,
    location VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (head_doctor_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Doctors table (extends users)
CREATE TABLE doctors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    employee_id VARCHAR(20) UNIQUE NOT NULL,
    specialization VARCHAR(100) NOT NULL,
    department_id INT NOT NULL,
    license_number VARCHAR(50) UNIQUE NOT NULL,
    experience_years INT DEFAULT 0,
    consultation_fee DECIMAL(10,2) DEFAULT 0.00,
    working_hours_start TIME DEFAULT '09:00:00',
    working_hours_end TIME DEFAULT '17:00:00',
    is_available BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE RESTRICT
);

-- Patients table
CREATE TABLE patients (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id VARCHAR(20) UNIQUE NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender ENUM('Male', 'Female', 'Other') NOT NULL,
    phone VARCHAR(20) NOT NULL,
    email VARCHAR(100),
    address TEXT,
    emergency_contact_name VARCHAR(100),
    emergency_contact_phone VARCHAR(20),
    blood_type ENUM('A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'),
    allergies TEXT,
    medical_history TEXT,
    insurance_provider VARCHAR(100),
    insurance_number VARCHAR(50),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Appointments table
CREATE TABLE appointments (
    id INT PRIMARY KEY AUTO_INCREMENT,
    appointment_id VARCHAR(20) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_date DATE NOT NULL,
    appointment_time TIME NOT NULL,
    duration_minutes INT DEFAULT 30,
    reason TEXT NOT NULL,
    status ENUM('scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show') DEFAULT 'scheduled',
    notes TEXT,
    diagnosis TEXT,
    prescription TEXT,
    follow_up_date DATE,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Medical records table
CREATE TABLE medical_records (
    id INT PRIMARY KEY AUTO_INCREMENT,
    patient_id INT NOT NULL,
    doctor_id INT NOT NULL,
    appointment_id INT,
    record_type ENUM('consultation', 'diagnosis', 'treatment', 'prescription', 'lab_result', 'imaging') NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    diagnosis TEXT,
    treatment TEXT,
    prescription TEXT,
    vital_signs JSON,
    lab_results JSON,
    attachments JSON,
    is_confidential BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (doctor_id) REFERENCES doctors(id) ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
);

-- Rooms table
CREATE TABLE rooms (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_number VARCHAR(20) UNIQUE NOT NULL,
    room_type ENUM('consultation', 'examination', 'surgery', 'emergency', 'ward', 'icu') NOT NULL,
    department_id INT,
    floor_number INT,
    capacity INT DEFAULT 1,
    equipment JSON,
    is_available BOOLEAN DEFAULT TRUE,
    hourly_rate DECIMAL(10,2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
);

-- Room bookings table
CREATE TABLE room_bookings (
    id INT PRIMARY KEY AUTO_INCREMENT,
    room_id INT NOT NULL,
    appointment_id INT,
    booking_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    purpose VARCHAR(200),
    status ENUM('booked', 'in_use', 'completed', 'cancelled') DEFAULT 'booked',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE
);

-- Billing table
CREATE TABLE billing (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bill_number VARCHAR(20) UNIQUE NOT NULL,
    patient_id INT NOT NULL,
    appointment_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    paid_amount DECIMAL(10,2) DEFAULT 0.00,
    balance_amount DECIMAL(10,2) GENERATED ALWAYS AS (total_amount - paid_amount) STORED,
    payment_status ENUM('pending', 'partial', 'paid', 'overdue') DEFAULT 'pending',
    due_date DATE,
    payment_method ENUM('cash', 'card', 'insurance', 'bank_transfer') DEFAULT 'cash',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
    FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE SET NULL
);

-- Billing items table
CREATE TABLE billing_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    bill_id INT NOT NULL,
    item_type ENUM('consultation', 'medication', 'procedure', 'room_charge', 'lab_test', 'imaging') NOT NULL,
    item_name VARCHAR(200) NOT NULL,
    description TEXT,
    quantity INT DEFAULT 1,
    unit_price DECIMAL(10,2) NOT NULL,
    total_price DECIMAL(10,2) GENERATED ALWAYS AS (quantity * unit_price) STORED,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES billing(id) ON DELETE CASCADE
);

-- Inventory table
CREATE TABLE inventory (
    id INT PRIMARY KEY AUTO_INCREMENT,
    item_name VARCHAR(200) NOT NULL,
    item_type ENUM('medication', 'equipment', 'supply', 'consumable') NOT NULL,
    category VARCHAR(100),
    description TEXT,
    sku VARCHAR(50) UNIQUE,
    current_stock INT DEFAULT 0,
    minimum_stock INT DEFAULT 0,
    maximum_stock INT DEFAULT 1000,
    unit_price DECIMAL(10,2) DEFAULT 0.00,
    supplier VARCHAR(200),
    expiry_date DATE,
    location VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Inventory transactions table
CREATE TABLE inventory_transactions (
    id INT PRIMARY KEY AUTO_INCREMENT,
    inventory_id INT NOT NULL,
    transaction_type ENUM('in', 'out', 'adjustment', 'expired', 'damaged') NOT NULL,
    quantity INT NOT NULL,
    reason VARCHAR(200),
    reference_id INT,
    reference_type ENUM('purchase', 'prescription', 'appointment', 'adjustment') DEFAULT 'adjustment',
    performed_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (inventory_id) REFERENCES inventory(id) ON DELETE CASCADE,
    FOREIGN KEY (performed_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Notifications table
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('info', 'warning', 'error', 'success') DEFAULT 'info',
    is_read BOOLEAN DEFAULT FALSE,
    related_id INT,
    related_type ENUM('appointment', 'patient', 'doctor', 'billing', 'inventory') DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Audit log table
CREATE TABLE audit_log (
    id INT PRIMARY KEY AUTO_INCREMENT,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    old_values JSON,
    new_values JSON,
    user_id INT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);

-- Create indexes for better performance
CREATE INDEX idx_patients_patient_id ON patients(patient_id);
CREATE INDEX idx_patients_phone ON patients(phone);
CREATE INDEX idx_patients_email ON patients(email);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
CREATE INDEX idx_appointments_patient ON appointments(patient_id);
CREATE INDEX idx_appointments_doctor ON appointments(doctor_id);
CREATE INDEX idx_appointments_status ON appointments(status);
CREATE INDEX idx_doctors_employee_id ON doctors(employee_id);
CREATE INDEX idx_doctors_department ON doctors(department_id);
CREATE INDEX idx_medical_records_patient ON medical_records(patient_id);
CREATE INDEX idx_billing_patient ON billing(patient_id);
CREATE INDEX idx_billing_status ON billing(payment_status);
CREATE INDEX idx_inventory_sku ON inventory(sku);
CREATE INDEX idx_inventory_stock ON inventory(current_stock);
CREATE INDEX idx_notifications_user ON notifications(user_id);
CREATE INDEX idx_notifications_read ON notifications(is_read);

-- Create views for common queries
CREATE VIEW patient_summary AS
SELECT 
    p.id,
    p.patient_id,
    CONCAT(p.first_name, ' ', p.last_name) AS full_name,
    p.date_of_birth,
    TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) AS age,
    p.gender,
    p.phone,
    p.email,
    COUNT(a.id) AS total_appointments,
    MAX(a.appointment_date) AS last_appointment,
    p.created_at
FROM patients p
LEFT JOIN appointments a ON p.id = a.patient_id
WHERE p.is_active = TRUE
GROUP BY p.id;

CREATE VIEW doctor_schedule AS
SELECT 
    d.id,
    CONCAT(u.first_name, ' ', u.last_name) AS doctor_name,
    d.specialization,
    dept.name AS department,
    d.working_hours_start,
    d.working_hours_end,
    COUNT(a.id) AS today_appointments,
    d.is_available
FROM doctors d
JOIN users u ON d.user_id = u.id
JOIN departments dept ON d.department_id = dept.id
LEFT JOIN appointments a ON d.id = a.doctor_id AND a.appointment_date = CURDATE()
WHERE u.is_active = TRUE
GROUP BY d.id;

CREATE VIEW appointment_details AS
SELECT 
    a.id,
    a.appointment_id,
    CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
    CONCAT(u.first_name, ' ', u.last_name) AS doctor_name,
    d.specialization,
    dept.name AS department,
    a.appointment_date,
    a.appointment_time,
    a.reason,
    a.status,
    a.created_at
FROM appointments a
JOIN patients p ON a.patient_id = p.id
JOIN doctors d ON a.doctor_id = d.id
JOIN users u ON d.user_id = u.id
JOIN departments dept ON d.department_id = dept.id;

-- Insert sample data
INSERT INTO users (username, email, password_hash, role, first_name, last_name, phone) VALUES
('admin', 'admin@hospital.com', '$2b$10$example_hash', 'admin', 'System', 'Administrator', '+1-555-0001'),
('dr.wilson', 'r.wilson@hospital.com', '$2b$10$example_hash', 'doctor', 'Robert', 'Wilson', '+1-555-0201'),
('dr.anderson', 'l.anderson@hospital.com', '$2b$10$example_hash', 'doctor', 'Lisa', 'Anderson', '+1-555-0202'),
('dr.taylor', 'j.taylor@hospital.com', '$2b$10$example_hash', 'doctor', 'James', 'Taylor', '+1-555-0203'),
('dr.garcia', 'm.garcia@hospital.com', '$2b$10$example_hash', 'doctor', 'Maria', 'Garcia', '+1-555-0204');

INSERT INTO departments (name, description, location, phone, email) VALUES
('Cardiology', 'Heart and cardiovascular system care', 'Floor 2, Wing A', '+1-555-1001', 'cardiology@hospital.com'),
('Neurology', 'Brain and nervous system disorders', 'Floor 3, Wing A', '+1-555-1002', 'neurology@hospital.com'),
('Orthopedics', 'Bone, joint, and muscle care', 'Floor 2, Wing B', '+1-555-1003', 'orthopedics@hospital.com'),
('Pediatrics', 'Medical care for infants, children, and adolescents', 'Floor 1, Wing C', '+1-555-1004', 'pediatrics@hospital.com'),
('Emergency', 'Emergency medical care and trauma', 'Ground Floor', '+1-555-1005', 'emergency@hospital.com'),
('Surgery', 'Surgical procedures and operations', 'Floor 4, Wing A', '+1-555-1006', 'surgery@hospital.com');

INSERT INTO doctors (user_id, employee_id, specialization, department_id, license_number, experience_years, consultation_fee) VALUES
(2, 'DOC001', 'Cardiologist', 1, 'LIC001', 15, 150.00),
(3, 'DOC002', 'Neurologist', 2, 'LIC002', 12, 140.00),
(4, 'DOC003', 'Orthopedic Surgeon', 3, 'LIC003', 20, 200.00),
(5, 'DOC004', 'Pediatrician', 4, 'LIC004', 8, 120.00);

INSERT INTO patients (patient_id, first_name, last_name, date_of_birth, gender, phone, email, address) VALUES
('PAT001', 'John', 'Smith', '1979-03-15', 'Male', '+1-555-0123', 'john.smith@email.com', '123 Main St, New York, NY 10001'),
('PAT002', 'Sarah', 'Johnson', '1992-07-22', 'Female', '+1-555-0124', 'sarah.johnson@email.com', '456 Oak Ave, Los Angeles, CA 90210'),
('PAT003', 'Michael', 'Brown', '1996-11-08', 'Male', '+1-555-0125', 'michael.brown@email.com', '789 Pine St, Chicago, IL 60601'),
('PAT004', 'Emily', 'Davis', '1989-05-14', 'Female', '+1-555-0126', 'emily.davis@email.com', '321 Elm St, Houston, TX 77001');

INSERT INTO appointments (appointment_id, patient_id, doctor_id, appointment_date, appointment_time, reason, status) VALUES
('APT001', 1, 1, '2024-01-15', '10:00:00', 'Regular checkup', 'scheduled'),
('APT002', 2, 2, '2024-01-16', '14:30:00', 'Headache consultation', 'scheduled'),
('APT003', 3, 3, '2024-01-14', '09:00:00', 'Knee pain', 'completed');

-- Create stored procedures for common operations
DELIMITER //

CREATE PROCEDURE GetPatientAppointments(IN patient_id INT)
BEGIN
    SELECT 
        a.appointment_id,
        CONCAT(u.first_name, ' ', u.last_name) AS doctor_name,
        d.specialization,
        a.appointment_date,
        a.appointment_time,
        a.reason,
        a.status
    FROM appointments a
    JOIN doctors d ON a.doctor_id = d.id
    JOIN users u ON d.user_id = u.id
    WHERE a.patient_id = patient_id
    ORDER BY a.appointment_date DESC, a.appointment_time DESC;
END //

CREATE PROCEDURE GetDoctorSchedule(IN doctor_id INT, IN schedule_date DATE)
BEGIN
    SELECT 
        a.appointment_id,
        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
        a.appointment_time,
        a.duration_minutes,
        a.reason,
        a.status
    FROM appointments a
    JOIN patients p ON a.patient_id = p.id
    WHERE a.doctor_id = doctor_id 
    AND a.appointment_date = schedule_date
    ORDER BY a.appointment_time;
END //

CREATE PROCEDURE GetDepartmentStats(IN dept_id INT)
BEGIN
    SELECT 
        d.name AS department_name,
        COUNT(DISTINCT doc.id) AS total_doctors,
        COUNT(DISTINCT a.patient_id) AS unique_patients,
        COUNT(a.id) AS total_appointments,
        COUNT(CASE WHEN a.appointment_date = CURDATE() THEN 1 END) AS today_appointments
    FROM departments d
    LEFT JOIN doctors doc ON d.id = doc.department_id
    LEFT JOIN appointments a ON doc.id = a.doctor_id
    WHERE d.id = dept_id
    GROUP BY d.id, d.name;
END //

DELIMITER ;

-- Create triggers for audit logging
DELIMITER //

CREATE TRIGGER audit_patients_insert
    AFTER INSERT ON patients
    FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, new_values, created_at)
    VALUES ('patients', NEW.id, 'INSERT', JSON_OBJECT(
        'patient_id', NEW.patient_id,
        'first_name', NEW.first_name,
        'last_name', NEW.last_name,
        'phone', NEW.phone,
        'email', NEW.email
    ), NOW());
END //

CREATE TRIGGER audit_patients_update
    AFTER UPDATE ON patients
    FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, old_values, new_values, created_at)
    VALUES ('patients', NEW.id, 'UPDATE', 
        JSON_OBJECT(
            'patient_id', OLD.patient_id,
            'first_name', OLD.first_name,
            'last_name', OLD.last_name,
            'phone', OLD.phone,
            'email', OLD.email
        ),
        JSON_OBJECT(
            'patient_id', NEW.patient_id,
            'first_name', NEW.first_name,
            'last_name', NEW.last_name,
            'phone', NEW.phone,
            'email', NEW.email
        ), NOW());
END //

CREATE TRIGGER audit_appointments_insert
    AFTER INSERT ON appointments
    FOR EACH ROW
BEGIN
    INSERT INTO audit_log (table_name, record_id, action, new_values, created_at)
    VALUES ('appointments', NEW.id, 'INSERT', JSON_OBJECT(
        'appointment_id', NEW.appointment_id,
        'patient_id', NEW.patient_id,
        'doctor_id', NEW.doctor_id,
        'appointment_date', NEW.appointment_date,
        'appointment_time', NEW.appointment_time,
        'status', NEW.status
    ), NOW());
END //

DELIMITER ;

-- Grant permissions (adjust as needed for your environment)
-- CREATE USER 'hms_user'@'localhost' IDENTIFIED BY 'secure_password';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON hospital_management_system.* TO 'hms_user'@'localhost';
-- FLUSH PRIVILEGES;
