# Hospital Management System (HMS)

A comprehensive web-based Hospital Management System built with HTML, CSS, JavaScript, and SQL database backend. This system provides complete management of patients, doctors, appointments, departments, and medical records.

## Features

### 🏥 Core Modules
- **Patient Management**: Complete patient registration, profile management, and medical history tracking
- **Doctor Management**: Doctor profiles, specializations, schedules, and availability management
- **Appointment Scheduling**: Book, reschedule, and manage patient appointments
- **Department Management**: Organize hospital departments and staff assignments
- **Dashboard Analytics**: Real-time statistics and visual reports
- **Medical Records**: Comprehensive patient medical history and treatment records

### 📊 Dashboard Features
- Real-time statistics (total patients, doctors, appointments, departments)
- Recent appointments overview
- Quick action buttons for common tasks
- Visual charts and analytics using Chart.js

### 🔍 Advanced Functionality
- **Search & Filter**: Advanced search across all modules
- **Responsive Design**: Mobile-friendly interface
- **Data Validation**: Client and server-side validation
- **Audit Logging**: Complete activity tracking
- **Export/Import**: Data backup and restore capabilities

## Technology Stack

### Frontend
- **HTML5**: Semantic markup and structure
- **CSS3**: Modern styling with Flexbox and Grid
- **JavaScript (ES6+)**: Interactive functionality and API integration
- **Chart.js**: Data visualization and analytics
- **Font Awesome**: Icons and visual elements

### Backend
- **PHP**: Server-side API endpoints
- **MySQL**: Relational database management
- **PDO**: Secure database interactions
- **JWT**: Authentication and authorization

### Database
- **MySQL 8.0+**: Primary database
- **Normalized Schema**: Optimized for performance and data integrity
- **Stored Procedures**: Complex business logic
- **Triggers**: Automated audit logging
- **Views**: Simplified data access

## Installation & Setup

### Prerequisites
- Web server (Apache/Nginx)
- PHP 7.4 or higher
- MySQL 8.0 or higher
- Modern web browser

### Step 1: Clone/Download the Project
```bash
git clone <repository-url>
# or download and extract the ZIP file
```

### Step 2: Database Setup
1. Create a MySQL database:
```sql
CREATE DATABASE hospital_management_system;
```

2. Import the database schema:
```bash
mysql -u root -p hospital_management_system < database/schema.sql
```

3. Update database credentials in `api/config.php`:
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'hospital_management_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
```

### Step 3: Web Server Configuration
1. Place the project files in your web server directory:
   - **XAMPP/WAMP**: `htdocs/hms/`
   - **Apache**: `/var/www/html/hms/`
   - **Nginx**: `/usr/share/nginx/html/hms/`

2. Ensure PHP extensions are enabled:
   - PDO
   - PDO_MySQL
   - JSON
   - OpenSSL (for JWT)

### Step 4: File Permissions
```bash
chmod 755 -R /path/to/hms/
chmod 644 /path/to/hms/api/config.php
```

### Step 5: Access the Application
Open your web browser and navigate to:
```
http://localhost/hms/
```

## Project Structure

```
hms/
├── index.html              # Main application file
├── css/
│   └── style.css          # Application styles
├── js/
│   ├── database.js        # Database simulation (localStorage)
│   └── app.js            # Main application logic
├── api/
│   ├── config.php        # Database configuration
│   ├── patients.php      # Patient API endpoints
│   ├── doctors.php       # Doctor API endpoints
│   └── appointments.php  # Appointment API endpoints
├── database/
│   └── schema.sql        # Database schema and sample data
└── README.md            # This file
```

## API Endpoints

### Patients API (`/api/patients.php`)
- `GET /api/patients` - Get all patients (with pagination and search)
- `GET /api/patients/{id}` - Get specific patient
- `POST /api/patients` - Create new patient
- `PUT /api/patients/{id}` - Update patient
- `DELETE /api/patients/{id}` - Delete patient

### Doctors API (`/api/doctors.php`)
- `GET /api/doctors` - Get all doctors (with filtering)
- `GET /api/doctors/{id}` - Get specific doctor
- `POST /api/doctors` - Create new doctor
- `PUT /api/doctors/{id}` - Update doctor
- `DELETE /api/doctors/{id}` - Delete doctor

### Appointments API (`/api/appointments.php`)
- `GET /api/appointments` - Get all appointments
- `GET /api/appointments/{id}` - Get specific appointment
- `POST /api/appointments` - Create new appointment
- `PUT /api/appointments/{id}` - Update appointment
- `DELETE /api/appointments/{id}` - Delete appointment

## Database Schema

### Core Tables
- **users**: System users and authentication
- **patients**: Patient information and medical history
- **doctors**: Doctor profiles and specializations
- **departments**: Hospital departments
- **appointments**: Appointment scheduling
- **medical_records**: Patient medical records
- **billing**: Financial transactions
- **inventory**: Medical supplies and equipment

### Key Features
- **Referential Integrity**: Foreign key constraints
- **Audit Logging**: Automatic change tracking
- **Data Validation**: Constraints and triggers
- **Performance Optimization**: Indexes and views

## Usage Guide

### Adding a New Patient
1. Navigate to the Patients section
2. Click "Add New Patient"
3. Fill in the required information
4. Save the patient record

### Scheduling an Appointment
1. Go to the Appointments section
2. Click "Book New Appointment"
3. Select patient and doctor
4. Choose date and time
5. Add appointment reason
6. Confirm booking

### Managing Doctors
1. Access the Doctors section
2. Add new doctors with their specializations
3. Assign doctors to departments
4. Set working hours and availability

### Viewing Reports
1. Navigate to the Reports section
2. View patient statistics by gender
3. Analyze appointment trends
4. Monitor department performance

## Configuration

### Environment Variables
Update `api/config.php` for your environment:
```php
// Database settings
define('DB_HOST', 'localhost');
define('DB_NAME', 'hospital_management_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');

// Security settings
define('JWT_SECRET', 'your-secret-key');
define('JWT_EXPIRY', 3600);

// Application settings
define('APP_URL', 'http://localhost/hms');
```

### Customization
- **Styling**: Modify `css/style.css` for custom themes
- **Functionality**: Extend `js/app.js` for additional features
- **Database**: Add tables in `database/schema.sql`
- **API**: Create new endpoints in the `api/` directory

## Security Features

- **Input Validation**: Server-side validation for all inputs
- **SQL Injection Prevention**: PDO prepared statements
- **XSS Protection**: Input sanitization and output encoding
- **CSRF Protection**: Token-based request validation
- **Authentication**: JWT-based user authentication
- **Audit Logging**: Complete activity tracking

## Browser Support

- Chrome 70+
- Firefox 65+
- Safari 12+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

## Troubleshooting

### Common Issues

1. **Database Connection Error**
   - Check database credentials in `config.php`
   - Ensure MySQL service is running
   - Verify database exists

2. **API Endpoints Not Working**
   - Check web server configuration
   - Ensure PHP is properly configured
   - Verify file permissions

3. **Charts Not Displaying**
   - Check Chart.js CDN connection
   - Verify JavaScript console for errors
   - Ensure data is properly formatted

4. **Styling Issues**
   - Clear browser cache
   - Check CSS file path
   - Verify Font Awesome CDN

### Debug Mode
Enable debug mode in `config.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

## Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support and questions:
- Create an issue in the repository
- Check the troubleshooting section
- Review the API documentation

## Future Enhancements

- [ ] Real-time notifications
- [ ] Mobile app integration
- [ ] Advanced reporting
- [ ] Multi-language support
- [ ] Cloud deployment
- [ ] Integration with medical devices
- [ ] Telemedicine features
- [ ] Advanced analytics with AI

## Changelog

### Version 1.0.0
- Initial release
- Core patient, doctor, and appointment management
- Dashboard with analytics
- Responsive design
- API endpoints
- Database schema
- Documentation

---

**Note**: This is a demonstration project. For production use, additional security measures, testing, and compliance with healthcare regulations should be implemented.
