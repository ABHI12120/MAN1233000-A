// Authentication System for Hospital Management System
class AuthSystem {
    constructor() {
        this.adminCredentials = {
            username: 'admin',
            password: 'admin123'
        };
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.checkExistingSession();
    }

    setupEventListeners() {
        const loginForm = document.getElementById('loginForm');
        if (loginForm) {
            loginForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleLogin();
            });
        }

        // Enter key support
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && document.getElementById('loginForm')) {
                this.handleLogin();
            }
        });
    }

    checkExistingSession() {
        // Check if user is already logged in
        const isLoggedIn = localStorage.getItem('hms_logged_in');
        const loginTime = localStorage.getItem('hms_login_time');
        
        if (isLoggedIn === 'true' && loginTime) {
            // Check if session is still valid (24 hours)
            const now = new Date().getTime();
            const sessionTime = parseInt(loginTime);
            const hoursDiff = (now - sessionTime) / (1000 * 60 * 60);
            
            if (hoursDiff < 24) {
                // Session is still valid, redirect to main system
                this.redirectToMain();
                return;
            } else {
                // Session expired, clear storage
                localStorage.removeItem('hms_logged_in');
                localStorage.removeItem('hms_login_time');
                localStorage.removeItem('hms_remember_me');
                localStorage.removeItem('hms_auth_token');
                window.location.href = 'login.html';
            }
        }
    }

    handleLogin() {
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        const rememberMe = document.getElementById('rememberMe').checked;

        // Clear previous error messages
        this.hideError();

        // Validate inputs
        if (!username || !password) {
            this.showError('Please enter both username and password.');
            return;
        }

        // Check credentials
        if (username === this.adminCredentials.username && password === this.adminCredentials.password) {
            // Successful login
            this.loginSuccess(rememberMe);
        } else {
            // Failed login
            this.showError('Invalid username or password. Please try again.');
        }
    }

    loginSuccess(rememberMe) {
        // Store login session
        localStorage.setItem('hms_logged_in', 'true');
        localStorage.setItem('hms_login_time', new Date().getTime().toString());
        
        // Generate a simple auth token (in a real app, this would come from the server)
        const authToken = 'hms_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        localStorage.setItem('hms_auth_token', authToken);
        
        if (rememberMe) {
            localStorage.setItem('hms_remember_me', 'true');
        }

        // Show success message briefly
        this.showSuccess('Login successful! Redirecting...');

        // Redirect to main system after a short delay
        setTimeout(() => {
            this.redirectToMain();
        }, 1000);
    }

    showError(message) {
        const errorDiv = document.getElementById('errorMessage');
        const errorText = document.getElementById('errorText');
        
        if (errorDiv && errorText) {
            errorText.textContent = message;
            errorDiv.style.display = 'flex';
            
            // Auto-hide error after 5 seconds
            setTimeout(() => {
                this.hideError();
            }, 5000);
        }
    }

    showSuccess(message) {
        const errorDiv = document.getElementById('errorMessage');
        const errorText = document.getElementById('errorText');
        
        if (errorDiv && errorText) {
            errorDiv.className = 'error-message success-message';
            errorDiv.style.backgroundColor = '#d4edda';
            errorDiv.style.color = '#155724';
            errorDiv.style.borderColor = '#c3e6cb';
            
            const icon = errorDiv.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-check-circle';
                icon.style.color = '#28a745';
            }
            
            errorText.textContent = message;
            errorDiv.style.display = 'flex';
        }
    }

    hideError() {
        const errorDiv = document.getElementById('errorMessage');
        if (errorDiv) {
            errorDiv.style.display = 'none';
            // Reset styling
            errorDiv.className = 'error-message';
            errorDiv.style.backgroundColor = '';
            errorDiv.style.color = '';
            errorDiv.style.borderColor = '';
            
            const icon = errorDiv.querySelector('i');
            if (icon) {
                icon.className = 'fas fa-exclamation-circle';
                icon.style.color = '';
            }
        }
    }

    redirectToMain() {
        // Redirect to main system
        window.location.href = 'index.html';
    }

    logout() {
        // Show logout confirmation
        if (confirm('Are you sure you want to logout?')) {
            this.performLogout();
        }
    }

    async performLogout() {
        try {
            // Try to call logout API if available
            const token = localStorage.getItem('hms_auth_token');
            if (token) {
                await fetch('api/logout.php', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
            }
        } catch (error) {
            // Continue with logout even if API call fails
            console.log('Logout API call failed, continuing with local logout');
        }
        
        // Clear all authentication data
        localStorage.removeItem('hms_logged_in');
        localStorage.removeItem('hms_login_time');
        localStorage.removeItem('hms_remember_me');
        localStorage.removeItem('hms_auth_token');
        
        // Show logout message
        this.showSuccess('Logging out...');
        
        // Redirect to login page after a short delay
        setTimeout(() => {
            window.location.href = 'login.html';
        }, 1000);
    }

    // Static method to check authentication from other pages
    static checkAuth() {
        const isLoggedIn = localStorage.getItem('hms_logged_in');
        const loginTime = localStorage.getItem('hms_login_time');
        
        if (isLoggedIn !== 'true' || !loginTime) {
            window.location.href = 'login.html';
            return false;
        }

        // Check if session is still valid (24 hours)
        const now = new Date().getTime();
        const sessionTime = parseInt(loginTime);
        const hoursDiff = (now - sessionTime) / (1000 * 60 * 60);
        
        if (hoursDiff >= 24) {
            // Session expired
            localStorage.removeItem('hms_logged_in');
            localStorage.removeItem('hms_login_time');
            localStorage.removeItem('hms_remember_me');
            localStorage.removeItem('hms_auth_token');
            window.location.href = 'login.html';
            return false;
        }

        return true;
    }

    // Static method to logout from other pages
    static async logout() {
        try {
            // Try to call logout API if available
            const token = localStorage.getItem('hms_auth_token');
            if (token) {
                await fetch('api/logout.php', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${token}`,
                        'Content-Type': 'application/json'
                    }
                });
            }
        } catch (error) {
            // Continue with logout even if API call fails
            console.log('Logout API call failed, continuing with local logout');
        }
        
        // Clear all authentication data
        localStorage.removeItem('hms_logged_in');
        localStorage.removeItem('hms_login_time');
        localStorage.removeItem('hms_remember_me');
        localStorage.removeItem('hms_auth_token');
        
        // Redirect to login page
        window.location.href = 'login.html';
    }
}

// Initialize authentication system
const auth = new AuthSystem();

// Global logout function for use in other pages
async function logout() {
    // Show logout confirmation
    if (confirm('Are you sure you want to logout?')) {
        await AuthSystem.logout();
    }
}
