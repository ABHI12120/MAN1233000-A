// Hospital Management System - Main Application
// This file contains the main application logic and UI interactions

class HospitalManagementSystem {
    constructor() {
        this.currentSection = 'dashboard';
        this.init();
    }

    init() {
        // Check authentication first
        if (!AuthSystem.checkAuth()) {
            return; // Redirect to login page
        }
        
        this.setupEventListeners();
        this.loadDashboard();
        this.loadPatients();
        this.loadDoctors();
        this.loadAppointments();
        this.loadDepartments();
        this.loadBilling();
        this.setupSearchFunctionality();
        this.setupFormSubmissions();
    }

    // Event Listeners Setup
    setupEventListeners() {
        // Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const section = link.getAttribute('data-section');
                this.showSection(section);
            });
        });

        // Modal close events
        document.querySelectorAll('.close').forEach(closeBtn => {
            closeBtn.addEventListener('click', (e) => {
                const modal = e.target.closest('.modal');
                this.closeModal(modal.id);
            });
        });

        // Close modal when clicking outside
        document.querySelectorAll('.modal').forEach(modal => {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    this.closeModal(modal.id);
                }
            });
        });

        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                this.closeAllModals();
            }
        });
    }

    // Navigation
    showSection(sectionName) {
        // Hide all sections
        document.querySelectorAll('.content-section').forEach(section => {
            section.classList.remove('active');
        });

        // Remove active class from all nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Show selected section
        const targetSection = document.getElementById(sectionName);
        if (targetSection) {
            targetSection.classList.add('active');
        }

        // Add active class to selected nav link
        const targetLink = document.querySelector(`[data-section="${sectionName}"]`);
        if (targetLink) {
            targetLink.classList.add('active');
        }

        this.currentSection = sectionName;

        // Load section-specific data
        switch (sectionName) {
            case 'dashboard':
                this.loadDashboard();
                break;
            case 'patients':
                this.loadPatients();
                break;
            case 'doctors':
                this.loadDoctors();
                break;
            case 'appointments':
                this.loadAppointments();
                break;
            case 'departments':
                this.loadDepartments();
                break;
            case 'reports':
                this.loadReports();
                break;
            case 'billing':
                this.loadBilling();
                break;
        }
    }

    // Modal Management
    openModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
            
            // Focus first input
            const firstInput = modal.querySelector('input, select, textarea');
            if (firstInput) {
                setTimeout(() => firstInput.focus(), 100);
            }
        }
    }

    closeModal(modalId) {
        const modal = document.getElementById(modalId);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = 'auto';
            
            // Reset form
            const form = modal.querySelector('form');
            if (form) {
                form.reset();
            }
        }
    }

    closeAllModals() {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
        document.body.style.overflow = 'auto';
    }

    // Dashboard
    loadDashboard() {
        this.updateDashboardStats();
        this.loadRecentAppointments();
    }

    updateDashboardStats() {
        document.getElementById('total-patients').textContent = db.getTotalPatients();
        document.getElementById('total-doctors').textContent = db.getTotalDoctors();
        document.getElementById('today-appointments').textContent = db.getTodaysAppointmentsCount();
        document.getElementById('total-departments').textContent = db.getTotalDepartments();
    }

    loadRecentAppointments() {
        const recentAppointments = db.getRecentAppointments(5);
        const container = document.getElementById('recent-appointments');
        
        if (recentAppointments.length === 0) {
            container.innerHTML = '<p class="text-center text-muted">No recent appointments</p>';
            return;
        }

        container.innerHTML = recentAppointments.map(appointment => `
            <div class="appointment-item">
                <div class="appointment-info">
                    <h4>${appointment.patientName}</h4>
                    <p>${appointment.doctorName} - ${db.formatDate(appointment.date)} at ${db.formatTime(appointment.time)}</p>
                </div>
                <span class="appointment-status ${appointment.status}">${appointment.status}</span>
            </div>
        `).join('');
    }

    // Patient Management
    loadPatients() {
        const patients = db.getAllPatients();
        this.renderPatientsTable(patients);
    }

    renderPatientsTable(patients) {
        const tbody = document.getElementById('patients-table-body');
        
        if (patients.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No patients found</td></tr>';
            return;
        }

        tbody.innerHTML = patients.map(patient => `
            <tr>
                <td>${patient.id}</td>
                <td>${patient.name}</td>
                <td>${patient.age}</td>
                <td>${patient.gender}</td>
                <td>${patient.phone}</td>
                <td>${patient.email}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn-primary" onclick="hms.editPatient(${patient.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-danger" onclick="hms.deletePatient(${patient.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    openPatientModal() {
        this.openModal('patientModal');
    }

    editPatient(id) {
        const patient = db.getPatientById(id);
        if (patient) {
            document.getElementById('patientName').value = patient.name;
            document.getElementById('patientAge').value = patient.age;
            document.getElementById('patientGender').value = patient.gender;
            document.getElementById('patientPhone').value = patient.phone;
            document.getElementById('patientEmail').value = patient.email;
            document.getElementById('patientAddress').value = patient.address || '';
            
            // Store patient ID for update
            document.getElementById('patientForm').dataset.patientId = id;
            
            this.openModal('patientModal');
        }
    }

    deletePatient(id) {
        if (confirm('Are you sure you want to delete this patient?')) {
            db.deletePatient(id);
            this.loadPatients();
            this.updateDashboardStats();
            this.showMessage('Patient deleted successfully', 'success');
        }
    }

    // Doctor Management
    loadDoctors() {
        const doctors = db.getAllDoctors();
        this.renderDoctorsTable(doctors);
    }

    renderDoctorsTable(doctors) {
        const tbody = document.getElementById('doctors-table-body');
        
        if (doctors.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No doctors found</td></tr>';
            return;
        }

        tbody.innerHTML = doctors.map(doctor => `
            <tr>
                <td>${doctor.id}</td>
                <td>${doctor.name}</td>
                <td>${doctor.specialization}</td>
                <td>${doctor.department}</td>
                <td>${doctor.phone}</td>
                <td>${doctor.email}</td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn-primary" onclick="hms.editDoctor(${doctor.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-danger" onclick="hms.deleteDoctor(${doctor.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    openDoctorModal() {
        this.openModal('doctorModal');
    }

    editDoctor(id) {
        const doctor = db.getDoctorById(id);
        if (doctor) {
            document.getElementById('doctorName').value = doctor.name;
            document.getElementById('doctorSpecialization').value = doctor.specialization;
            document.getElementById('doctorDepartment').value = doctor.department;
            document.getElementById('doctorPhone').value = doctor.phone;
            document.getElementById('doctorEmail').value = doctor.email;
            document.getElementById('doctorExperience').value = doctor.experience;
            
            // Store doctor ID for update
            document.getElementById('doctorForm').dataset.doctorId = id;
            
            this.openModal('doctorModal');
        }
    }

    deleteDoctor(id) {
        if (confirm('Are you sure you want to delete this doctor?')) {
            db.deleteDoctor(id);
            this.loadDoctors();
            this.updateDashboardStats();
            this.showMessage('Doctor deleted successfully', 'success');
        }
    }

    // Appointment Management
    loadAppointments() {
        const appointments = db.getAllAppointments();
        this.renderAppointmentsTable(appointments);
        this.populateAppointmentDropdowns();
    }

    renderAppointmentsTable(appointments) {
        const tbody = document.getElementById('appointments-table-body');
        
        if (appointments.length === 0) {
            tbody.innerHTML = '<tr><td colspan="7" class="text-center">No appointments found</td></tr>';
            return;
        }

        tbody.innerHTML = appointments.map(appointment => `
            <tr>
                <td>${appointment.id}</td>
                <td>${appointment.patientName}</td>
                <td>${appointment.doctorName}</td>
                <td>${db.formatDate(appointment.date)}</td>
                <td>${db.formatTime(appointment.time)}</td>
                <td><span class="status-badge ${appointment.status}">${appointment.status}</span></td>
                <td>
                    <div class="table-actions">
                        <button class="btn btn-primary" onclick="hms.editAppointment(${appointment.id})">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="btn btn-danger" onclick="hms.deleteAppointment(${appointment.id})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');
    }

    openAppointmentModal() {
        this.populateAppointmentDropdowns();
        this.openModal('appointmentModal');
    }

    populateAppointmentDropdowns() {
        const patients = db.getAllPatients();
        const doctors = db.getAllDoctors();
        
        const patientSelect = document.getElementById('appointmentPatient');
        const doctorSelect = document.getElementById('appointmentDoctor');
        
        patientSelect.innerHTML = '<option value="">Select Patient</option>' +
            patients.map(patient => `<option value="${patient.id}">${patient.name}</option>`).join('');
        
        doctorSelect.innerHTML = '<option value="">Select Doctor</option>' +
            doctors.map(doctor => `<option value="${doctor.id}">${doctor.name} - ${doctor.specialization}</option>`).join('');
    }

    editAppointment(id) {
        const appointment = db.getAppointmentById(id);
        if (appointment) {
            this.populateAppointmentDropdowns();
            
            document.getElementById('appointmentPatient').value = appointment.patientId;
            document.getElementById('appointmentDoctor').value = appointment.doctorId;
            document.getElementById('appointmentDate').value = appointment.date;
            document.getElementById('appointmentTime').value = appointment.time;
            document.getElementById('appointmentReason').value = appointment.reason;
            
            // Store appointment ID for update
            document.getElementById('appointmentForm').dataset.appointmentId = id;
            
            this.openModal('appointmentModal');
        }
    }

    deleteAppointment(id) {
        if (confirm('Are you sure you want to delete this appointment?')) {
            db.deleteAppointment(id);
            this.loadAppointments();
            this.updateDashboardStats();
            this.showMessage('Appointment deleted successfully', 'success');
        }
    }

    // Department Management
    loadDepartments() {
        const departments = db.getAllDepartments();
        this.renderDepartmentsGrid(departments);
    }

    renderDepartmentsGrid(departments) {
        const container = document.getElementById('departments-grid');
        
        if (departments.length === 0) {
            container.innerHTML = '<p class="text-center text-muted">No departments found</p>';
            return;
        }

        container.innerHTML = departments.map(department => `
            <div class="department-card">
                <h3>${department.name}</h3>
                <p>${department.description}</p>
                <div class="department-stats">
                    <div class="department-stat">
                        <div class="number">${department.doctorsCount}</div>
                        <div class="label">Doctors</div>
                    </div>
                    <div class="department-stat">
                        <div class="number">${department.patientsCount}</div>
                        <div class="label">Patients</div>
                    </div>
                </div>
                <div class="table-actions mt-2">
                    <button class="btn btn-primary" onclick="hms.editDepartment(${department.id})">
                        <i class="fas fa-edit"></i> Edit
                    </button>
                    <button class="btn btn-danger" onclick="hms.deleteDepartment(${department.id})">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </div>
            </div>
        `).join('');
    }

    openDepartmentModal() {
        this.openModal('departmentModal');
    }

    editDepartment(id) {
        const department = db.getDepartmentById(id);
        if (department) {
            document.getElementById('departmentName').value = department.name;
            document.getElementById('departmentDescription').value = department.description;
            document.getElementById('departmentHead').value = department.head;
            
            // Store department ID for update
            document.getElementById('departmentForm').dataset.departmentId = id;
            
            this.openModal('departmentModal');
        }
    }

    deleteDepartment(id) {
        if (confirm('Are you sure you want to delete this department?')) {
            db.deleteDepartment(id);
            this.loadDepartments();
            this.updateDashboardStats();
            this.showMessage('Department deleted successfully', 'success');
        }
    }


    // Reports
    loadReports() {
        this.createPatientChart();
        this.createAppointmentChart();
        this.createDepartmentChart();
        this.createBillingDateChart();
        this.createBillingPatientChart();
    }

    // Billing
    loadBilling() {
        this.renderBillsTable(db.getAllBills());
        this.populateBillPatients();
        this.ensureAtLeastOneBillItemRow();
        this.updateBillTotalsPreview();
    }

    renderBillsTable(bills) {
        const tbody = document.getElementById('billing-table-body');
        if (!tbody) return;
        if (bills.length === 0) {
            tbody.innerHTML = '<tr><td colspan="9" class="text-center">No bills found</td></tr>';
            return;
        }
        tbody.innerHTML = bills.map(bill => {
            const totals = db.calculateBillTotals(bill.items, bill.taxPercent, bill.discountPercent);
            const itemsCount = bill.items.reduce((sum, it) => sum + Number(it.quantity), 0);
            return `
                <tr>
                    <td>${bill.billNumber}</td>
                    <td>${bill.patientName}</td>
                    <td>${db.formatDate(bill.date)}</td>
                    <td>${itemsCount}</td>
                    <td>$${totals.subtotal.toFixed(2)}</td>
                    <td>$${totals.taxAmount.toFixed(2)}</td>
                    <td><strong>$${totals.total.toFixed(2)}</strong></td>
                    <td><span class="status-badge ${bill.status}">${bill.status}</span></td>
                    <td>
                        <div class="table-actions">
                            <button class="btn btn-primary" onclick="hms.editBill(${bill.id})"><i class="fas fa-edit"></i></button>
                            <button class="btn btn-danger" onclick="hms.deleteBill(${bill.id})"><i class="fas fa-trash"></i></button>
                        </div>
                    </td>
                </tr>
            `;
        }).join('');
    }

    populateBillPatients() {
        const select = document.getElementById('billPatient');
        if (!select) return;
        const patients = db.getAllPatients();
        select.innerHTML = '<option value="">Select Patient</option>' +
            patients.map(p => `<option value="${p.id}">${p.name}</option>`).join('');
    }

    ensureAtLeastOneBillItemRow() {
        const container = document.getElementById('billItems');
        if (!container) return;
        if (container.children.length === 0) {
            this.addBillItemRow();
        }
    }

    addBillItemRow(item = { description: '', quantity: 1, unitPrice: 0 }) {
        const container = document.getElementById('billItems');
        if (!container) return;
        const row = document.createElement('div');
        row.className = 'form-row';
        row.innerHTML = `
            <div class="form-group" style="flex:2">
                <input type="text" class="bill-desc" placeholder="Description" value="${item.description || ''}">
            </div>
            <div class="form-group">
                <input type="number" class="bill-qty" min="1" value="${item.quantity || 1}">
            </div>
            <div class="form-group">
                <input type="number" class="bill-price" min="0" step="0.01" value="${item.unitPrice || 0}">
            </div>
            <div class="form-group">
                <button type="button" class="btn btn-danger" onclick="this.closest('.form-row').remove(); hms.updateBillTotalsPreview();"><i class="fas fa-trash"></i></button>
            </div>
        `;
        container.appendChild(row);
        ['input', 'change'].forEach(ev => row.addEventListener(ev, () => this.updateBillTotalsPreview()));
    }

    collectBillFormData() {
        const patientId = parseInt(document.getElementById('billPatient').value);
        const patient = db.getPatientById(patientId);
        const date = document.getElementById('billDate').value || new Date().toISOString().slice(0,10);
        const taxPercent = Number(document.getElementById('billTax').value || 0);
        const discountPercent = Number(document.getElementById('billDiscount').value || 0);
        const items = Array.from(document.querySelectorAll('#billItems .form-row')).map(r => ({
            description: r.querySelector('.bill-desc').value,
            quantity: Number(r.querySelector('.bill-qty').value || 1),
            unitPrice: Number(r.querySelector('.bill-price').value || 0)
        })).filter(it => it.description);
        return { patientId, patientName: patient ? patient.name : '', date, items, taxPercent, discountPercent, status: 'unpaid' };
    }

    updateBillTotalsPreview() {
        const data = this.collectBillFormData();
        const totals = db.calculateBillTotals(data.items || [], data.taxPercent, data.discountPercent);
        const setText = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = Number(val).toFixed(2); };
        setText('billSubtotal', totals.subtotal);
        setText('billTaxAmount', totals.taxAmount);
        setText('billDiscountAmount', totals.discountAmount);
        setText('billTotal', totals.total);
    }

    openBillModal() {
        this.populateBillPatients();
        document.getElementById('billForm').reset();
        document.getElementById('billItems').innerHTML = '';
        this.ensureAtLeastOneBillItemRow();
        this.openModal('billModal');
    }

    editBill(id) {
        const bill = db.getBillById(id);
        if (!bill) return;
        document.getElementById('billForm').dataset.billId = id;
        this.populateBillPatients();
        document.getElementById('billPatient').value = bill.patientId;
        document.getElementById('billDate').value = bill.date;
        document.getElementById('billTax').value = bill.taxPercent;
        document.getElementById('billDiscount').value = bill.discountPercent;
        const container = document.getElementById('billItems');
        container.innerHTML = '';
        bill.items.forEach(it => this.addBillItemRow(it));
        this.updateBillTotalsPreview();
        this.openModal('billModal');
    }

    deleteBill(id) {
        if (confirm('Delete this bill?')) {
            db.deleteBill(id);
            this.loadBilling();
            this.showMessage('Bill deleted', 'success');
        }
    }

    createPatientChart() {
        const ctx = document.getElementById('patientChart');
        if (!ctx) return;

        const stats = db.getPatientStatsByGender();
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: Object.keys(stats),
                datasets: [{
                    data: Object.values(stats),
                    backgroundColor: [
                        '#667eea',
                        '#f093fb',
                        '#4facfe'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }

    createAppointmentChart() {
        const ctx = document.getElementById('appointmentChart');
        if (!ctx) return;

        const stats = db.getAppointmentStatsByStatus();
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: Object.keys(stats).map(key => key.charAt(0).toUpperCase() + key.slice(1)),
                datasets: [{
                    label: 'Appointments',
                    data: Object.values(stats),
                    backgroundColor: [
                        '#667eea',
                        '#28a745',
                        '#dc3545'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    createDepartmentChart() {
        const ctx = document.getElementById('departmentChart');
        if (!ctx) return;

        const stats = db.getDepartmentStats();
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: stats.map(dept => dept.name),
                datasets: [{
                    label: 'Patients',
                    data: stats.map(dept => dept.patients),
                    borderColor: '#667eea',
                    backgroundColor: 'rgba(102, 126, 234, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Doctors',
                    data: stats.map(dept => dept.doctors),
                    borderColor: '#f093fb',
                    backgroundColor: 'rgba(240, 147, 251, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    }

    createBillingDateChart() {
        const ctx = document.getElementById('billingDateChart');
        if (!ctx) return;
        const map = db.getBillingSummaryByDate();
        const labels = Object.keys(map).sort();
        const data = labels.map(k => Number(map[k].toFixed(2)));
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels,
                datasets: [{ label: 'Total ($)', data, backgroundColor: '#36a2eb' }]
            },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    createBillingPatientChart() {
        const ctx = document.getElementById('billingPatientChart');
        if (!ctx) return;
        const map = db.getBillingSummaryByPatient();
        const entries = Object.entries(map);
        const labels = entries.map(([k]) => k.split(':')[1]);
        const data = entries.map(([, v]) => Number(v.toFixed(2)));
        new Chart(ctx, {
            type: 'doughnut',
            data: { labels, datasets: [{ data, backgroundColor: ['#667eea','#f093fb','#4facfe','#28a745','#ffc107','#dc3545'] }] },
            options: { responsive: true, maintainAspectRatio: false }
        });
    }

    // Search Functionality
    setupSearchFunctionality() {
        // Patient search
        const patientSearch = document.getElementById('patient-search');
        if (patientSearch) {
            patientSearch.addEventListener('input', (e) => {
                const query = e.target.value;
                if (query.length > 0) {
                    const results = db.searchPatients(query);
                    this.renderPatientsTable(results);
                } else {
                    this.loadPatients();
                }
            });
        }

        // Doctor search
        const doctorSearch = document.getElementById('doctor-search');
        if (doctorSearch) {
            doctorSearch.addEventListener('input', (e) => {
                const query = e.target.value;
                if (query.length > 0) {
                    const results = db.searchDoctors(query);
                    this.renderDoctorsTable(results);
                } else {
                    this.loadDoctors();
                }
            });
        }

        // Appointment search
        const appointmentSearch = document.getElementById('appointment-search');
        if (appointmentSearch) {
            appointmentSearch.addEventListener('input', (e) => {
                const query = e.target.value;
                if (query.length > 0) {
                    const results = db.searchAppointments(query);
                    this.renderAppointmentsTable(results);
                } else {
                    this.loadAppointments();
                }
            });
        }

        // (Buildings removed)

        // Billing search
        const billingSearch = document.getElementById('billing-search');
        if (billingSearch) {
            billingSearch.addEventListener('input', (e) => {
                const query = e.target.value;
                if (query.length > 0) {
                    const results = db.searchBills(query);
                    this.renderBillsTable(results);
                } else {
                    this.loadBilling();
                }
            });
        }
    }

    // Form Submissions
    setupFormSubmissions() {
        // Patient form
        const patientForm = document.getElementById('patientForm');
        if (patientForm) {
            patientForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handlePatientSubmit();
            });
        }

        // Doctor form
        const doctorForm = document.getElementById('doctorForm');
        if (doctorForm) {
            doctorForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleDoctorSubmit();
            });
        }

        // Appointment form
        const appointmentForm = document.getElementById('appointmentForm');
        if (appointmentForm) {
            appointmentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleAppointmentSubmit();
            });
        }

        // Department form
        const departmentForm = document.getElementById('departmentForm');
        if (departmentForm) {
            departmentForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleDepartmentSubmit();
            });
        }

        // (Buildings removed)

        // Bill form
        const billForm = document.getElementById('billForm');
        if (billForm) {
            billForm.addEventListener('submit', (e) => {
                e.preventDefault();
                this.handleBillSubmit();
            });
        }
    }

    handlePatientSubmit() {
        const form = document.getElementById('patientForm');
        const patientId = form.dataset.patientId;
        
        const patientData = {
            name: document.getElementById('patientName').value,
            age: parseInt(document.getElementById('patientAge').value),
            gender: document.getElementById('patientGender').value,
            phone: document.getElementById('patientPhone').value,
            email: document.getElementById('patientEmail').value,
            address: document.getElementById('patientAddress').value
        };

        if (patientId) {
            // Update existing patient
            db.updatePatient(patientId, patientData);
            this.showMessage('Patient updated successfully', 'success');
        } else {
            // Create new patient
            db.createPatient(patientData);
            this.showMessage('Patient added successfully', 'success');
        }

        this.closeModal('patientModal');
        this.loadPatients();
        this.updateDashboardStats();
    }

    handleDoctorSubmit() {
        const form = document.getElementById('doctorForm');
        const doctorId = form.dataset.doctorId;
        
        const doctorData = {
            name: document.getElementById('doctorName').value,
            specialization: document.getElementById('doctorSpecialization').value,
            department: document.getElementById('doctorDepartment').value,
            phone: document.getElementById('doctorPhone').value,
            email: document.getElementById('doctorEmail').value,
            experience: parseInt(document.getElementById('doctorExperience').value),
            status: 'active'
        };

        if (doctorId) {
            // Update existing doctor
            db.updateDoctor(doctorId, doctorData);
            this.showMessage('Doctor updated successfully', 'success');
        } else {
            // Create new doctor
            db.createDoctor(doctorData);
            this.showMessage('Doctor added successfully', 'success');
        }

        this.closeModal('doctorModal');
        this.loadDoctors();
        this.updateDashboardStats();
    }

    handleAppointmentSubmit() {
        const form = document.getElementById('appointmentForm');
        const appointmentId = form.dataset.appointmentId;
        
        const patientId = parseInt(document.getElementById('appointmentPatient').value);
        const doctorId = parseInt(document.getElementById('appointmentDoctor').value);
        const patient = db.getPatientById(patientId);
        const doctor = db.getDoctorById(doctorId);
        
        const appointmentData = {
            patientId: patientId,
            doctorId: doctorId,
            patientName: patient.name,
            doctorName: doctor.name,
            date: document.getElementById('appointmentDate').value,
            time: document.getElementById('appointmentTime').value,
            reason: document.getElementById('appointmentReason').value,
            status: 'scheduled'
        };

        if (appointmentId) {
            // Update existing appointment
            db.updateAppointment(appointmentId, appointmentData);
            this.showMessage('Appointment updated successfully', 'success');
        } else {
            // Create new appointment
            db.createAppointment(appointmentData);
            this.showMessage('Appointment booked successfully', 'success');
        }

        this.closeModal('appointmentModal');
        this.loadAppointments();
        this.updateDashboardStats();
    }

    handleDepartmentSubmit() {
        const form = document.getElementById('departmentForm');
        const departmentId = form.dataset.departmentId;
        
        const departmentData = {
            name: document.getElementById('departmentName').value,
            description: document.getElementById('departmentDescription').value,
            head: document.getElementById('departmentHead').value,
            doctorsCount: 0,
            patientsCount: 0
        };

        if (departmentId) {
            // Update existing department
            db.updateDepartment(departmentId, departmentData);
            this.showMessage('Department updated successfully', 'success');
        } else {
            // Create new department
            db.createDepartment(departmentData);
            this.showMessage('Department added successfully', 'success');
        }

        this.closeModal('departmentModal');
        this.loadDepartments();
        this.updateDashboardStats();
    }

    handleBuildingSubmit() {
        const form = document.getElementById('buildingForm');
        const buildingId = form.dataset.buildingId;
        
        const buildingData = {
            name: document.getElementById('buildingName').value,
            code: document.getElementById('buildingCode').value,
            address: document.getElementById('buildingAddress').value,
            floors: parseInt(document.getElementById('buildingFloors').value),
            capacity: parseInt(document.getElementById('buildingCapacity').value),
            manager: document.getElementById('buildingManager').value,
            status: document.getElementById('buildingStatus').value,
            departmentsCount: 0,
            occupancy: 0
        };

        if (buildingId) {
            // Update existing building
            db.updateBuilding(buildingId, buildingData);
            this.showMessage('Building updated successfully', 'success');
        } else {
            // Create new building
            db.createBuilding(buildingData);
            this.showMessage('Building added successfully', 'success');
        }

        this.closeModal('buildingModal');
        this.loadBuildings();
        this.updateDashboardStats();
    }

    handleBillSubmit() {
        const form = document.getElementById('billForm');
        const billId = form.dataset.billId;
        const data = this.collectBillFormData();
        if (!data.patientId || data.items.length === 0) {
            this.showMessage('Select patient and add at least one item', 'error');
            return;
        }
        if (billId) {
            db.updateBill(billId, data);
            this.showMessage('Bill updated', 'success');
        } else {
            db.createBill(data);
            this.showMessage('Bill created', 'success');
        }
        this.closeModal('billModal');
        this.loadBilling();
    }

    // Utility Methods
    showMessage(message, type = 'success') {
        // Remove existing messages
        const existingMessages = document.querySelectorAll('.message');
        existingMessages.forEach(msg => msg.remove());

        // Create new message
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${type}`;
        messageDiv.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            ${message}
        `;

        // Insert message at the top of the current section
        const currentSection = document.querySelector('.content-section.active');
        if (currentSection) {
            currentSection.insertBefore(messageDiv, currentSection.firstChild);
            
            // Auto-remove message after 5 seconds
            setTimeout(() => {
                messageDiv.remove();
            }, 5000);
        }
    }
}

// Global functions for HTML onclick handlers
function showSection(sectionName) {
    hms.showSection(sectionName);
}

function openPatientModal() {
    hms.openPatientModal();
}

function openDoctorModal() {
    hms.openDoctorModal();
}

function openAppointmentModal() {
    hms.openAppointmentModal();
}

function openDepartmentModal() {
    hms.openDepartmentModal();
}

// (Buildings removed)

function closeModal(modalId) {
    hms.closeModal(modalId);
}

function openBillModal() {
    hms.openBillModal();
}

function addBillItem() {
    hms.addBillItemRow();
}

// Simple logout function for the main interface
function handleLogout() {
    if (confirm('Are you sure you want to logout?')) {
        // Clear all authentication data
        localStorage.removeItem('hms_logged_in');
        localStorage.removeItem('hms_login_time');
        localStorage.removeItem('hms_remember_me');
        localStorage.removeItem('hms_auth_token');
        
        // Show logout message
        alert('Logging out...');
        
        // Redirect to login page
        window.location.href = 'login.html';
    }
}

// Initialize the application
const hms = new HospitalManagementSystem();

// Ensure logout is accessible globally
window.handleLogout = handleLogout;
