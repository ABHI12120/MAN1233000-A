// Hospital Management System - Database Module
// This module simulates a database using localStorage for demo purposes
// In a real application, this would connect to a SQL database

class Database {
    constructor() {
        this.initializeDatabase();
    }

    // Initialize database with sample data
    initializeDatabase() {
        // Check if data already exists
        if (!localStorage.getItem('hms_patients')) {
            this.seedPatients();
        }
        if (!localStorage.getItem('hms_doctors')) {
            this.seedDoctors();
        }
        if (!localStorage.getItem('hms_appointments')) {
            this.seedAppointments();
        }
        if (!localStorage.getItem('hms_departments')) {
            this.seedDepartments();
        }
        if (!localStorage.getItem('hms_buildings')) {
            this.seedBuildings();
        }
        if (!localStorage.getItem('hms_bills')) {
            this.seedBills();
        }
    }

    // Seed sample patients data
    seedPatients() {
        const patients = [
            {
                id: 1,
                name: "John Smith",
                age: 45,
                gender: "Male",
                phone: "+1-555-0123",
                email: "john.smith@email.com",
                address: "123 Main St, New York, NY 10001",
                dateAdded: new Date().toISOString()
            },
            {
                id: 2,
                name: "Sarah Johnson",
                age: 32,
                gender: "Female",
                phone: "+1-555-0124",
                email: "sarah.johnson@email.com",
                address: "456 Oak Ave, Los Angeles, CA 90210",
                dateAdded: new Date().toISOString()
            },
            {
                id: 3,
                name: "Michael Brown",
                age: 28,
                gender: "Male",
                phone: "+1-555-0125",
                email: "michael.brown@email.com",
                address: "789 Pine St, Chicago, IL 60601",
                dateAdded: new Date().toISOString()
            },
            {
                id: 4,
                name: "Emily Davis",
                age: 35,
                gender: "Female",
                phone: "+1-555-0126",
                email: "emily.davis@email.com",
                address: "321 Elm St, Houston, TX 77001",
                dateAdded: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_patients', JSON.stringify(patients));
    }

    // Seed sample doctors data
    seedDoctors() {
        const doctors = [
            {
                id: 1,
                name: "Dr. Robert Wilson",
                specialization: "Cardiologist",
                department: "Cardiology",
                phone: "+1-555-0201",
                email: "r.wilson@hospital.com",
                experience: 15,
                status: "active",
                dateAdded: new Date().toISOString()
            },
            {
                id: 2,
                name: "Dr. Lisa Anderson",
                specialization: "Neurologist",
                department: "Neurology",
                phone: "+1-555-0202",
                email: "l.anderson@hospital.com",
                experience: 12,
                status: "active",
                dateAdded: new Date().toISOString()
            },
            {
                id: 3,
                name: "Dr. James Taylor",
                specialization: "Orthopedic Surgeon",
                department: "Orthopedics",
                phone: "+1-555-0203",
                email: "j.taylor@hospital.com",
                experience: 20,
                status: "active",
                dateAdded: new Date().toISOString()
            },
            {
                id: 4,
                name: "Dr. Maria Garcia",
                specialization: "Pediatrician",
                department: "Pediatrics",
                phone: "+1-555-0204",
                email: "m.garcia@hospital.com",
                experience: 8,
                status: "active",
                dateAdded: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_doctors', JSON.stringify(doctors));
    }

    // Seed sample appointments data
    seedAppointments() {
        const appointments = [
            {
                id: 1,
                patientId: 1,
                doctorId: 1,
                patientName: "John Smith",
                doctorName: "Dr. Robert Wilson",
                date: "2024-01-15",
                time: "10:00",
                reason: "Regular checkup",
                status: "scheduled",
                dateCreated: new Date().toISOString()
            },
            {
                id: 2,
                patientId: 2,
                doctorId: 2,
                patientName: "Sarah Johnson",
                doctorName: "Dr. Lisa Anderson",
                date: "2024-01-16",
                time: "14:30",
                reason: "Headache consultation",
                status: "scheduled",
                dateCreated: new Date().toISOString()
            },
            {
                id: 3,
                patientId: 3,
                doctorId: 3,
                patientName: "Michael Brown",
                doctorName: "Dr. James Taylor",
                date: "2024-01-14",
                time: "09:00",
                reason: "Knee pain",
                status: "completed",
                dateCreated: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_appointments', JSON.stringify(appointments));
    }

    // Seed sample departments data
    seedDepartments() {
        const departments = [
            {
                id: 1,
                name: "Cardiology",
                description: "Heart and cardiovascular system care",
                head: "Dr. Robert Wilson",
                doctorsCount: 5,
                patientsCount: 120,
                dateCreated: new Date().toISOString()
            },
            {
                id: 2,
                name: "Neurology",
                description: "Brain and nervous system disorders",
                head: "Dr. Lisa Anderson",
                doctorsCount: 4,
                patientsCount: 85,
                dateCreated: new Date().toISOString()
            },
            {
                id: 3,
                name: "Orthopedics",
                description: "Bone, joint, and muscle care",
                head: "Dr. James Taylor",
                doctorsCount: 6,
                patientsCount: 150,
                dateCreated: new Date().toISOString()
            },
            {
                id: 4,
                name: "Pediatrics",
                description: "Medical care for infants, children, and adolescents",
                head: "Dr. Maria Garcia",
                doctorsCount: 3,
                patientsCount: 95,
                dateCreated: new Date().toISOString()
            },
            {
                id: 5,
                name: "Emergency",
                description: "Emergency medical care and trauma",
                head: "Dr. David Lee",
                doctorsCount: 8,
                patientsCount: 200,
                dateCreated: new Date().toISOString()
            },
            {
                id: 6,
                name: "Surgery",
                description: "Surgical procedures and operations",
                head: "Dr. Jennifer White",
                doctorsCount: 7,
                patientsCount: 110,
                dateCreated: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_departments', JSON.stringify(departments));
    }

    // Seed sample buildings data
    seedBuildings() {
        const buildings = [
            {
                id: 1,
                name: "Main Hospital Building",
                code: "MH-001",
                address: "123 Medical Center Drive, City, State 12345",
                floors: 8,
                capacity: 500,
                manager: "John Smith",
                status: "Active",
                departmentsCount: 12,
                occupancy: 85,
                dateCreated: new Date().toISOString()
            },
            {
                id: 2,
                name: "Emergency Wing",
                code: "EW-002",
                address: "125 Medical Center Drive, City, State 12345",
                floors: 3,
                capacity: 150,
                manager: "Sarah Wilson",
                status: "Active",
                departmentsCount: 3,
                occupancy: 95,
                dateCreated: new Date().toISOString()
            },
            {
                id: 3,
                name: "Research Center",
                code: "RC-003",
                address: "127 Medical Center Drive, City, State 12345",
                floors: 5,
                capacity: 200,
                manager: "Dr. Robert Brown",
                status: "Active",
                departmentsCount: 5,
                occupancy: 60,
                dateCreated: new Date().toISOString()
            },
            {
                id: 4,
                name: "Outpatient Clinic",
                code: "OC-004",
                address: "129 Medical Center Drive, City, State 12345",
                floors: 2,
                capacity: 100,
                manager: "Lisa Johnson",
                status: "Active",
                departmentsCount: 4,
                occupancy: 75,
                dateCreated: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_buildings', JSON.stringify(buildings));
    }

    // Seed sample bills data
    seedBills() {
        const bills = [
            {
                id: 1,
                billNumber: 'INV-0001',
                patientId: 1,
                patientName: 'John Smith',
                date: new Date().toISOString().slice(0, 10),
                items: [
                    { description: 'Consultation Fee', quantity: 1, unitPrice: 50 },
                    { description: 'X-Ray', quantity: 1, unitPrice: 120 }
                ],
                taxPercent: 5,
                discountPercent: 0,
                status: 'unpaid',
                dateCreated: new Date().toISOString()
            }
        ];
        localStorage.setItem('hms_bills', JSON.stringify(bills));
    }

    // Generic CRUD operations
    getAll(tableName) {
        const data = localStorage.getItem(`hms_${tableName}`);
        return data ? JSON.parse(data) : [];
    }

    getById(tableName, id) {
        const data = this.getAll(tableName);
        return data.find(item => item.id === parseInt(id));
    }

    create(tableName, item) {
        const data = this.getAll(tableName);
        const newId = data.length > 0 ? Math.max(...data.map(item => item.id)) + 1 : 1;
        const newItem = {
            ...item,
            id: newId,
            dateCreated: new Date().toISOString()
        };
        data.push(newItem);
        localStorage.setItem(`hms_${tableName}`, JSON.stringify(data));
        return newItem;
    }

    update(tableName, id, updates) {
        const data = this.getAll(tableName);
        const index = data.findIndex(item => item.id === parseInt(id));
        if (index !== -1) {
            data[index] = { ...data[index], ...updates };
            localStorage.setItem(`hms_${tableName}`, JSON.stringify(data));
            return data[index];
        }
        return null;
    }

    delete(tableName, id) {
        const data = this.getAll(tableName);
        const filteredData = data.filter(item => item.id !== parseInt(id));
        localStorage.setItem(`hms_${tableName}`, JSON.stringify(filteredData));
        return true;
    }

    // Patient specific methods
    getAllPatients() {
        return this.getAll('patients');
    }

    getPatientById(id) {
        return this.getById('patients', id);
    }

    createPatient(patientData) {
        return this.create('patients', patientData);
    }

    updatePatient(id, updates) {
        return this.update('patients', id, updates);
    }

    deletePatient(id) {
        return this.delete('patients', id);
    }

    searchPatients(query) {
        const patients = this.getAllPatients();
        const lowercaseQuery = query.toLowerCase();
        return patients.filter(patient => 
            patient.name.toLowerCase().includes(lowercaseQuery) ||
            patient.email.toLowerCase().includes(lowercaseQuery) ||
            patient.phone.includes(query)
        );
    }

    // Doctor specific methods
    getAllDoctors() {
        return this.getAll('doctors');
    }

    getDoctorById(id) {
        return this.getById('doctors', id);
    }

    createDoctor(doctorData) {
        return this.create('doctors', doctorData);
    }

    updateDoctor(id, updates) {
        return this.update('doctors', id, updates);
    }

    deleteDoctor(id) {
        return this.delete('doctors', id);
    }

    searchDoctors(query) {
        const doctors = this.getAllDoctors();
        const lowercaseQuery = query.toLowerCase();
        return doctors.filter(doctor => 
            doctor.name.toLowerCase().includes(lowercaseQuery) ||
            doctor.specialization.toLowerCase().includes(lowercaseQuery) ||
            doctor.department.toLowerCase().includes(lowercaseQuery)
        );
    }

    getDoctorsByDepartment(department) {
        const doctors = this.getAllDoctors();
        return doctors.filter(doctor => doctor.department === department);
    }

    // Appointment specific methods
    getAllAppointments() {
        return this.getAll('appointments');
    }

    getAppointmentById(id) {
        return this.getById('appointments', id);
    }

    createAppointment(appointmentData) {
        return this.create('appointments', appointmentData);
    }

    updateAppointment(id, updates) {
        return this.update('appointments', id, updates);
    }

    deleteAppointment(id) {
        return this.delete('appointments', id);
    }

    getAppointmentsByDate(date) {
        const appointments = this.getAllAppointments();
        return appointments.filter(appointment => appointment.date === date);
    }

    getTodaysAppointments() {
        const today = new Date().toISOString().split('T')[0];
        return this.getAppointmentsByDate(today);
    }

    getAppointmentsByPatient(patientId) {
        const appointments = this.getAllAppointments();
        return appointments.filter(appointment => appointment.patientId === parseInt(patientId));
    }

    getAppointmentsByDoctor(doctorId) {
        const appointments = this.getAllAppointments();
        return appointments.filter(appointment => appointment.doctorId === parseInt(doctorId));
    }

    searchAppointments(query) {
        const appointments = this.getAllAppointments();
        const lowercaseQuery = query.toLowerCase();
        return appointments.filter(appointment => 
            appointment.patientName.toLowerCase().includes(lowercaseQuery) ||
            appointment.doctorName.toLowerCase().includes(lowercaseQuery) ||
            appointment.reason.toLowerCase().includes(lowercaseQuery)
        );
    }

    // Department specific methods
    getAllDepartments() {
        return this.getAll('departments');
    }

    getDepartmentById(id) {
        return this.getById('departments', id);
    }

    createDepartment(departmentData) {
        return this.create('departments', departmentData);
    }

    updateDepartment(id, updates) {
        return this.update('departments', id, updates);
    }

    deleteDepartment(id) {
        return this.delete('departments', id);
    }

    // Building specific methods
    getAllBuildings() {
        return this.getAll('buildings');
    }

    getBuildingById(id) {
        return this.getById('buildings', id);
    }

    createBuilding(buildingData) {
        return this.create('buildings', buildingData);
    }

    updateBuilding(id, updates) {
        return this.update('buildings', id, updates);
    }

    deleteBuilding(id) {
        return this.delete('buildings', id);
    }

    getTotalBuildings() {
        return this.getAllBuildings().length;
    }

    searchBuildings(query) {
        const buildings = this.getAllBuildings();
        const lowercaseQuery = query.toLowerCase();
        
        return buildings.filter(building => 
            building.name.toLowerCase().includes(lowercaseQuery) ||
            building.code.toLowerCase().includes(lowercaseQuery) ||
            building.manager.toLowerCase().includes(lowercaseQuery) ||
            building.address.toLowerCase().includes(lowercaseQuery) ||
            building.status.toLowerCase().includes(lowercaseQuery)
        );
    }

    // Statistics methods
    getTotalPatients() {
        return this.getAllPatients().length;
    }

    getTotalDoctors() {
        return this.getAllDoctors().length;
    }

    getTotalAppointments() {
        return this.getAllAppointments().length;
    }

    getTotalDepartments() {
        return this.getAllDepartments().length;
    }

    getTodaysAppointmentsCount() {
        return this.getTodaysAppointments().length;
    }

    getRecentAppointments(limit = 5) {
        const appointments = this.getAllAppointments();
        return appointments
            .sort((a, b) => new Date(b.dateCreated) - new Date(a.dateCreated))
            .slice(0, limit);
    }

    // Billing methods
    getAllBills() {
        return this.getAll('bills');
    }

    getBillById(id) {
        return this.getById('bills', id);
    }

    createBill(billData) {
        // auto-generate bill number
        const nextNum = (this.getAllBills().length + 1).toString().padStart(4, '0');
        const billNumber = `INV-${nextNum}`;
        return this.create('bills', { ...billData, billNumber });
    }

    updateBill(id, updates) {
        return this.update('bills', id, updates);
    }

    deleteBill(id) {
        return this.delete('bills', id);
    }

    calculateBillTotals(items, taxPercent = 0, discountPercent = 0) {
        const subtotal = items.reduce((sum, item) => sum + (Number(item.quantity) * Number(item.unitPrice)), 0);
        const taxAmount = subtotal * (Number(taxPercent) / 100);
        const discountAmount = subtotal * (Number(discountPercent) / 100);
        const total = subtotal + taxAmount - discountAmount;
        return {
            subtotal: Number(subtotal.toFixed(2)),
            taxAmount: Number(taxAmount.toFixed(2)),
            discountAmount: Number(discountAmount.toFixed(2)),
            total: Number(total.toFixed(2))
        };
    }

    searchBills(query) {
        const bills = this.getAllBills();
        const q = query.toLowerCase();
        return bills.filter(b => b.billNumber.toLowerCase().includes(q) || (b.patientName || '').toLowerCase().includes(q));
    }

    getBillingSummaryByDate() {
        const bills = this.getAllBills();
        const map = {};
        bills.forEach(b => {
            const { total } = this.calculateBillTotals(b.items, b.taxPercent, b.discountPercent);
            map[b.date] = (map[b.date] || 0) + total;
        });
        return map; // { '2024-01-01': 123.45, ... }
    }

    getBillingSummaryByPatient() {
        const bills = this.getAllBills();
        const map = {};
        bills.forEach(b => {
            const { total } = this.calculateBillTotals(b.items, b.taxPercent, b.discountPercent);
            const key = `${b.patientId}:${b.patientName}`;
            map[key] = (map[key] || 0) + total;
        });
        return map; // { '1:John Smith': 200.00, ... }
    }

    // Analytics methods
    getPatientStatsByGender() {
        const patients = this.getAllPatients();
        const stats = { Male: 0, Female: 0, Other: 0 };
        patients.forEach(patient => {
            stats[patient.gender] = (stats[patient.gender] || 0) + 1;
        });
        return stats;
    }

    getAppointmentStatsByStatus() {
        const appointments = this.getAllAppointments();
        const stats = { scheduled: 0, completed: 0, cancelled: 0 };
        appointments.forEach(appointment => {
            stats[appointment.status] = (stats[appointment.status] || 0) + 1;
        });
        return stats;
    }

    getDepartmentStats() {
        const departments = this.getAllDepartments();
        return departments.map(dept => ({
            name: dept.name,
            doctors: dept.doctorsCount,
            patients: dept.patientsCount
        }));
    }

    // Utility methods
    generateId() {
        return Date.now() + Math.random();
    }

    formatDate(dateString) {
        const date = new Date(dateString);
        return date.toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric'
        });
    }

    formatTime(timeString) {
        const [hours, minutes] = timeString.split(':');
        const hour = parseInt(hours);
        const ampm = hour >= 12 ? 'PM' : 'AM';
        const displayHour = hour % 12 || 12;
        return `${displayHour}:${minutes} ${ampm}`;
    }

    // Export data (for backup purposes)
    exportData() {
        const data = {
            patients: this.getAllPatients(),
            doctors: this.getAllDoctors(),
            appointments: this.getAllAppointments(),
            departments: this.getAllDepartments(),
            exportDate: new Date().toISOString()
        };
        return JSON.stringify(data, null, 2);
    }

    // Import data (for restore purposes)
    importData(jsonData) {
        try {
            const data = JSON.parse(jsonData);
            if (data.patients) localStorage.setItem('hms_patients', JSON.stringify(data.patients));
            if (data.doctors) localStorage.setItem('hms_doctors', JSON.stringify(data.doctors));
            if (data.appointments) localStorage.setItem('hms_appointments', JSON.stringify(data.appointments));
            if (data.departments) localStorage.setItem('hms_departments', JSON.stringify(data.departments));
            return true;
        } catch (error) {
            console.error('Error importing data:', error);
            return false;
        }
    }
}

// Create global database instance
const db = new Database();
