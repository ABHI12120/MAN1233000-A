# Hospital Management System - Setup Guide

This guide will walk you through setting up the Hospital Management System on your local machine.

## Quick Start (5 minutes)

### Option 1: Using XAMPP (Recommended for beginners)

1. **Download and Install XAMPP**
   - Download from: https://www.apachefriends.org/
   - Install with default settings
   - Start Apache and MySQL services

2. **Setup the Project**
   ```bash
   # Navigate to XAMPP htdocs directory
   cd C:\xampp\htdocs
   
   # Create project directory
   mkdir hms
   cd hms
   
   # Copy all project files here
   ```

3. **Database Setup**
   - Open phpMyAdmin: http://localhost/phpmyadmin
   - Create new database: `hospital_management_system`
   - Import the schema: File → Import → Choose `database/schema.sql`

4. **Access the Application**
   - Open browser: http://localhost/hms/

### Option 2: Using WAMP (Windows)

1. **Download and Install WAMP**
   - Download from: http://www.wampserver.com/
   - Install with default settings
   - Start all services

2. **Setup the Project**
   ```bash
   # Navigate to WAMP www directory
   cd C:\wamp64\www
   
   # Create project directory
   mkdir hms
   cd hms
   
   # Copy all project files here
   ```

3. **Database Setup**
   - Open phpMyAdmin: http://localhost/phpmyadmin
   - Create new database: `hospital_management_system`
   - Import the schema: File → Import → Choose `database/schema.sql`

4. **Access the Application**
   - Open browser: http://localhost/hms/

### Option 3: Using MAMP (macOS)

1. **Download and Install MAMP**
   - Download from: https://www.mamp.info/
   - Install with default settings
   - Start servers

2. **Setup the Project**
   ```bash
   # Navigate to MAMP htdocs directory
   cd /Applications/MAMP/htdocs
   
   # Create project directory
   mkdir hms
   cd hms
   
   # Copy all project files here
   ```

3. **Database Setup**
   - Open phpMyAdmin: http://localhost:8888/phpMyAdmin/
   - Create new database: `hospital_management_system`
   - Import the schema: File → Import → Choose `database/schema.sql`

4. **Access the Application**
   - Open browser: http://localhost:8888/hms/

## Detailed Setup Instructions

### Prerequisites

- **Web Server**: Apache 2.4+ or Nginx 1.18+
- **PHP**: Version 7.4 or higher
- **MySQL**: Version 8.0 or higher
- **Browser**: Modern browser (Chrome, Firefox, Safari, Edge)

### Step 1: Environment Setup

#### For Windows Users
1. Install XAMPP or WAMP
2. Ensure PHP extensions are enabled:
   - PDO
   - PDO_MySQL
   - JSON
   - OpenSSL

#### For macOS Users
1. Install MAMP or use Homebrew:
   ```bash
   brew install php mysql
   brew services start mysql
   ```

#### For Linux Users
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install apache2 php mysql-server php-mysql php-pdo

# CentOS/RHEL
sudo yum install httpd php mysql-server php-mysql php-pdo
```

### Step 2: Project Installation

1. **Download the Project**
   ```bash
   # Clone from Git (if available)
   git clone <repository-url> hms
   
   # Or download and extract ZIP file
   unzip hms.zip
   ```

2. **Place in Web Directory**
   ```bash
   # Move to web server directory
   sudo mv hms /var/www/html/  # Linux
   # or
   cp -r hms C:\xampp\htdocs\  # Windows XAMPP
   ```

3. **Set Permissions** (Linux/macOS)
   ```bash
   sudo chown -R www-data:www-data /var/www/html/hms
   sudo chmod -R 755 /var/www/html/hms
   ```

### Step 3: Database Configuration

1. **Create Database**
   ```sql
   CREATE DATABASE hospital_management_system;
   ```

2. **Import Schema**
   ```bash
   mysql -u root -p hospital_management_system < database/schema.sql
   ```

3. **Update Configuration**
   Edit `api/config.php`:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_NAME', 'hospital_management_system');
   define('DB_USER', 'root');
   define('DB_PASS', 'your_password');
   ```

### Step 4: Web Server Configuration

#### Apache Configuration
Create `.htaccess` file in project root:
```apache
RewriteEngine On
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^api/(.*)$ api/$1.php [L]
```

#### Nginx Configuration
Add to server block:
```nginx
location /hms/ {
    try_files $uri $uri/ /hms/index.html;
}

location /hms/api/ {
    try_files $uri $uri/ /hms/api/$1.php;
}
```

### Step 5: Testing the Installation

1. **Check PHP Configuration**
   ```bash
   php -v
   php -m | grep -E "(pdo|mysql|json)"
   ```

2. **Test Database Connection**
   Create `test_db.php`:
   ```php
   <?php
   require_once 'api/config.php';
   echo "Database connection: " . ($db ? "Success" : "Failed");
   ?>
   ```

3. **Access the Application**
   - Open browser: http://localhost/hms/
   - Check if dashboard loads correctly
   - Test adding a patient

## Configuration Options

### Database Settings
```php
// api/config.php
define('DB_HOST', 'localhost');
define('DB_NAME', 'hospital_management_system');
define('DB_USER', 'your_username');
define('DB_PASS', 'your_password');
define('DB_CHARSET', 'utf8mb4');
```

### Application Settings
```php
define('APP_NAME', 'Hospital Management System');
define('APP_VERSION', '1.0.0');
define('APP_URL', 'http://localhost/hms');
```

### Security Settings
```php
define('JWT_SECRET', 'your-secret-key-here');
define('JWT_EXPIRY', 3600);
define('PASSWORD_MIN_LENGTH', 8);
```

### File Upload Settings
```php
define('UPLOAD_MAX_SIZE', 5 * 1024 * 1024); // 5MB
define('UPLOAD_ALLOWED_TYPES', ['jpg', 'jpeg', 'png', 'pdf']);
```

## Troubleshooting

### Common Issues and Solutions

#### 1. Database Connection Failed
**Error**: "Database connection failed"
**Solution**:
- Check MySQL service is running
- Verify database credentials
- Ensure database exists
- Check firewall settings

#### 2. API Endpoints Not Working
**Error**: 404 Not Found for API calls
**Solution**:
- Check web server configuration
- Verify .htaccess file
- Ensure mod_rewrite is enabled
- Check file permissions

#### 3. Charts Not Displaying
**Error**: Charts show as blank
**Solution**:
- Check internet connection (Chart.js CDN)
- Verify JavaScript console for errors
- Ensure data is properly formatted
- Check browser compatibility

#### 4. Styling Issues
**Error**: CSS not loading or broken layout
**Solution**:
- Clear browser cache
- Check CSS file path
- Verify Font Awesome CDN
- Check for JavaScript errors

#### 5. Permission Denied
**Error**: "Permission denied" when accessing files
**Solution**:
```bash
# Linux/macOS
sudo chown -R www-data:www-data /var/www/html/hms
sudo chmod -R 755 /var/www/html/hms

# Windows
# Run as Administrator or check folder permissions
```

### Debug Mode

Enable debug mode in `api/config.php`:
```php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

### Log Files

Check these log files for errors:
- **Apache**: `/var/log/apache2/error.log`
- **PHP**: `/var/log/php_errors.log`
- **MySQL**: `/var/log/mysql/error.log`

## Performance Optimization

### Database Optimization
```sql
-- Add indexes for better performance
CREATE INDEX idx_patients_search ON patients(first_name, last_name, phone);
CREATE INDEX idx_appointments_date ON appointments(appointment_date);
CREATE INDEX idx_doctors_department ON doctors(department_id);
```

### PHP Optimization
```php
// Enable OPcache in php.ini
opcache.enable=1
opcache.memory_consumption=128
opcache.max_accelerated_files=4000
```

### Web Server Optimization
```apache
# Enable compression
LoadModule deflate_module modules/mod_deflate.so
<Location />
    SetOutputFilter DEFLATE
    SetEnvIfNoCase Request_URI \
        \.(?:gif|jpe?g|png)$ no-gzip dont-vary
</Location>
```

## Security Checklist

- [ ] Change default database passwords
- [ ] Update JWT secret key
- [ ] Enable HTTPS in production
- [ ] Set proper file permissions
- [ ] Disable PHP error display in production
- [ ] Regular database backups
- [ ] Keep software updated
- [ ] Use strong passwords
- [ ] Enable firewall
- [ ] Regular security audits

## Backup and Restore

### Database Backup
```bash
# Create backup
mysqldump -u root -p hospital_management_system > backup.sql

# Restore backup
mysql -u root -p hospital_management_system < backup.sql
```

### File Backup
```bash
# Create file backup
tar -czf hms_backup.tar.gz /var/www/html/hms/

# Restore file backup
tar -xzf hms_backup.tar.gz -C /
```

## Production Deployment

### Environment Setup
1. Use a production web server (Apache/Nginx)
2. Configure SSL certificates
3. Set up database replication
4. Implement monitoring
5. Configure automated backups

### Security Hardening
1. Disable debug mode
2. Use environment variables for secrets
3. Implement rate limiting
4. Set up intrusion detection
5. Regular security updates

### Performance Tuning
1. Enable caching
2. Optimize database queries
3. Use CDN for static assets
4. Implement load balancing
5. Monitor performance metrics

## Support

If you encounter issues:
1. Check this troubleshooting guide
2. Review error logs
3. Search for similar issues online
4. Create an issue in the repository
5. Contact support

## Next Steps

After successful installation:
1. Explore the dashboard
2. Add sample data
3. Test all features
4. Customize for your needs
5. Set up regular backups
6. Plan for production deployment
