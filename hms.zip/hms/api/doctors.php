<?php
// Hospital Management System - Doctors API
// This file handles all doctor-related API endpoints

require_once 'config.php';

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Route handling
switch ($method) {
    case 'GET':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            getDoctor($path_parts[2]);
        } else {
            getDoctors();
        }
        break;
    case 'POST':
        createDoctor();
        break;
    case 'PUT':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            updateDoctor($path_parts[2]);
        } else {
            sendError('Doctor ID required for update');
        }
        break;
    case 'DELETE':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            deleteDoctor($path_parts[2]);
        } else {
            sendError('Doctor ID required for deletion');
        }
        break;
    default:
        sendError('Method not allowed', 405);
}

// Get all doctors with optional filtering and pagination
function getDoctors() {
    global $db;
    
    try {
        // Get query parameters
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(MAX_PAGE_SIZE, max(1, intval($_GET['limit']))) : DEFAULT_PAGE_SIZE;
        $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
        $department = isset($_GET['department']) ? sanitizeInput($_GET['department']) : '';
        $specialization = isset($_GET['specialization']) ? sanitizeInput($_GET['specialization']) : '';
        $is_available = isset($_GET['is_available']) ? filter_var($_GET['is_available'], FILTER_VALIDATE_BOOLEAN) : null;
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(u.first_name LIKE ? OR u.last_name LIKE ? OR d.employee_id LIKE ? OR d.specialization LIKE ?)";
            $search_param = "%$search%";
            $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param]);
        }
        
        if (!empty($department)) {
            $where_conditions[] = "dept.name = ?";
            $params[] = $department;
        }
        
        if (!empty($specialization)) {
            $where_conditions[] = "d.specialization LIKE ?";
            $params[] = "%$specialization%";
        }
        
        if ($is_available !== null) {
            $where_conditions[] = "d.is_available = ?";
            $params[] = $is_available ? 1 : 0;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total 
                      FROM doctors d 
                      JOIN users u ON d.user_id = u.id 
                      JOIN departments dept ON d.department_id = dept.id 
                      $where_clause";
        $count_stmt = $db->prepare($count_sql);
        $count_stmt->execute($params);
        $total = $count_stmt->fetch()['total'];
        
        // Get doctors
        $sql = "SELECT 
                    d.id, d.employee_id, d.specialization, d.license_number,
                    d.experience_years, d.consultation_fee, d.working_hours_start,
                    d.working_hours_end, d.is_available, d.created_at, d.updated_at,
                    u.first_name, u.last_name, u.email, u.phone,
                    dept.name as department_name, dept.id as department_id
                FROM doctors d 
                JOIN users u ON d.user_id = u.id 
                JOIN departments dept ON d.department_id = dept.id 
                $where_clause 
                ORDER BY u.first_name, u.last_name 
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $doctors = $stmt->fetchAll();
        
        // Format response
        $response = [
            'doctors' => $doctors,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ]
        ];
        
        sendSuccess($response);
        
    } catch (Exception $e) {
        sendError('Failed to fetch doctors: ' . $e->getMessage(), 500);
    }
}

// Get single doctor by ID
function getDoctor($id) {
    global $db;
    
    try {
        $sql = "SELECT 
                    d.id, d.employee_id, d.specialization, d.license_number,
                    d.experience_years, d.consultation_fee, d.working_hours_start,
                    d.working_hours_end, d.is_available, d.created_at, d.updated_at,
                    u.first_name, u.last_name, u.email, u.phone,
                    dept.name as department_name, dept.id as department_id
                FROM doctors d 
                JOIN users u ON d.user_id = u.id 
                JOIN departments dept ON d.department_id = dept.id 
                WHERE d.id = ?";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);
        $doctor = $stmt->fetch();
        
        if (!$doctor) {
            sendError('Doctor not found', 404);
        }
        
        // Get doctor's appointments for today
        $today = date('Y-m-d');
        $appointments_sql = "SELECT 
                                a.id, a.appointment_id, a.appointment_time,
                                a.reason, a.status,
                                CONCAT(p.first_name, ' ', p.last_name) as patient_name,
                                p.phone as patient_phone
                            FROM appointments a
                            JOIN patients p ON a.patient_id = p.id
                            WHERE a.doctor_id = ? AND a.appointment_date = ?
                            ORDER BY a.appointment_time";
        
        $appointments_stmt = $db->prepare($appointments_sql);
        $appointments_stmt->execute([$id, $today]);
        $doctor['today_appointments'] = $appointments_stmt->fetchAll();
        
        // Get doctor's schedule for the week
        $week_start = date('Y-m-d', strtotime('monday this week'));
        $week_end = date('Y-m-d', strtotime('sunday this week'));
        
        $schedule_sql = "SELECT 
                            appointment_date, appointment_time,
                            CONCAT(p.first_name, ' ', p.last_name) as patient_name,
                            a.reason, a.status
                        FROM appointments a
                        JOIN patients p ON a.patient_id = p.id
                        WHERE a.doctor_id = ? 
                        AND a.appointment_date BETWEEN ? AND ?
                        ORDER BY a.appointment_date, a.appointment_time";
        
        $schedule_stmt = $db->prepare($schedule_sql);
        $schedule_stmt->execute([$id, $week_start, $week_end]);
        $doctor['weekly_schedule'] = $schedule_stmt->fetchAll();
        
        sendSuccess($doctor);
        
    } catch (Exception $e) {
        sendError('Failed to fetch doctor: ' . $e->getMessage(), 500);
    }
}

// Create new doctor
function createDoctor() {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Validate required fields
        $required_fields = ['first_name', 'last_name', 'email', 'phone', 'specialization', 'department_id', 'license_number'];
        validateRequired($required_fields, $input);
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate email
        if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }
        
        // Check if email already exists
        $email_check_sql = "SELECT id FROM users WHERE email = ?";
        $email_check_stmt = $db->prepare($email_check_sql);
        $email_check_stmt->execute([$data['email']]);
        
        if ($email_check_stmt->fetch()) {
            sendError('Email already exists');
        }
        
        // Check if department exists
        $dept_check_sql = "SELECT id FROM departments WHERE id = ?";
        $dept_check_stmt = $db->prepare($dept_check_sql);
        $dept_check_stmt->execute([$data['department_id']]);
        
        if (!$dept_check_stmt->fetch()) {
            sendError('Department not found');
        }
        
        // Check if license number already exists
        $license_check_sql = "SELECT id FROM doctors WHERE license_number = ?";
        $license_check_stmt = $db->prepare($license_check_sql);
        $license_check_stmt->execute([$data['license_number']]);
        
        if ($license_check_stmt->fetch()) {
            sendError('License number already exists');
        }
        
        // Generate employee ID
        $employee_id = generateId('DOC');
        
        // Check if employee ID already exists
        $emp_check_sql = "SELECT id FROM doctors WHERE employee_id = ?";
        $emp_check_stmt = $db->prepare($emp_check_sql);
        $emp_check_stmt->execute([$employee_id]);
        
        while ($emp_check_stmt->fetch()) {
            $employee_id = generateId('DOC');
            $emp_check_stmt->execute([$employee_id]);
        }
        
        // Start transaction
        $db->beginTransaction();
        
        try {
            // Create user account
            $user_sql = "INSERT INTO users (username, email, password_hash, role, first_name, last_name, phone) 
                        VALUES (?, ?, ?, 'doctor', ?, ?, ?)";
            
            $username = strtolower($data['first_name'] . '.' . $data['last_name']);
            $password_hash = password_hash('default_password', PASSWORD_DEFAULT); // In production, generate secure password
            
            $user_stmt = $db->prepare($user_sql);
            $user_stmt->execute([
                $username,
                $data['email'],
                $password_hash,
                $data['first_name'],
                $data['last_name'],
                $data['phone']
            ]);
            
            $user_id = $db->lastInsertId();
            
            // Create doctor record
            $doctor_sql = "INSERT INTO doctors (
                            user_id, employee_id, specialization, department_id, license_number,
                            experience_years, consultation_fee, working_hours_start, working_hours_end
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
            
            $doctor_stmt = $db->prepare($doctor_sql);
            $doctor_stmt->execute([
                $user_id,
                $employee_id,
                $data['specialization'],
                $data['department_id'],
                $data['license_number'],
                $data['experience_years'] ?? 0,
                $data['consultation_fee'] ?? 0.00,
                $data['working_hours_start'] ?? '09:00:00',
                $data['working_hours_end'] ?? '17:00:00'
            ]);
            
            $doctor_id = $db->lastInsertId();
            
            $db->commit();
            
            logActivity(1, 'CREATE_DOCTOR', ['doctor_id' => $doctor_id, 'user_id' => $user_id]);
            sendSuccess(['id' => $doctor_id, 'user_id' => $user_id, 'employee_id' => $employee_id], 'Doctor created successfully');
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        sendError('Failed to create doctor: ' . $e->getMessage(), 500);
    }
}

// Update doctor
function updateDoctor($id) {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Check if doctor exists
        $check_sql = "SELECT d.id, d.user_id FROM doctors d WHERE d.id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        $doctor = $check_stmt->fetch();
        
        if (!$doctor) {
            sendError('Doctor not found', 404);
        }
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate email if provided
        if (isset($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }
        
        // Check if email already exists (excluding current doctor)
        if (isset($data['email'])) {
            $email_check_sql = "SELECT id FROM users WHERE email = ? AND id != ?";
            $email_check_stmt = $db->prepare($email_check_sql);
            $email_check_stmt->execute([$data['email'], $doctor['user_id']]);
            
            if ($email_check_stmt->fetch()) {
                sendError('Email already exists');
            }
        }
        
        // Check if department exists
        if (isset($data['department_id'])) {
            $dept_check_sql = "SELECT id FROM departments WHERE id = ?";
            $dept_check_stmt = $db->prepare($dept_check_sql);
            $dept_check_stmt->execute([$data['department_id']]);
            
            if (!$dept_check_stmt->fetch()) {
                sendError('Department not found');
            }
        }
        
        // Check if license number already exists (excluding current doctor)
        if (isset($data['license_number'])) {
            $license_check_sql = "SELECT id FROM doctors WHERE license_number = ? AND id != ?";
            $license_check_stmt = $db->prepare($license_check_sql);
            $license_check_stmt->execute([$data['license_number'], $id]);
            
            if ($license_check_stmt->fetch()) {
                sendError('License number already exists');
            }
        }
        
        // Start transaction
        $db->beginTransaction();
        
        try {
            // Update user information
            $user_update_fields = [];
            $user_params = [];
            
            $user_allowed_fields = ['first_name', 'last_name', 'email', 'phone'];
            
            foreach ($user_allowed_fields as $field) {
                if (isset($data[$field])) {
                    $user_update_fields[] = "$field = ?";
                    $user_params[] = $data[$field];
                }
            }
            
            if (!empty($user_update_fields)) {
                $user_params[] = $doctor['user_id'];
                $user_sql = "UPDATE users SET " . implode(', ', $user_update_fields) . ", updated_at = NOW() WHERE id = ?";
                $user_stmt = $db->prepare($user_sql);
                $user_stmt->execute($user_params);
            }
            
            // Update doctor information
            $doctor_update_fields = [];
            $doctor_params = [];
            
            $doctor_allowed_fields = [
                'specialization', 'department_id', 'license_number', 'experience_years',
                'consultation_fee', 'working_hours_start', 'working_hours_end', 'is_available'
            ];
            
            foreach ($doctor_allowed_fields as $field) {
                if (isset($data[$field])) {
                    $doctor_update_fields[] = "$field = ?";
                    $doctor_params[] = $data[$field];
                }
            }
            
            if (!empty($doctor_update_fields)) {
                $doctor_params[] = $id;
                $doctor_sql = "UPDATE doctors SET " . implode(', ', $doctor_update_fields) . ", updated_at = NOW() WHERE id = ?";
                $doctor_stmt = $db->prepare($doctor_sql);
                $doctor_stmt->execute($doctor_params);
            }
            
            $db->commit();
            
            logActivity(1, 'UPDATE_DOCTOR', ['doctor_id' => $id]);
            sendSuccess(['id' => $id], 'Doctor updated successfully');
            
        } catch (Exception $e) {
            $db->rollback();
            throw $e;
        }
        
    } catch (Exception $e) {
        sendError('Failed to update doctor: ' . $e->getMessage(), 500);
    }
}

// Delete doctor
function deleteDoctor($id) {
    global $db;
    
    try {
        // Check if doctor exists
        $check_sql = "SELECT d.id, d.user_id, d.employee_id FROM doctors d WHERE d.id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        $doctor = $check_stmt->fetch();
        
        if (!$doctor) {
            sendError('Doctor not found', 404);
        }
        
        // Check if doctor has appointments
        $appointments_sql = "SELECT COUNT(*) as count FROM appointments WHERE doctor_id = ?";
        $appointments_stmt = $db->prepare($appointments_sql);
        $appointments_stmt->execute([$id]);
        $appointment_count = $appointments_stmt->fetch()['count'];
        
        if ($appointment_count > 0) {
            // Soft delete - mark as unavailable instead of hard delete
            $sql = "UPDATE doctors SET is_available = 0, updated_at = NOW() WHERE id = ?";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                logActivity(1, 'DEACTIVATE_DOCTOR', ['doctor_id' => $id]);
                sendSuccess(['id' => $id], 'Doctor deactivated successfully (has existing appointments)');
            } else {
                sendError('Failed to deactivate doctor');
            }
        } else {
            // Hard delete if no appointments
            $db->beginTransaction();
            
            try {
                // Delete doctor record
                $doctor_sql = "DELETE FROM doctors WHERE id = ?";
                $doctor_stmt = $db->prepare($doctor_sql);
                $doctor_stmt->execute([$id]);
                
                // Delete user account
                $user_sql = "DELETE FROM users WHERE id = ?";
                $user_stmt = $db->prepare($user_sql);
                $user_stmt->execute([$doctor['user_id']]);
                
                $db->commit();
                
                logActivity(1, 'DELETE_DOCTOR', ['doctor_id' => $id, 'user_id' => $doctor['user_id']]);
                sendSuccess(['id' => $id], 'Doctor deleted successfully');
                
            } catch (Exception $e) {
                $db->rollback();
                throw $e;
            }
        }
        
    } catch (Exception $e) {
        sendError('Failed to delete doctor: ' . $e->getMessage(), 500);
    }
}
?>
