<?php
// Hospital Management System - Appointments API
// This file handles all appointment-related API endpoints

require_once 'config.php';

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Route handling
switch ($method) {
    case 'GET':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            getAppointment($path_parts[2]);
        } else {
            getAppointments();
        }
        break;
    case 'POST':
        createAppointment();
        break;
    case 'PUT':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            updateAppointment($path_parts[2]);
        } else {
            sendError('Appointment ID required for update');
        }
        break;
    case 'DELETE':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            deleteAppointment($path_parts[2]);
        } else {
            sendError('Appointment ID required for deletion');
        }
        break;
    default:
        sendError('Method not allowed', 405);
}

// Get all appointments with optional filtering and pagination
function getAppointments() {
    global $db;
    
    try {
        // Get query parameters
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(MAX_PAGE_SIZE, max(1, intval($_GET['limit']))) : DEFAULT_PAGE_SIZE;
        $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
        $status = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
        $date = isset($_GET['date']) ? sanitizeInput($_GET['date']) : '';
        $doctor_id = isset($_GET['doctor_id']) ? intval($_GET['doctor_id']) : null;
        $patient_id = isset($_GET['patient_id']) ? intval($_GET['patient_id']) : null;
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(p.first_name LIKE ? OR p.last_name LIKE ? OR u.first_name LIKE ? OR u.last_name LIKE ? OR a.reason LIKE ?)";
            $search_param = "%$search%";
            $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
        }
        
        if (!empty($status)) {
            $where_conditions[] = "a.status = ?";
            $params[] = $status;
        }
        
        if (!empty($date)) {
            $where_conditions[] = "a.appointment_date = ?";
            $params[] = $date;
        }
        
        if ($doctor_id !== null) {
            $where_conditions[] = "a.doctor_id = ?";
            $params[] = $doctor_id;
        }
        
        if ($patient_id !== null) {
            $where_conditions[] = "a.patient_id = ?";
            $params[] = $patient_id;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total 
                      FROM appointments a
                      JOIN patients p ON a.patient_id = p.id
                      JOIN doctors d ON a.doctor_id = d.id
                      JOIN users u ON d.user_id = u.id
                      $where_clause";
        $count_stmt = $db->prepare($count_sql);
        $count_stmt->execute($params);
        $total = $count_stmt->fetch()['total'];
        
        // Get appointments
        $sql = "SELECT 
                    a.id, a.appointment_id, a.appointment_date, a.appointment_time,
                    a.duration_minutes, a.reason, a.status, a.notes, a.diagnosis,
                    a.prescription, a.follow_up_date, a.created_at, a.updated_at,
                    p.id as patient_id, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
                    p.phone as patient_phone, p.email as patient_email,
                    d.id as doctor_id, CONCAT(u.first_name, ' ', u.last_name) as doctor_name,
                    d.specialization, dept.name as department_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN doctors d ON a.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                JOIN departments dept ON d.department_id = dept.id
                $where_clause 
                ORDER BY a.appointment_date DESC, a.appointment_time DESC 
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $appointments = $stmt->fetchAll();
        
        // Format response
        $response = [
            'appointments' => $appointments,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ]
        ];
        
        sendSuccess($response);
        
    } catch (Exception $e) {
        sendError('Failed to fetch appointments: ' . $e->getMessage(), 500);
    }
}

// Get single appointment by ID
function getAppointment($id) {
    global $db;
    
    try {
        $sql = "SELECT 
                    a.id, a.appointment_id, a.appointment_date, a.appointment_time,
                    a.duration_minutes, a.reason, a.status, a.notes, a.diagnosis,
                    a.prescription, a.follow_up_date, a.created_at, a.updated_at,
                    p.id as patient_id, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
                    p.phone as patient_phone, p.email as patient_email, p.date_of_birth,
                    p.gender, p.address, p.blood_type, p.allergies, p.medical_history,
                    d.id as doctor_id, CONCAT(u.first_name, ' ', u.last_name) as doctor_name,
                    d.specialization, d.consultation_fee, dept.name as department_name
                FROM appointments a
                JOIN patients p ON a.patient_id = p.id
                JOIN doctors d ON a.doctor_id = d.id
                JOIN users u ON d.user_id = u.id
                JOIN departments dept ON d.department_id = dept.id
                WHERE a.id = ?";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);
        $appointment = $stmt->fetch();
        
        if (!$appointment) {
            sendError('Appointment not found', 404);
        }
        
        // Get medical records for this appointment
        $records_sql = "SELECT 
                           id, record_type, title, description, diagnosis, treatment,
                           prescription, vital_signs, lab_results, created_at
                       FROM medical_records 
                       WHERE appointment_id = ? 
                       ORDER BY created_at DESC";
        
        $records_stmt = $db->prepare($records_sql);
        $records_stmt->execute([$id]);
        $appointment['medical_records'] = $records_stmt->fetchAll();
        
        sendSuccess($appointment);
        
    } catch (Exception $e) {
        sendError('Failed to fetch appointment: ' . $e->getMessage(), 500);
    }
}

// Create new appointment
function createAppointment() {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Validate required fields
        $required_fields = ['patient_id', 'doctor_id', 'appointment_date', 'appointment_time', 'reason'];
        validateRequired($required_fields, $input);
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate patient exists
        $patient_check_sql = "SELECT id, first_name, last_name FROM patients WHERE id = ? AND is_active = 1";
        $patient_check_stmt = $db->prepare($patient_check_sql);
        $patient_check_stmt->execute([$data['patient_id']]);
        $patient = $patient_check_stmt->fetch();
        
        if (!$patient) {
            sendError('Patient not found or inactive');
        }
        
        // Validate doctor exists and is available
        $doctor_check_sql = "SELECT d.id, d.is_available, u.first_name, u.last_name 
                            FROM doctors d 
                            JOIN users u ON d.user_id = u.id 
                            WHERE d.id = ?";
        $doctor_check_stmt = $db->prepare($doctor_check_sql);
        $doctor_check_stmt->execute([$data['doctor_id']]);
        $doctor = $doctor_check_stmt->fetch();
        
        if (!$doctor) {
            sendError('Doctor not found');
        }
        
        if (!$doctor['is_available']) {
            sendError('Doctor is not available');
        }
        
        // Validate appointment date and time
        $appointment_datetime = $data['appointment_date'] . ' ' . $data['appointment_time'];
        if (!strtotime($appointment_datetime)) {
            sendError('Invalid appointment date or time format');
        }
        
        // Check if appointment is in the future
        if (strtotime($appointment_datetime) <= time()) {
            sendError('Appointment must be scheduled for a future date and time');
        }
        
        // Check for conflicting appointments
        $conflict_sql = "SELECT id FROM appointments 
                        WHERE doctor_id = ? 
                        AND appointment_date = ? 
                        AND appointment_time = ? 
                        AND status IN ('scheduled', 'confirmed')";
        $conflict_stmt = $db->prepare($conflict_sql);
        $conflict_stmt->execute([$data['doctor_id'], $data['appointment_date'], $data['appointment_time']]);
        
        if ($conflict_stmt->fetch()) {
            sendError('Doctor already has an appointment at this time');
        }
        
        // Generate appointment ID
        $appointment_id = generateId('APT');
        
        // Check if appointment ID already exists
        $check_sql = "SELECT id FROM appointments WHERE appointment_id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$appointment_id]);
        
        while ($check_stmt->fetch()) {
            $appointment_id = generateId('APT');
            $check_stmt->execute([$appointment_id]);
        }
        
        // Insert appointment
        $sql = "INSERT INTO appointments (
                    appointment_id, patient_id, doctor_id, appointment_date, appointment_time,
                    duration_minutes, reason, status, notes, created_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'scheduled', ?, ?)";
        
        $stmt = $db->prepare($sql);
        $result = $stmt->execute([
            $appointment_id,
            $data['patient_id'],
            $data['doctor_id'],
            $data['appointment_date'],
            $data['appointment_time'],
            $data['duration_minutes'] ?? 30,
            $data['reason'],
            $data['notes'] ?? null,
            1 // created_by (admin user ID)
        ]);
        
        if ($result) {
            $appointment_id = $db->lastInsertId();
            logActivity(1, 'CREATE_APPOINTMENT', ['appointment_id' => $appointment_id]);
            sendSuccess(['id' => $appointment_id, 'appointment_id' => $appointment_id], 'Appointment created successfully');
        } else {
            sendError('Failed to create appointment');
        }
        
    } catch (Exception $e) {
        sendError('Failed to create appointment: ' . $e->getMessage(), 500);
    }
}

// Update appointment
function updateAppointment($id) {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Check if appointment exists
        $check_sql = "SELECT id, status FROM appointments WHERE id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        $appointment = $check_stmt->fetch();
        
        if (!$appointment) {
            sendError('Appointment not found', 404);
        }
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate status if provided
        $valid_statuses = ['scheduled', 'confirmed', 'in_progress', 'completed', 'cancelled', 'no_show'];
        if (isset($data['status']) && !in_array($data['status'], $valid_statuses)) {
            sendError('Invalid status value');
        }
        
        // Validate appointment date and time if provided
        if (isset($data['appointment_date']) && isset($data['appointment_time'])) {
            $appointment_datetime = $data['appointment_date'] . ' ' . $data['appointment_time'];
            if (!strtotime($appointment_datetime)) {
                sendError('Invalid appointment date or time format');
            }
        }
        
        // Check for conflicting appointments (if date/time is being changed)
        if (isset($data['appointment_date']) || isset($data['appointment_time'])) {
            $current_sql = "SELECT appointment_date, appointment_time, doctor_id FROM appointments WHERE id = ?";
            $current_stmt = $db->prepare($current_sql);
            $current_stmt->execute([$id]);
            $current = $current_stmt->fetch();
            
            $appointment_date = $data['appointment_date'] ?? $current['appointment_date'];
            $appointment_time = $data['appointment_time'] ?? $current['appointment_time'];
            $doctor_id = $data['doctor_id'] ?? $current['doctor_id'];
            
            $conflict_sql = "SELECT id FROM appointments 
                            WHERE doctor_id = ? 
                            AND appointment_date = ? 
                            AND appointment_time = ? 
                            AND id != ?
                            AND status IN ('scheduled', 'confirmed')";
            $conflict_stmt = $db->prepare($conflict_sql);
            $conflict_stmt->execute([$doctor_id, $appointment_date, $appointment_time, $id]);
            
            if ($conflict_stmt->fetch()) {
                sendError('Doctor already has an appointment at this time');
            }
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [];
        
        $allowed_fields = [
            'patient_id', 'doctor_id', 'appointment_date', 'appointment_time',
            'duration_minutes', 'reason', 'status', 'notes', 'diagnosis',
            'prescription', 'follow_up_date'
        ];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($update_fields)) {
            sendError('No valid fields to update');
        }
        
        $params[] = $id;
        
        $sql = "UPDATE appointments SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
        
        $stmt = $db->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            logActivity(1, 'UPDATE_APPOINTMENT', ['appointment_id' => $id]);
            sendSuccess(['id' => $id], 'Appointment updated successfully');
        } else {
            sendError('Failed to update appointment');
        }
        
    } catch (Exception $e) {
        sendError('Failed to update appointment: ' . $e->getMessage(), 500);
    }
}

// Delete appointment
function deleteAppointment($id) {
    global $db;
    
    try {
        // Check if appointment exists
        $check_sql = "SELECT id, status FROM appointments WHERE id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        $appointment = $check_stmt->fetch();
        
        if (!$appointment) {
            sendError('Appointment not found', 404);
        }
        
        // Check if appointment can be deleted (only scheduled appointments can be deleted)
        if ($appointment['status'] !== 'scheduled') {
            sendError('Only scheduled appointments can be deleted');
        }
        
        // Delete appointment
        $sql = "DELETE FROM appointments WHERE id = ?";
        $stmt = $db->prepare($sql);
        $result = $stmt->execute([$id]);
        
        if ($result) {
            logActivity(1, 'DELETE_APPOINTMENT', ['appointment_id' => $id]);
            sendSuccess(['id' => $id], 'Appointment deleted successfully');
        } else {
            sendError('Failed to delete appointment');
        }
        
    } catch (Exception $e) {
        sendError('Failed to delete appointment: ' . $e->getMessage(), 500);
    }
}
?>
