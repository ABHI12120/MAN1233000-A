<?php
// Hospital Management System - Logout API
// This file handles user logout functionality

require_once 'config.php';

// Only allow POST requests for logout
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendError('Method not allowed', 405);
}

try {
    // Get the authorization header
    $headers = getallheaders();
    $token = null;
    
    if (isset($headers['Authorization'])) {
        $authHeader = $headers['Authorization'];
        if (preg_match('/Bearer\s(\S+)/', $authHeader, $matches)) {
            $token = $matches[1];
        }
    }
    
    // If token exists, validate it and log the logout
    if ($token) {
        $payload = validateJWT($token);
        if ($payload && isset($payload['user_id'])) {
            // Log the logout activity
            logActivity($payload['user_id'], 'logout', [
                'logout_time' => date('Y-m-d H:i:s'),
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown'
            ]);
        }
    }
    
    // Return success response
    sendSuccess(null, 'Logged out successfully');
    
} catch (Exception $e) {
    // Even if logging fails, we should still allow logout
    sendSuccess(null, 'Logged out successfully');
}
?>
