<?php
// Hospital Management System - Patients API
// This file handles all patient-related API endpoints

require_once 'config.php';

// Get request method and path
$method = $_SERVER['REQUEST_METHOD'];
$path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$path_parts = explode('/', trim($path, '/'));

// Route handling
switch ($method) {
    case 'GET':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            getPatient($path_parts[2]);
        } else {
            getPatients();
        }
        break;
    case 'POST':
        createPatient();
        break;
    case 'PUT':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            updatePatient($path_parts[2]);
        } else {
            sendError('Patient ID required for update');
        }
        break;
    case 'DELETE':
        if (isset($path_parts[2]) && is_numeric($path_parts[2])) {
            deletePatient($path_parts[2]);
        } else {
            sendError('Patient ID required for deletion');
        }
        break;
    default:
        sendError('Method not allowed', 405);
}

// Get all patients with optional filtering and pagination
function getPatients() {
    global $db;
    
    try {
        // Get query parameters
        $page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
        $limit = isset($_GET['limit']) ? min(MAX_PAGE_SIZE, max(1, intval($_GET['limit']))) : DEFAULT_PAGE_SIZE;
        $search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';
        $gender = isset($_GET['gender']) ? sanitizeInput($_GET['gender']) : '';
        $is_active = isset($_GET['is_active']) ? filter_var($_GET['is_active'], FILTER_VALIDATE_BOOLEAN) : null;
        
        $offset = ($page - 1) * $limit;
        
        // Build query
        $where_conditions = [];
        $params = [];
        
        if (!empty($search)) {
            $where_conditions[] = "(first_name LIKE ? OR last_name LIKE ? OR patient_id LIKE ? OR phone LIKE ? OR email LIKE ?)";
            $search_param = "%$search%";
            $params = array_merge($params, [$search_param, $search_param, $search_param, $search_param, $search_param]);
        }
        
        if (!empty($gender)) {
            $where_conditions[] = "gender = ?";
            $params[] = $gender;
        }
        
        if ($is_active !== null) {
            $where_conditions[] = "is_active = ?";
            $params[] = $is_active ? 1 : 0;
        }
        
        $where_clause = !empty($where_conditions) ? 'WHERE ' . implode(' AND ', $where_conditions) : '';
        
        // Get total count
        $count_sql = "SELECT COUNT(*) as total FROM patients $where_clause";
        $count_stmt = $db->prepare($count_sql);
        $count_stmt->execute($params);
        $total = $count_stmt->fetch()['total'];
        
        // Get patients
        $sql = "SELECT 
                    id, patient_id, first_name, last_name, date_of_birth,
                    TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) as age,
                    gender, phone, email, address, emergency_contact_name,
                    emergency_contact_phone, blood_type, allergies, medical_history,
                    insurance_provider, insurance_number, is_active, created_at, updated_at
                FROM patients 
                $where_clause 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?";
        
        $params[] = $limit;
        $params[] = $offset;
        
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $patients = $stmt->fetchAll();
        
        // Format response
        $response = [
            'patients' => $patients,
            'pagination' => [
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'pages' => ceil($total / $limit)
            ]
        ];
        
        sendSuccess($response);
        
    } catch (Exception $e) {
        sendError('Failed to fetch patients: ' . $e->getMessage(), 500);
    }
}

// Get single patient by ID
function getPatient($id) {
    global $db;
    
    try {
        $sql = "SELECT 
                    id, patient_id, first_name, last_name, date_of_birth,
                    TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) as age,
                    gender, phone, email, address, emergency_contact_name,
                    emergency_contact_phone, blood_type, allergies, medical_history,
                    insurance_provider, insurance_number, is_active, created_at, updated_at
                FROM patients 
                WHERE id = ?";
        
        $stmt = $db->prepare($sql);
        $stmt->execute([$id]);
        $patient = $stmt->fetch();
        
        if (!$patient) {
            sendError('Patient not found', 404);
        }
        
        // Get patient's appointments
        $appointments_sql = "SELECT 
                                a.id, a.appointment_id, a.appointment_date, a.appointment_time,
                                a.reason, a.status, a.notes,
                                CONCAT(u.first_name, ' ', u.last_name) as doctor_name,
                                d.specialization, dept.name as department
                            FROM appointments a
                            JOIN doctors d ON a.doctor_id = d.id
                            JOIN users u ON d.user_id = u.id
                            JOIN departments dept ON d.department_id = dept.id
                            WHERE a.patient_id = ?
                            ORDER BY a.appointment_date DESC, a.appointment_time DESC
                            LIMIT 10";
        
        $appointments_stmt = $db->prepare($appointments_sql);
        $appointments_stmt->execute([$id]);
        $patient['recent_appointments'] = $appointments_stmt->fetchAll();
        
        sendSuccess($patient);
        
    } catch (Exception $e) {
        sendError('Failed to fetch patient: ' . $e->getMessage(), 500);
    }
}

// Create new patient
function createPatient() {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Validate required fields
        $required_fields = ['first_name', 'last_name', 'date_of_birth', 'gender', 'phone'];
        validateRequired($required_fields, $input);
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate gender
        if (!in_array($data['gender'], ['Male', 'Female', 'Other'])) {
            sendError('Invalid gender value');
        }
        
        // Validate date of birth
        if (!strtotime($data['date_of_birth'])) {
            sendError('Invalid date of birth format');
        }
        
        // Validate email if provided
        if (!empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }
        
        // Generate patient ID
        $patient_id = generateId('PAT');
        
        // Check if patient ID already exists
        $check_sql = "SELECT id FROM patients WHERE patient_id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$patient_id]);
        
        while ($check_stmt->fetch()) {
            $patient_id = generateId('PAT');
            $check_stmt->execute([$patient_id]);
        }
        
        // Insert patient
        $sql = "INSERT INTO patients (
                    patient_id, first_name, last_name, date_of_birth, gender,
                    phone, email, address, emergency_contact_name, emergency_contact_phone,
                    blood_type, allergies, medical_history, insurance_provider, insurance_number
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = $db->prepare($sql);
        $result = $stmt->execute([
            $patient_id,
            $data['first_name'],
            $data['last_name'],
            $data['date_of_birth'],
            $data['gender'],
            $data['phone'],
            $data['email'] ?? null,
            $data['address'] ?? null,
            $data['emergency_contact_name'] ?? null,
            $data['emergency_contact_phone'] ?? null,
            $data['blood_type'] ?? null,
            $data['allergies'] ?? null,
            $data['medical_history'] ?? null,
            $data['insurance_provider'] ?? null,
            $data['insurance_number'] ?? null
        ]);
        
        if ($result) {
            $patient_id = $db->lastInsertId();
            logActivity(1, 'CREATE_PATIENT', ['patient_id' => $patient_id]);
            sendSuccess(['id' => $patient_id, 'patient_id' => $patient_id], 'Patient created successfully');
        } else {
            sendError('Failed to create patient');
        }
        
    } catch (Exception $e) {
        sendError('Failed to create patient: ' . $e->getMessage(), 500);
    }
}

// Update patient
function updatePatient($id) {
    global $db;
    
    try {
        $input = json_decode(file_get_contents('php://input'), true);
        
        if (!$input) {
            sendError('Invalid JSON input');
        }
        
        // Check if patient exists
        $check_sql = "SELECT id FROM patients WHERE id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        
        if (!$check_stmt->fetch()) {
            sendError('Patient not found', 404);
        }
        
        // Sanitize input
        $data = sanitizeInput($input);
        
        // Validate gender if provided
        if (isset($data['gender']) && !in_array($data['gender'], ['Male', 'Female', 'Other'])) {
            sendError('Invalid gender value');
        }
        
        // Validate date of birth if provided
        if (isset($data['date_of_birth']) && !strtotime($data['date_of_birth'])) {
            sendError('Invalid date of birth format');
        }
        
        // Validate email if provided
        if (isset($data['email']) && !empty($data['email']) && !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            sendError('Invalid email format');
        }
        
        // Build update query dynamically
        $update_fields = [];
        $params = [];
        
        $allowed_fields = [
            'first_name', 'last_name', 'date_of_birth', 'gender', 'phone', 'email',
            'address', 'emergency_contact_name', 'emergency_contact_phone', 'blood_type',
            'allergies', 'medical_history', 'insurance_provider', 'insurance_number', 'is_active'
        ];
        
        foreach ($allowed_fields as $field) {
            if (isset($data[$field])) {
                $update_fields[] = "$field = ?";
                $params[] = $data[$field];
            }
        }
        
        if (empty($update_fields)) {
            sendError('No valid fields to update');
        }
        
        $params[] = $id;
        
        $sql = "UPDATE patients SET " . implode(', ', $update_fields) . ", updated_at = NOW() WHERE id = ?";
        
        $stmt = $db->prepare($sql);
        $result = $stmt->execute($params);
        
        if ($result) {
            logActivity(1, 'UPDATE_PATIENT', ['patient_id' => $id]);
            sendSuccess(['id' => $id], 'Patient updated successfully');
        } else {
            sendError('Failed to update patient');
        }
        
    } catch (Exception $e) {
        sendError('Failed to update patient: ' . $e->getMessage(), 500);
    }
}

// Delete patient
function deletePatient($id) {
    global $db;
    
    try {
        // Check if patient exists
        $check_sql = "SELECT id, patient_id FROM patients WHERE id = ?";
        $check_stmt = $db->prepare($check_sql);
        $check_stmt->execute([$id]);
        $patient = $check_stmt->fetch();
        
        if (!$patient) {
            sendError('Patient not found', 404);
        }
        
        // Check if patient has appointments
        $appointments_sql = "SELECT COUNT(*) as count FROM appointments WHERE patient_id = ?";
        $appointments_stmt = $db->prepare($appointments_sql);
        $appointments_stmt->execute([$id]);
        $appointment_count = $appointments_stmt->fetch()['count'];
        
        if ($appointment_count > 0) {
            // Soft delete - mark as inactive instead of hard delete
            $sql = "UPDATE patients SET is_active = 0, updated_at = NOW() WHERE id = ?";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                logActivity(1, 'DEACTIVATE_PATIENT', ['patient_id' => $id]);
                sendSuccess(['id' => $id], 'Patient deactivated successfully (has existing appointments)');
            } else {
                sendError('Failed to deactivate patient');
            }
        } else {
            // Hard delete if no appointments
            $sql = "DELETE FROM patients WHERE id = ?";
            $stmt = $db->prepare($sql);
            $result = $stmt->execute([$id]);
            
            if ($result) {
                logActivity(1, 'DELETE_PATIENT', ['patient_id' => $id]);
                sendSuccess(['id' => $id], 'Patient deleted successfully');
            } else {
                sendError('Failed to delete patient');
            }
        }
        
    } catch (Exception $e) {
        sendError('Failed to delete patient: ' . $e->getMessage(), 500);
    }
}
?>
