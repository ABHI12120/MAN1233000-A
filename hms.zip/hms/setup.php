<?php
/**
 * Hospital Management System - Setup Script
 * This script helps with initial setup and configuration
 */

echo "🏥 Hospital Management System Setup\n";
echo "=====================================\n\n";

// Check PHP version
echo "Checking PHP version...\n";
if (version_compare(PHP_VERSION, '7.4.0', '<')) {
    echo "❌ PHP 7.4 or higher is required. Current version: " . PHP_VERSION . "\n";
    exit(1);
}
echo "✅ PHP version: " . PHP_VERSION . "\n\n";

// Check required extensions
echo "Checking PHP extensions...\n";
$required_extensions = ['pdo', 'pdo_mysql', 'json', 'openssl'];
$missing_extensions = [];

foreach ($required_extensions as $ext) {
    if (!extension_loaded($ext)) {
        $missing_extensions[] = $ext;
        echo "❌ Missing extension: $ext\n";
    } else {
        echo "✅ Extension loaded: $ext\n";
    }
}

if (!empty($missing_extensions)) {
    echo "\n❌ Please install missing extensions and try again.\n";
    exit(1);
}
echo "\n";

// Check file permissions
echo "Checking file permissions...\n";
$directories = ['api', 'css', 'js', 'database'];
$files = ['index.html', 'api/config.php'];

foreach ($directories as $dir) {
    if (is_dir($dir)) {
        if (is_readable($dir)) {
            echo "✅ Directory readable: $dir\n";
        } else {
            echo "❌ Directory not readable: $dir\n";
        }
    } else {
        echo "❌ Directory not found: $dir\n";
    }
}

foreach ($files as $file) {
    if (file_exists($file)) {
        if (is_readable($file)) {
            echo "✅ File readable: $file\n";
        } else {
            echo "❌ File not readable: $file\n";
        }
    } else {
        echo "❌ File not found: $file\n";
    }
}
echo "\n";

// Database connection test
echo "Testing database connection...\n";
try {
    require_once 'api/config.php';
    if ($db) {
        echo "✅ Database connection successful\n";
        
        // Check if tables exist
        $tables = ['users', 'patients', 'doctors', 'departments', 'appointments'];
        $existing_tables = [];
        
        foreach ($tables as $table) {
            $stmt = $db->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$table]);
            if ($stmt->fetch()) {
                $existing_tables[] = $table;
                echo "✅ Table exists: $table\n";
            } else {
                echo "❌ Table missing: $table\n";
            }
        }
        
        if (count($existing_tables) < count($tables)) {
            echo "\n⚠️  Some tables are missing. Please import the database schema.\n";
            echo "Run: mysql -u root -p hospital_management_system < database/schema.sql\n";
        }
        
    } else {
        echo "❌ Database connection failed\n";
    }
} catch (Exception $e) {
    echo "❌ Database error: " . $e->getMessage() . "\n";
}
echo "\n";

// Check sample data
echo "Checking sample data...\n";
try {
    if ($db) {
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM patients");
        $stmt->execute();
        $patient_count = $stmt->fetch()['count'];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM doctors");
        $stmt->execute();
        $doctor_count = $stmt->fetch()['count'];
        
        $stmt = $db->prepare("SELECT COUNT(*) as count FROM appointments");
        $stmt->execute();
        $appointment_count = $stmt->fetch()['count'];
        
        echo "✅ Patients: $patient_count\n";
        echo "✅ Doctors: $doctor_count\n";
        echo "✅ Appointments: $appointment_count\n";
        
        if ($patient_count == 0 || $doctor_count == 0) {
            echo "\n⚠️  No sample data found. The database schema includes sample data.\n";
        }
    }
} catch (Exception $e) {
    echo "❌ Error checking sample data: " . $e->getMessage() . "\n";
}
echo "\n";

// Web server check
echo "Checking web server configuration...\n";
if (isset($_SERVER['SERVER_SOFTWARE'])) {
    echo "✅ Web server: " . $_SERVER['SERVER_SOFTWARE'] . "\n";
} else {
    echo "⚠️  Web server information not available\n";
}

if (function_exists('apache_get_modules')) {
    $modules = apache_get_modules();
    if (in_array('mod_rewrite', $modules)) {
        echo "✅ mod_rewrite is enabled\n";
    } else {
        echo "⚠️  mod_rewrite is not enabled (required for clean URLs)\n";
    }
} else {
    echo "⚠️  Apache modules check not available\n";
}
echo "\n";

// Configuration check
echo "Checking configuration...\n";
$config_file = 'api/config.php';
if (file_exists($config_file)) {
    $config_content = file_get_contents($config_file);
    
    if (strpos($config_content, 'your-secret-key-here') !== false) {
        echo "⚠️  Default JWT secret key detected. Please change it in api/config.php\n";
    } else {
        echo "✅ JWT secret key configured\n";
    }
    
    if (strpos($config_content, 'your_password') !== false) {
        echo "⚠️  Default database password detected. Please update it in api/config.php\n";
    } else {
        echo "✅ Database password configured\n";
    }
} else {
    echo "❌ Configuration file not found: $config_file\n";
}
echo "\n";

// Final recommendations
echo "Setup Summary\n";
echo "=============\n";
echo "✅ PHP version and extensions are compatible\n";
echo "✅ File structure is correct\n";
echo "✅ Database connection is working\n";
echo "\n";

echo "Next Steps:\n";
echo "1. Open your web browser and navigate to: http://localhost/hms/\n";
echo "2. Test the application by adding a patient\n";
echo "3. Schedule an appointment\n";
echo "4. Explore the dashboard and reports\n";
echo "\n";

echo "For production deployment:\n";
echo "1. Change default passwords and secret keys\n";
echo "2. Enable HTTPS\n";
echo "3. Set up regular backups\n";
echo "4. Configure monitoring\n";
echo "\n";

echo "Documentation:\n";
echo "- README.md: Complete project documentation\n";
echo "- SETUP.md: Detailed setup instructions\n";
echo "- database/schema.sql: Database structure\n";
echo "\n";

echo "🎉 Setup completed successfully!\n";
?>
