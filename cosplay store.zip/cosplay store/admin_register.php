<?php
session_start();
include 'db.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password'];

    // First check if username already exists
    $check = mysqli_query($conn, "SELECT id FROM admin WHERE username='$username' LIMIT 1");
    if (mysqli_num_rows($check) > 0) {
        $msg = "⚠️ Username already exists. Please choose another.";
    } else {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert new admin
        $sql = "INSERT INTO admin (username, password) VALUES ('$username', '$hashed_password')";
        if (mysqli_query($conn, $sql)) {
            $msg = "✅ Admin registered successfully! <a href='admin_login.php'>Login here</a>";
        } else {
            $msg = "❌ Error: " . mysqli_error($conn);
        }
    }
}
?>
<!doctype html>
<html>
<head>
<title>Register Admin</title>
<link rel="stylesheet" href="styles/styles.css">
<style>
    body {
        font-family: Arial, sans-serif;
        background: #f5f7fb;
    }
    .register-box {
        max-width: 400px;
        margin: 80px auto;
        padding: 20px;
        background: #fff;
        border-radius: 12px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        text-align: center;
    }
    .register-box h2 {
        margin-bottom: 20px;
    }
    .register-box input {
        width: 90%;
        padding: 10px;
        margin: 10px 0;
        border: 1px solid #ccc;
        border-radius: 8px;
    }
    .register-box button {
        width: 95%;
        padding: 10px;
        background: #f97316;
        color: #fff;
        border: none;
        border-radius: 8px;
        cursor: pointer;
    }
    .register-box button:hover {
        background: #ea580c;
    }
    .msg {
        margin: 10px 0;
        color: green;
    }
    .error {
        margin: 10px 0;
        color: red;
    }
</style>
</head>
<body>
<div class="register-box">
    <h2>Admin Registration</h2>
    <?php 
if ($msg) {
    $cls = (strpos($msg, '⚠️') !== false || strpos($msg, '❌') !== false) ? 'error' : 'msg';
    echo "<p class='$cls'>$msg</p>";
}
?>	
    	<form method="post">
        <input type="text" name="username" placeholder="Enter username" required><br>
        <input type="password" name="password" placeholder="Enter password" required><br>
        <button type="submit">Register</button>
    </form>
    <p>Already an admin? <a href="admin_login.php">Login here</a></p>
</div>
</body>
</html>