<?php
session_start();
include 'db.php';
if(!isset($_SESSION['user_id'])) die('Please login first. <a href="login.php">Login</a>');
if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])) die('Cart is empty.');

$user_id = $_SESSION['user_id'];
$cart = $_SESSION['cart'];

foreach($cart as $product_id=>$qty){
    mysqli_query($conn,"INSERT INTO orders(user_id, product_id, quantity, status) VALUES($user_id, $product_id, $qty, 'pending')");
}

$_SESSION['cart'] = [];
echo "Order placed successfully! Cash on Delivery selected. <a href='index.php'>Go back</a>";
?>