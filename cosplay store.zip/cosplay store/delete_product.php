<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$id = isset($_GET['id']) ? (int) $_GET['id'] : null;
if ($id) {
    mysqli_query($conn, "DELETE FROM products WHERE id=".$id);
    header("Location: admin_dashboard.php?msg=Product deleted");
    exit();
} else {
    echo "Product ID missing.";
}