<?php
session_start();
include 'db.php';

// Restrict access to admins only
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$msg = '';
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if (!$id) {
    die("Product ID missing.");
}

// Fetch existing product
$res = mysqli_query($conn, "SELECT * FROM products WHERE id=".$id);
$product = mysqli_fetch_assoc($res);

if (!$product) {
    die("Product not found.");
}

// Update product
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $desc =mysqli_real_escape_string($conn, $_POST['description']);
    $price = $_POST['price'];
    $category = mysqli_real_escape_string($conn, $_POST['category']);
     // keep old image by default
    $image = $product['image'];
    // If new image uploaded
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "images/";
        $imageName = basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $image =  $targetDir.$imageName;
        } else {
            $msg = "Error uploading image!";
        }
    }

    $price = (float) $price;
    $sql = "UPDATE products SET name='$name', description='$desc' ,price=$price, category='$category', image='$image' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        $msg = "Product updated successfully!";
        // Refresh product data
        $res = mysqli_query($conn, "SELECT * FROM products WHERE id=".$id);
        $product = mysqli_fetch_assoc($res);
    } else {
        $msg = "Error: " . mysqli_error($conn);
    }
}
?>
<!doctype html>
<html>
<head>
<title>Edit Product</title>
<link rel="stylesheet" href="styles/styles.css">
</head>
<body>
<div class="edit-container">
    <?php if($msg) echo "<p>$msg</p>"; ?>
    <form method="post" enctype="multipart/form-data">
    <a href="admin_dashboard.php"> <h2>Admin Dashboard</h2> </a>
      <h2>Edit Product</h2>
      <input type="text" name="name" value="<?php echo $product['name']; ?>" required><br>
      <input type="text" name="description" value="<?php echo $product['description']; ?>" required><br> 	
      <input type="number" name="price" value="<?php echo $product['price']; ?>" required><br>
      <input type="text" name="category" value="<?php echo $product['category']; ?>" required><br>

      <p>Current Image:</p>
      <img src="<?php echo $product['image']; ?>" width="150"><br><br>

      <input type="file" name="image"><br>
      <small>Leave blank to keep existing image.</small><br><br>

      <button type="submit">Update Product</button>
      <p><a href="index.php">← Back to Store</a></p>
    </form>
</div>
</body>
</html>