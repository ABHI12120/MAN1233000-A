<?php
include 'db.php';
$cat = isset($_GET['category']) ? $_GET['category'] : 'all';
$search = isset($_GET['search']) ? $_GET['search'] : '';
// Fetch Products Catagory vise
$sql = "SELECT * FROM products";
if($cat != 'all') $sql .= " WHERE category='$cat'";
if($search != ''){
    $sql .= $cat=='all' ? " WHERE name LIKE '%$search%' OR description LIKE '%$search%'" : " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
}
$sql .= " ORDER BY id DESC";
$res = mysqli_query($conn,$sql);
$products = [];
while($row = mysqli_fetch_assoc($res)) $products[] = $row;
echo json_encode($products);
?>