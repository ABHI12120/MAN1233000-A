<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Handle delete user
if (isset($_GET['delete'])) {
    $userId = (int) $_GET['delete'];
    // Prevent deleting admin rows if stored in same users table (defensive)
    mysqli_query($conn, "DELETE FROM users WHERE id=$userId");
    header("Location: manage_users.php?msg=".urlencode("User deleted"));
    exit();
}

$users = mysqli_query($conn, "SELECT id, username, email, phone, state, pincode FROM users ORDER BY id DESC");
?>
<!doctype html>
<html>
<head>
    <title>Manage Users - Admin</title>
    <link rel="stylesheet" href="styles/styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin:10px; background:#f5f7fb; }
        h1 { text-align:center; color:#2b8aef; }
        .top-bar { text-align:center; margin:20px; }
        .btn { background:#f97316; color:#fff; padding:8px 16px; text-decoration:none; border-radius:6px; margin:5px; display:inline-block; }
        .btn:hover { background:#ea580c; }
        table { width:100%; border-collapse:collapse; background:#fff; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); overflow:hidden; }
        th, td { padding:12px; border-bottom:1px solid #ddd; text-align:center; }
        th { background:#f97316; color:#fff; }
        .msg { text-align:center; margin:10px; color:green; }
    </style>
    <script>
        function confirmDelete(){
            return confirm('Delete this user? This cannot be undone.');
        }
    </script>
    </head>
<body>
    <h1>Manage Users</h1>
    <div class="top-bar">
        <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
        <a href="manage_orders.php" class="btn">Manage Orders</a>
        <a href="logout.php" class="btn" style="background:#e74c3c;">Logout</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
        <p class="msg"><?php echo htmlspecialchars($_GET['msg']); ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Phone</th>
            <th>State</th>
            <th>Pincode</th>
            <th>Actions</th>
        </tr>
        <?php while($u = mysqli_fetch_assoc($users)): ?>
        <tr>
            <td><?php echo $u['id']; ?></td>
            <td><?php echo htmlspecialchars($u['username']); ?></td>
            <td><?php echo htmlspecialchars($u['email']); ?></td>
            <td><?php echo htmlspecialchars($u['phone']); ?></td>
            <td><?php echo htmlspecialchars($u['state']); ?></td>
            <td><?php echo htmlspecialchars($u['pincode']); ?></td>
            <td>
                <a class="btn" style="background:#e74c3c;" onclick="return confirmDelete()" href="manage_users.php?delete=<?php echo $u['id']; ?>">Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>


