<?php
session_start();
include 'db.php';

if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Update order status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['order_id'], $_POST['status'])) {
    $orderId = (int) $_POST['order_id'];
    $status = mysqli_real_escape_string($conn, $_POST['status']);
    mysqli_query($conn, "UPDATE orders SET status='$status' WHERE id=$orderId");
    header("Location: manage_orders.php?msg=".urlencode("Order updated"));
    exit();
}

// Fetch orders with product and user info if available
$orders = mysqli_query(
    $conn,
    "SELECT o.id, o.user_id, o.product_id, o.quantity, o.status, o.created_at,
            u.username, u.email,
            p.name AS product_name, p.price
     FROM orders o
     LEFT JOIN users u ON u.id = o.user_id
     LEFT JOIN products p ON p.id = o.product_id
     ORDER BY o.id DESC"
);
?>
<!doctype html>
<html>
<head>
    <title>Manage Orders - Admin</title>
    <link rel="stylesheet" href="styles/styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin:10px; background:#f5f7fb; }
        h1 { text-align:center; color:#2b8aef; }
        .top-bar { text-align:center; margin:20px; }
        .btn { background:#f97316; color:#fff; padding:8px 16px; text-decoration:none; border-radius:6px; margin:5px; display:inline-block; }
        .btn:hover { background:#ea580c; }
        table { width:100%; border-collapse:collapse; background:#fff; border-radius:8px; box-shadow:0 2px 8px rgba(0,0,0,0.1); overflow:hidden; }
        th, td { padding:12px; border-bottom:1px solid #ddd; text-align:center; }
        th { background:#f97316; color:#fff; }
        .msg { text-align:center; margin:10px; color:green; }
        form.inline { display:inline; }
        select { padding:6px; }
    </style>
</head>
<body>
    <h1>Manage Orders</h1>
    <div class="top-bar">
        <a href="admin_dashboard.php" class="btn">Back to Dashboard</a>
        <a href="manage_users.php" class="btn">Manage Users</a>
        <a href="logout.php" class="btn" style="background:#e74c3c;">Logout</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
        <p class="msg"><?php echo htmlspecialchars($_GET['msg']); ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th>
            <th>User</th>
            <th>Email</th>
            <th>Product</th>
            <th>Quantity</th>
            <th>Total</th>
            <th>Status</th>
            <th>Created</th>
            <th>Actions</th>
        </tr>
        <?php while($o = mysqli_fetch_assoc($orders)): ?>
        <tr>
            <td><?php echo $o['id']; ?></td>
            <td><?php echo htmlspecialchars($o['username'] ?: ('User #'.$o['user_id'])); ?></td>
            <td><?php echo htmlspecialchars($o['email'] ?: '-'); ?></td>
            <td><?php echo htmlspecialchars($o['product_name'] ?: ('Product #'.$o['product_id'])); ?></td>
            <td><?php echo (int)$o['quantity']; ?></td>
            <td>
                <?php 
                    $price = isset($o['price']) ? (float)$o['price'] : 0; 
                    $total = $price * (int)$o['quantity']; 
                    echo '₹'.number_format($total, 2);
                ?>
            </td>
            <td><?php echo htmlspecialchars($o['status']); ?></td>
            <td><?php echo htmlspecialchars($o['created_at'] ?? ''); ?></td>
            <td>
                <form method="post" class="inline">
                    <input type="hidden" name="order_id" value="<?php echo $o['id']; ?>">
                    <select name="status">
                        <?php 
                        $statuses = ['pending','processing','shipped','delivered','cancelled'];
                        foreach ($statuses as $s):
                        ?>
                            <option value="<?php echo $s; ?>" <?php if($o['status']===$s) echo 'selected'; ?>><?php echo ucfirst($s); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <button type="submit" class="btn">Update</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>


