-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 28, 2025 at 10:56 AM
-- Server version: 5.7.34
-- PHP Version: 8.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cosplay_costumes`
--

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `description`, `image`) VALUES
(1, 'Itachi Uchiha Costume', 'anime', 1599.00, 'High-quality Akatsuki cloak with red cloud design. Perfect for Naruto fans.', 'images/Itachi_chiha.webp'),
(2, 'Jacob Frye Cosplay', 'games', 2499.00, 'Authentic Victorian-era styled coat, vest, and accessories inspired by Assassin\'s Creed Syndicate.', 'images/jacobfrye.jpg'),
(3, 'Luffy Cosplay Outfit', 'anime', 1399.00, 'One Piece Monkey D. Luffy red vest, shorts, and straw hat costume.', 'images/LuffyCosplay.webp'),
(4, 'Smoke Cosplay', 'games', 1899.00, 'Inspired by Mortal Kombat character Smoke, includes ninja suit and mask.', 'images/smoke.jpg'),
(5, 'Red Ranger Costume', 'movies', 2199.00, 'Classic Power Rangers red ranger jumpsuit with helmet.', 'images/red_ranger.jpg'),
(6, 'Homelander Cosplay', 'movies', 2999.00, 'The Boys inspired Homelander costume with cape and muscle suit.', 'images/homelander.png'),
(7, 'Blue Ranger Costume', 'movies', 2199.00, 'Power Rangers Blue Ranger jumpsuit with helmet.', 'images/blue_ranger.jpg'),
(8, 'Spider-Man Suit', 'movies', 2799.00, 'Full-body Spider-Man costume made from stretchable fabric.', 'images/spiderman.jpg'),
(9, 'Wolverine Cosplay', 'movies', 2599.00, 'Leather jacket and claw set inspired by X-Men Wolverine.', 'images/wolverine.jpg'),
(10, 'Zenitsu Agatsuma Costume', 'anime', 1699.00, 'Demon Slayer Zenitsu cosplay with detailed kimono and accessories.', 'images/zenitsu.jpg'),
(11, 'Tanjiro Kamado Costume', 'anime', 1799.00, 'Demon Slayer Tanjiro cosplay with signature checkered haori and sword.', 'images/tanjiro.jpg'),
(12, 'Batman Costume', 'movies', 3199.00, 'Dark Knight inspired full suit with mask and cape.', 'images/Batman.webp'),
(20, 'Mario', 'games', 2599.00, 'Mario is the iconic red-capped plumber from Nintendoâ€™s Super Mario series.', 'images/Mario.jpg'),
(14, 'Captain America Suit', 'movies', 2899.00, 'Marvel Captain America full costume with shield.', 'images/captain_america.jpg'),
(15, 'Satoru Gojo Costume', 'anime', 1899.00, 'Jujutsu Kaisen Gojo cosplay with blindfold and black uniform.', 'images/SatoruGojo.webp'),
(16, 'Green Ranger Costume', 'movies', 2299.00, 'Classic Power Rangers Green Ranger suit with helmet.', 'images/green_ranger.jpg'),
(17, 'Obanai Iguro Costume', 'anime', 1799.00, 'Demon Slayer Obanai cosplay with striped haori and snake accessory.', 'images/obenai_iguro.jpg'),
(18, 'Deadpool Suit', 'movies', 2999.00, 'High-quality Deadpool full-body costume with belt and accessories.', 'images/deadpool.jpg'),
(19, 'God of War Kratos Cosplay', 'games', 3299.00, 'Detailed Kratos costume with armor pieces and body paint.', 'images/god_of_war.jpg'),
(21, 'Luijgi', 'games', 2699.00, 'Luigi is Marioâ€™s younger brother, taller and usually dressed in green', 'images/Luigi.jpg'),
(22, 'Atreus', 'games', 2899.00, 'Atreus is a key character in God of War (2018) and its sequel. He is the young son of Kratos and shows a mix of curiosity, intelligence, and compassion.', 'images/Atreus.jpg'),
(23, 'Geo', 'anime', 2799.00, 'This is demons slayer one of popular character', 'images/geo.jpg'),
(24, 'goku', 'anime', 2899.00, 'Son Goku, from *Dragon Ball*, is a Saiyan warrior with a cheerful personality and insatiable love for training and fighting strong opponents.', 'images/goku.jpg'),
(25, 'naruto', 'anime', 2999.00, 'Naruto Uzumaki is the main character of the anime and manga *Naruto*. He is a spirited ninja with dreams of becoming Hokage, the leader of his village.', 'images/naruto.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;