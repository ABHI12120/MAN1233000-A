<?php
session_start();
include 'db.php';

// Initialize filters
$search = "";
$category = "";

// Read query params
if (isset($_GET['q'])) {
    $search = mysqli_real_escape_string($conn, $_GET['q']);
}
if (isset($_GET['category'])) {
    $category = mysqli_real_escape_string($conn, $_GET['category']);
}

// Build query
$sql = "SELECT * FROM products WHERE 1"; 

if ($search !== "") {
    $sql .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
}

if ($category !== "" && $category !== "all") {
    $sql .= " AND category = '$category'";
}

$sql .= " ORDER BY id DESC";
$res = mysqli_query($conn, $sql);
$products = mysqli_fetch_all($res, MYSQLI_ASSOC);
?>
	<?php
	// Helper to resolve image path reliably against existing files in images/
	function resolveImagePath($image)
	{
		$base = basename($image); // handle values like "images/foo.jpg" or "foo.jpg"
		$name = pathinfo($base, PATHINFO_FILENAME);
		$candidates = [];
		// Try the basename as-is under images/
		$candidates[] = "images/" . $base;
		// Try common extensions
		$extensions = ['jpg','jpeg','png','webp','gif','JPG','JPEG','PNG','WEBP','GIF'];
		foreach ($extensions as $ext) {
			$candidates[] = "images/{$name}.{$ext}";
		}
		foreach ($candidates as $cand) {
			if (file_exists($cand)) {
				return $cand;
			}
		}
		// Last resort: loose match by name fragment
		foreach (glob("images/*") as $file) {
			if (stripos(pathinfo($file, PATHINFO_FILENAME), $name) !== false) {
				return $file;
			}
		}
		// Fallback to images/<basename> even if missing
		return "images/" . $base;
	}
	?>
	
<!doctype html>
<html>
<head>
<title>Cosplay Costume Store</title>
<link rel="stylesheet" href="styles/styles.css">
	<script defer src="js/main.js"></script>
</head>
<body>
<header>
<div class="container top">
	
  <div class="brand">
    <div class="logo"><a href="index.php">CS</a></div>
    <div>
      <div style="font-weight:700">Cosplay Costume Store</div>
   
  </div>
  
  <div class="search">
    <form method="get" action="index.php">
      <input id="search" name="q" value="<?php echo htmlspecialchars($search); ?>" 
             placeholder="Search products, e.g. naruto" />
      <button type="submit" class="btn">🔎</button>
    </form>
  </div>
  </div>
  <nav class="navbar">
    <ul>
      <li><a href="login.php">Login</a></li>
      <li><a href="admin_login.php">Admin</a></li>
      <li><a href="logout.php">Logout</a></li>
      <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
    </ul>
  </nav>
</div>
</header>

<section class="hero">
      <div class="hero-inner">
        <div class="hero-copy">
          <h1>Welcome to Cosplay Costume Store — authentic, creative, & fun</h1>
<p>Browse our curated selection of cosplay costumes, wigs, and accessories. Popular characters and outfits are displayed on the first page for easy browsing and demo.</p>
        </div>
        </div>
    </section>
    
<section class="categories">
  <form method="get" action="index.php" id="category-search-form">
    <div class="category-grid">
      <button type="submit" name="category" value="all" class="category-card <?php echo $category=='all'||$category=='' ? 'active' : ''; ?>">All</button>
      <button type="submit" name="category" value="anime" class="category-card <?php echo $category=='anime' ? 'active' : ''; ?>">Anime</button>
      <button type="submit" name="category" value="games" class="category-card <?php echo $category=='games' ? 'active' : ''; ?>">Games</button>
      <button type="submit" name="category" value="movies" class="category-card <?php echo $category=='movies' ? 'active' : ''; ?>">Movies</button>
    </div>
  </form>
</section>

<main class="container">
<section class="grid">
<?php if (count($products) > 0): ?>
    <?php foreach($products as $p): ?>
    <div class="card">
        <img src="<?php echo htmlspecialchars(resolveImagePath($p['image'])); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>">
        <div class="meta">
            <h3 class="title"><?php echo $p['name']; ?></h3>
            <p class="desc"><?php echo $p['description']; ?></p>
            <div class="price-row">
                <div class="price">₹<?php echo $p['price']; ?></div>
             <button type="button" class="add-to-cart" data-id="<?php echo $p['id']; ?>">Add</button>
            </div>
        </div>
    </div>
    <?php endforeach; ?>
<?php else: ?>
    <p>No products found for "<b><?php echo htmlspecialchars($search); ?></b>".</p>
<?php endif; ?>
</section>

<footer>
<p>© Cosplay Costumes Store | <a href="index.php">Home</a> | <a href="about.php">About us</a> | <a href="contact.php">Contact</a></p>
</footer>
</main>
</body>
</html>