<?php
session_start();
include 'db.php';  // include your database connection

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Insert into DB
    $sql = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";
    if (mysqli_query($conn, $sql)) {
        $msg = "✅ Thank you, $name! Your message has been received.";
    } else {
        $msg = "❌ Error: " . mysqli_error($conn);
    }
}
?>
<!doctype html>
<html>
<head>
<title>Contact Us - Cosplay Costume Store</title>
<link rel="stylesheet" href="styles/styles.css">
</head>
<body>
<header>
<div class="container top">
  <div class="brand">
    <div class="logo"><a href="index.php">CS</a></div>
    <div>
      <div style="font-weight:700"> Cosplay Costume Store</div>
    </div>
  </div>
  <nav class="navbar">
    <ul>
      <li><a href="login.php">Login</a></li>
      <li><a href="logout.php">Logout</a></li>	
      <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
    </ul>
  </nav>
</div>
</header>

<div class="contact">
<h1>Contact Us</h1>

<form method="post">
<label>Name:</label><br>
<input type="text" name="name" placeholder="Enter Your Name" required><br>
<label>Email:</label><br>
<input type="email" name="email" placeholder="Enter Your Email" required><br>
<label>Message:</label><br>
<textarea name="message" placeholder="Enter the reason for contact" required></textarea><br>
<button type="submit" class="bttn">Send</button>
</form>
<?php if($msg) echo "<p style='color:green;'>$msg</p>"; ?>
</div>

<footer>
<p>© Cosplay Costume Store | <a href="index.php">Home</a> | <a href="about.php">About</a> | <a href="contact.php">Contact</a></p>
</footer>
</body>
</html>