<?php
session_start();
include 'db.php';

// Fetch products
$res = mysqli_query($conn, "SELECT * FROM  Coustmes");
$coustmes = mysqli_fetch_all($res, MYSQLI_ASSOC);
?>
<!doctype html>
<html>
<head>
<title>Cosplay Coustmes Store</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
<header>
<div class="container top">
  <div class="brand">
    <div class="logo"><a href="#">PS</a></div>
    <div>
      <div style="font-weight:700">Cosplay Coustmes Store</div>
      <div style="font-size:12px;color:#6b7280">Everything your pet needs</div>
    </div>
  </div>
  <div class="search">
    <input id="search" placeholder="Search products, e.g. dog food" />
  </div>
  <nav class="navbar">
    <ul>
      <li><a href="login.php">Login</a></li>
      <li><a href="admin_login.php">Admin</a></li>
      <li><a href="logout.php">Logout</a></li>
      <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
    </ul>
  </nav>
</div>
</header>
<section class="hero">
      <div class="hero-inner">
        <div class="hero-copy">
          <h1>Welcome to Cosplay Coustmes Store — simple, healthy, & happy</h1>
          <p>Browse our curated selection of pet foods, toys, and accessories. Products are shown on the first page for easy grading and demo.</p>
        </div>
        <div class="hero-img" aria-hidden="true"></div>
      </div>
    </section>
<main class="container">
<section class="grid">
<?php foreach($Coustmes as $p): ?>
<div class="card">
    <img src="<?php echo $p['image']; ?>" alt="<?php echo $p['name']; ?>">
    <div class="meta">
        <h3 class="title"><?php echo $p['name']; ?></h3>
        <p class="desc"><?php echo $p['description']; ?></p>
        <div class="price-row">
            <div class="price">₹<?php echo $p['price']; ?></div>
            <form method="post" action="cart.php">
                <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                <button type="submit" class="add">Add</button>
            </form>
        </div>
    </div>
</div>

<?php endforeach; ?>
</section>
<footer>
<p>© Cosplay Coustmes Store | <a href="index.php">Home</a> | <a href="about.php">About us</a> | <a href="contact.php">Contact</a></p>
</footer>
</main>
</body>
</html>