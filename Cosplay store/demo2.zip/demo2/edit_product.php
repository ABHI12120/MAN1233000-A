<?php
session_start();
include 'db.php';

// Restrict access to admins only
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$msg = '';
$id = $_GET['id'] ?? null;

if (!$id) {
    die("Product ID missing.");
}

// Fetch existing product
$res = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
$product = mysqli_fetch_assoc($res);

if (!$product) {
    die("Product not found.");
}

// Update product
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    $image = $product['image']; // keep old image by default

    // If new image uploaded
    if (!empty($_FILES['image']['name'])) {
        $targetDir = "images/";
        $imageName = time() . "_" . basename($_FILES["image"]["name"]);
        $targetFile = $targetDir . $imageName;

        if (move_uploaded_file($_FILES["image"]["tmp_name"], $targetFile)) {
            $image = $imageName;
        } else {
            $msg = "Error uploading image!";
        }
    }

    $sql = "UPDATE products SET name='$name', price='$price', category='$category', image='$image' WHERE id='$id'";
    if (mysqli_query($conn, $sql)) {
        $msg = "Product updated successfully!";
        // Refresh product data
        $res = mysqli_query($conn, "SELECT * FROM products WHERE id='$id'");
        $product = mysqli_fetch_assoc($res);
    } else {
        $msg = "Error: " . mysqli_error($conn);
    }
}
?>
<!doctype html>
<html>
<head>
<title>Edit Product</title>
 <link rel="stylesheet" href="styles.css">
</head>
<body>
<h2>Edit Product</h2>
<?php if($msg) echo "<p>$msg</p>"; ?>
<form method="post" enctype="multipart/form-data">
<h2>Edit Product</h2>
    <input type="text" name="name" value="<?php echo $product['name']; ?>" required><br>
    <input type="number" name="price" value="<?php echo $product['price']; ?>" required><br>
    <input type="text" name="category" value="<?php echo $product['category']; ?>" required><br>

    <p>Current Image:</p>
    <img src="uploads/<?php echo $product['image']; ?>" width="150"><br><br>

    <input type="file" name="image"><br>
    <small>Leave blank to keep existing image.</small><br><br>

    <button type="submit">Update Product</button>
</form>
</body>
</html>