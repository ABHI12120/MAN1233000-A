<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>About Us - Cosplay Coustmes Store</title>
<!--<link rel="stylesheet" href="styles.css">-->
	  <style>
    :root {
      --accent: #2b8aef;
      --muted: #6b7280;
      --bg: #f5f7fb;
      --text: #333;
    }

    body {
      font-family: Arial, sans-serif;
      background-color: var(--bg);
      color: var(--text);
      margin: 0;
      padding: 0;
    }

    /* Top bar */
    .container.top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 20px;
      background-color: #fff;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
    }

    .brand{
      display:flex;
      align-items:center;
      gap:12px
      }
      
    .logo{
      width:52px;
      height:52px;border-radius:6px;
      background:linear-gradient(135deg,var(--accent), cyan);
      display:flex;
      align-items:center;
      justify-content:center;
      color:#fff;
      font-weight:700
      }
      
    .logo a{
      color:white;
      text-decoration: none;
    }

    nav.navbar ul {
      list-style: none;
      display: flex;
      gap: 20px;
      margin: 0;
      padding: 0;
    }

    nav.navbar ul li a {
      text-decoration: none;
      color: var(--muted);
      font-weight: 600;
      transition: color 0.3s;
    }

    nav.navbar ul li a:hover {
      color: var(--accent);
    }

    /* Page content */
    .content {
      max-width: 1000px;
      margin: 40px auto;
      padding: 0 20px;
    }

    .content h1 {
      color: var(--accent);
      margin-bottom: 20px;
    }

    .content p {
      line-height: 1.6;
      margin-bottom: 15px;
    }

    /* Highlight section */
    .highlight {
      background-color: #fff;
      padding: 20px;
      border-left: 5px solid var(--accent);
      margin: 20px 0;
    }
  </style>
</style>
</head>
<body>

  <!-- Top bar -->
  <div class="container top">
    <div class="brand">
      <div class="logo"><a href="index.html">PS</a></div>
      <div>
        <div style="font-weight:700">Cosplay Coustmes Store</div>
        <div style="font-size:12px;color:var(--muted)">Everything your pet needs</div>
      </div>
    </div>

    <nav class="navbar">
      <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="about.php">About Us</a></li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
      </ul>
    </nav>
  </div>

  <!-- About content -->
  <div class="content">
    <h1>About Us</h1>

    <p>Welcome to <strong>Pet Products Store</strong>! We are passionate about pets and dedicated to providing the best products for your furry friends. From nutritious food to fun toys, our store is a one-stop destination for all pet needs.</p>

    <div class="highlight">
      <h2>Our Mission</h2>
      <p>To ensure every pet has access to high-quality products that promote health, happiness, and well-being. We aim to make pet care easy and enjoyable for pet owners everywhere.</p>
    </div>

    <div class="highlight">
      <h2>Our Vision</h2>
      <p>To become the most trusted and convenient pet products store, fostering strong relationships with our customers and their beloved pets.</p>
    </div>

    <div class="highlight">
      <h2>Why Choose Us?</h2>
      <ul>
        <li>Wide variety of products for dogs, cats, birds, and more.</li>
        <li>High-quality, trusted brands.</li>
        <li>Fast and reliable service.</li>
        <li>Customer satisfaction is our priority.</li>
      </ul>
    </div>
  </div>
<footer>
<p>© Pet Products Store | <a href="index.php">Home</a> | <a href="about.php">About</a> | <a href="contact.php">Contact</a></p>
</footer>
</body>
</html>