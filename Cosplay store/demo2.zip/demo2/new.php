<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cosplay Coustmes Store</title>
<style>
:root {--accent:#2b8aef;--muted:#6b7280;--card:#fff;--bg:#f5f7fb}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial;background:var(--bg);color:#111}
header{background:#fff;padding:20px 24px;box-shadow:0 1px 4px rgba(15,23,42,0.06);position:sticky;top:0;z-index:10}
.container{max-width:1100px;margin:0 auto}
.top{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.brand{display:flex;align-items:center;gap:12px}
.logo{width:52px;height:52px;border-radius:6px;background:linear-gradient(135deg,var(--accent), cyan);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700}
.logo a{color:white;text-decoration:none}
.search{flex:1;min-width:180px}
.search input{width:100%;padding:10px 14px;border-radius:6px;border:1px solid #e6e9ef}
.navbar{display:flex;align-items:center;gap:20px;flex-wrap:wrap}
.navbar ul{list-style:none;display:flex;gap:16px;margin:0;padding:0;flex-wrap:wrap}
.navbar ul li a{text-decoration:none;color: var(--muted);font-weight:600;transition:color 0.3s}
.navbar ul li a:hover{color: var(--accent)}
.btn{background:var(--accent);color:#fff;padding:9px 12px;border-radius:4px;border:none;cursor:pointer;transition:background 0.3s}
.btn:hover{background:#1d5fbf}
.hero{background:linear-gradient(90deg,#f8fbff,#ffffff);padding:36px 24px;margin-top:18px;border-radius:12px}
.hero-inner{display:flex;gap:24px;align-items:center;flex-wrap:wrap}
.hero-copy h1{margin:0;font-size:28px}
.hero-copy p{margin:8px 0;color:var(--muted)}
.hero-img{width:180px;height:140px;border-radius:4px;background-image:url('https://picsum.photos/id/237/600/400');background-size:cover;background-position:center;flex-shrink:0}
.filters{display:flex;gap:8px;margin:18px 10px;flex-wrap:wrap}
.chip{padding:8px 12px;border-radius:5px;background:#fff;border:1px solid #e6e9ef;cursor:pointer;transition:all 0.2s}
.chip.active{background:var(--accent);color:#fff;border-color:transparent}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));margin:0px 9px;gap:18px}
.card{background:var(--card);border-radius:6px;padding:10px;box-shadow:0 6px 18px rgba(16,24,40,0.04);display:flex;flex-direction:column;transition:transform 0.2s}
.card:hover{transform:translateY(-4px)}
.card img{width:100%;height:140px;object-fit:cover;border-radius:5px}
.meta{padding:10px 4px;flex:1;display:flex;flex-direction:column}
.title{font-weight:600;margin:0 0 6px 0;font-size:14px}
.desc{margin:0;color:var(--muted);font-size:13px;flex:1}
.price-row{display:flex;align-items:center;justify-content:space-between;margin-top:10px}
.price{font-weight:700}
.add{padding:8px 10px;border-radius:6px;border:none;background:orange;color:#fff;cursor:pointer;transition:background 0.3s}
.add:hover{background:#e68a00}
.cart-btn{position:fixed;right:20px;bottom:20px;background:#111;color:#fff;padding:12px 16px;border-radius:6px;box-shadow:0 8px 24px rgba(2,6,23,0.2);z-index:20;cursor:pointer}
footer{padding:30px 24px;margin-top:28px;color:var(--muted);text-align:center;background:#111}
footer a{text-decoration:none;color:#fff;margin:0 6px}
footer a:hover{color:var(--accent)}
@media(max-width:640px){.hero-inner{flex-direction:column;align-items:flex-start}.hero-img{width:100%;height:160px}.top{flex-direction:column;align-items:flex-start}.navbar ul{flex-direction:column;gap:8px}}
</style>
</head>
<body>

<header>
  <div class="container top">
    <div class="brand">
      <div class="logo"><a href="#">PS</a></div>
      <div>
        <div>Cosplay Costumes  Store</div>
        <div>Everything your pet needs</div>
      </div>
    </div>

    <div class="search">
      <input id="search" placeholder="Search products, e.g. dog food">
    </div>

    <nav class="navbar">
      <ul>
        <li><a href="#">Home</a></li>
        <li><a href="about.html">About Us</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
      <button class="btn" id="viewAllBtn">View All</button>
    </nav>
  </div>
</header>

<main class="container">
  <section class="hero">
    <div class="hero-inner">
      <div class="hero-copy">
        <h1>Welcome to Pet Products Store — simple, healthy, & happy</h1>
        <p>Browse our curated selection of pet foods, toys, and accessories.</p>
      </div>
      <div class="hero-img" aria-hidden="true"></div>
    </div>
  </section>

  <section style="margin-top:18px">
    <div class="filters" id="categoryChips">
      <div class="chip active" data-cat="all">All</div>
      <div class="chip" data-cat="food">Food</div>
      <div class="chip" data-cat="toys">Toys</div>
      <div class="chip" data-cat="accessories">Accessories</div>
    </div>
    <div class="grid" id="productGrid"></div>
  </section>
</main>

<button class="cart-btn" id="cartBtn">Cart (<span id="cartCount">0</span>)</button>

<footer>
  <p>© Cosplay Coustmes store |
    <a href="#">Home</a> |
    <a href="about.html">About Us</a> |
    <a href="contact.html">Contact</a>
  </p>
</footer>

<template id="productTpl">
  <div class="card">
    <img src="" alt="product">
    <div class="meta">
      <h3 class="title"></h3>
      <p class="desc"></p>
      <div class="price-row">
        <div class="price"></div>
        <button class="add">Add</button>
      </div>
    </div>
  </div>
</template>

<script>
const PRODUCTS=[
{ id: 1,  name: "Naruto Uzumaki Costume",      price: "$39.99", category: "Anime", description: "Authentic Naruto Uzumaki costume for cosplay events.", image: "images/placeholder.png" },
  { id: 2,  name: "Sailor Moon Costume",         price: "$44.99", category: "Anime", description: "Classic Sailor Moon outfit.", image: "images/placeholder.png" },
  { id: 3,  name: "Goku Gi (Adult)",             price: "$49.99", category: "Anime", description: "Orange gi for Saiyan fans.", image: "images/placeholder.png" },
  { id: 4,  name: "Mikasa Ackerman Jacket",      price: "$54.99", category: "Anime", description: "Survey Corps jacket replica.", image: "images/placeholder.png" },
  { id: 5,  name: "Demon Slayer Kimono",         price: "$45.99", category: "Anime", description: "Stylish patterned kimono set.", image: "images/placeholder.png" },
  { id: 6,  name: "Spider-Man Suit",             price: "$49.99", category: "Marvel", description: "Spider-Man cosplay suit.", image: "images/placeholder.png" },
  { id: 7,  name: "Iron Man Armor",              price: "$99.99", category: "Marvel", description: "Iron Man armor replica.", image: "images/placeholder.png" },
  { id: 8,  name: "Captain Marvel Jacket",       price: "$59.99", category: "Marvel", description: "Stylish Captain Marvel jacket.", image: "images/placeholder.png" },
  { id: 9,  name: "Black Panther Outfit",        price: "$79.99", category: "Marvel", description: "Vibranium-inspired suit.", image: "images/placeholder.png" },
  { id:10,  name: "Falcon Wings (Prop)",         price: "$39.99", category: "Marvel", description: "Lightweight wing props.", image: "images/placeholder.png" },
  { id:11,  name: "Geralt of Rivia Costume",     price: "$69.99", category: "Game",  description: "The Witcher Geralt costume.", image: "images/placeholder.png" },
  { id:12,  name: "Zelda Princess Dress",        price: "$59.99", category: "Game",  description: "Princess Zelda dress.", image: "images/placeholder.png" },
  { id:13,  name: "Link Tunic & Cap",            price: "$49.99", category: "Game",  description: "Link's green tunic and cap.", image: "images/placeholder.png" },
  { id:14,  name: "Mario Overalls",              price: "$34.99", category: "Game",  description: "Classic Mario overalls and hat.", image: "images/placeholder.png" },
  { id:15,  name: "Lara Croft Outfit",           price: "$54.99", category: "Game",  description: "Adventurer outfit set.", image: "images/placeholder.png" },
  { id:16,  name: "Darth Vader Costume",         price: "$79.99", category: "Game",  description: "Iconic Darth Vader costume.", image: "images/placeholder.png" },
  { id:17,  name: "Harry Potter Robe",           price: "$29.99", category: "Anime", description: "House robe and tie.", image: "images/placeholder.png" },
  { id:18,  name: "Daenerys Dress",              price: "$69.99", category: "Anime", description: "Flowing dress inspired by Daenerys.", image: "images/placeholder.png" },
  { id:19,  name: "Eowyn Battle Dress",          price: "$64.99", category: "Anime", description: "Rugged battle-ready gown.", image: "images/placeholder.png" },
  { id:20,  name: "Prop Sword (Foam)",           price: "$24.99", category: "Game",  description: "Lightweight prop sword for cosplay.", image: "images/placeholder.png" }
];
];

const grid=document.getElementById('productGrid');
const tpl=document.getElementById('productTpl');
const chips=Array.from(document.querySelectorAll('.chip'));
const searchInput=document.getElementById('search');
const cartCountEl=document.getElementById('cartCount');

function formatPrice(p){return '₹'+p;}
function getCart(){return JSON.parse(localStorage.getItem('waggy_cart')||'{}');}
function setCart(c){localStorage.setItem('waggy_cart',JSON.stringify(c)); updateCartCount();}
function updateCartCount(){const cart=getCart();const count=Object.values(cart).reduce((s,n)=>s+n,0);cartCountEl.textContent=count;}

function renderProducts(filterCat='all',q=''){
grid.innerHTML='';
const f=PRODUCTS.filter(p=>(filterCat==='all'||p.cat===filterCat)&&(q===''||(p.name+' '+p.desc).toLowerCase().includes(q.toLowerCase())));
f.forEach(p=>{
let node=tpl.content.cloneNode(true);
node.querySelector('img').src=p.img;
node.querySelector('img').alt=p.name;
node.querySelector('.title').textContent=p.name;
node.querySelector('.desc').textContent=p.desc;
node.querySelector('.price').textContent=formatPrice(p.price);
node.querySelector('.add').addEventListener('click',()=>{addToCart(p.id);});
grid.appendChild(node);
});
if(f.length===0)grid.innerHTML='<div style="padding:36px;color:var(--muted)">No products match your search.</div>';
}

function addToCart(id){const cart=getCart();cart[id]=(cart[id]||0)+1;setCart(cart);alert('Added to cart');}

chips.forEach(c=>c.addEventListener('click',e=>{
chips.forEach(x=>x.classList.remove('active'));
e.target.classList.add('active');
renderProducts(e.target.dataset.cat,searchInput.value.trim());
}));

searchInput.addEventListener('input',()=>{const active=document.querySelector('.chip.active').dataset.cat;renderProducts(active,searchInput.value.trim());});

document.getElementById('cartBtn').addEventListener('click',()=>{
const cart=getCart();
const lines=Object.keys(cart).map(id=>{const p=PRODUCTS.find(x=>x.id==id);return `${p.name} x ${cart[id]} — ${formatPrice(p.price*cart[id])}`});
const total=Object.keys(cart).reduce((s,id)=>s+PRODUCTS.find(x=>x.id==id).price*cart[id],0);
const msg=lines.length?(lines.join('\n')+'\n\nTotal: '+formatPrice(total)+'\n\nCash on Delivery only for this demo.'):'Your cart is empty.';
alert(msg);
});

document.getElementById('viewAllBtn').addEventListener('click',()=>{renderProducts('all','');searchInput.value='';chips.forEach(x=>x.classList.remove('active'));chips[0].classList.addchips[0].classList.add('active');});

// Initial render
renderProducts('all','');
updateCartCount();
</script>

</body>
</html>