<?php
session_start();
include 'db.php';

// Add to cart (from product page)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['product_id']) && !isset($_POST['checkout'])) {
    $id = intval($_POST['product_id']);
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    if (isset($_SESSION['cart'][$id])) $_SESSION['cart'][$id]++;
    else $_SESSION['cart'][$id] = 1;

    // Stay on same page instead of showing empty cart directly
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
}

// Checkout (COD)
$msg = '';
if(isset($_POST['checkout'])){
    // Check login first
    if(!isset($_SESSION['user_id'])){
        header("Location: login.php?redirect=cart.php");
        exit;
    }

    if(!isset($_SESSION['cart']) || empty($_SESSION['cart'])){
        $msg = "Cart is empty!";
    } else {
        $user_id = $_SESSION['user_id']; // Use logged in user's ID
        foreach($_SESSION['cart'] as $pid => $qty){
            mysqli_query($conn, "INSERT INTO orders (user_id, product_id, quantity) 
                                VALUES ($user_id, $pid, $qty)");
        }
        unset($_SESSION['cart']);
        $msg = "Order placed successfully!";
    }
}

// Fetch cart items
$cart_products = [];
$total = 0;
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $ids = implode(',', array_keys($_SESSION['cart']));
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id IN ($ids)");
    while ($row = mysqli_fetch_assoc($res)) {
        $row['qty'] = $_SESSION['cart'][$row['id']];
        $row['subtotal'] = $row['price'] * $row['qty'];
        $total += $row['subtotal'];
        $cart_products[] = $row;
    }
}
?>
<!doctype html>
<html>
<head>
<title>Cart - Pet Products Store</title>
<link rel="stylesheet" href="styles.css">
	<style>
		p{
		 justify-content: center;
		}
		</style>
</head>
<body>
<header>
<div class="container top">
  <div class="brand">
    <div class="logo"><a href="#">PS</a></div>
    <div>
      <div style="font-weight:700">Pet Products Store</div>
      <div style="font-size:12px;color:#6b7280">Everything your pet needs</div>
    </div>
  </div>
  <nav class="navbar">
    <ul>
      <li><a href="index.php">Home</a></li>
      <li><a href="about.php">About Us</a></li>
      <li><a href="contact.php">Contact</a></li>
      <li><a href="login.php">Login</a></li>
      <li><a href="logout.php">Logout</a></li>
      <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
    </ul>
  </nav>
</div>
</header>
<h1>Your Cart</h1>

<?php if (!empty($cart_products)): ?>
<table>
<tr><th>Product</th><th>Qty</th><th>Price</th><th>Subtotal</th></tr>
<?php foreach($cart_products as $p): ?>
<tr>
<td><?php echo $p['name']; ?></td>
<td><?php echo $p['qty']; ?></td>
<td>₹<?php echo $p['price']; ?></td>
<td>₹<?php echo $p['subtotal']; ?></td>
</tr>
<?php endforeach; ?>
<tr><td colspan="3"><strong>Total</strong></td><td>₹<?php echo $total; ?></td></tr>
</table>

<form method="post">
    <button type="submit" name="checkout" class="btn">Checkout (COD)</button>
</form>

<?php else: ?>
<p>Your cart is empty.</p>
<?php endif; ?>

<?php if($msg) echo "<p class='msg'>$msg</p>"; ?>
<footer>
    <p>&copy; <?php echo date("Y"); ?> Pet Products Store. All rights reserved.</p>
</footer>

</div>
</body>
</html>