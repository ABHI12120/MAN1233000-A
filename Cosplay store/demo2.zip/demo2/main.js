// ---------- Utilities ----------
function formatPrice(p) { return '₹' + p.toString(); }

function getCart() { return JSON.parse(localStorage.getItem('waggy_cart') || '{}'); }
function setCart(c) { localStorage.setItem('waggy_cart', JSON.stringify(c)); updateCartCount(); }
function updateCartCount() {
    const cart = getCart();
    const count = Object.values(cart).reduce((s, n) => s + n, 0);
    const cartCountEl = document.getElementById('cartCount');
    if (cartCountEl) cartCountEl.textContent = count;
}

// ---------- Render Products ----------
async function fetchProducts(category = 'all', query = '') {
    // Use fetch_products.php for dynamic products or fallback to hardcoded array
    try {
        let url = 'fetch_products.php?category=' + category + '&search=' + encodeURIComponent(query);
        let res = await fetch(url);
        let products = await res.json();
        return products;
    } catch (e) {
        console.error('Error fetching products:', e);
        return [];
    }
}

async function renderProducts(category = 'all', query = '') {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    const tpl = document.getElementById('productTpl');
    grid.innerHTML = '';
    const products = await fetchProducts(category, query);

    if (products.length === 0) {
        grid.innerHTML = '<div style="padding:36px;color:var(--muted)">No products match your search.</div>';
        return;
    }

    products.forEach(p => {
        const node = tpl.content.cloneNode(true);
        const img = node.querySelector('img');
        img.src = p.img || p.image;
        img.alt = p.name;
        node.querySelector('.title').textContent = p.name;
        node.querySelector('.desc').textContent = p.desc || p.description;
        node.querySelector('.price').textContent = formatPrice(p.price);

        const btn = node.querySelector('.add');
        btn.addEventListener('click', () => {
            addToCart(p.id);
        });

        grid.appendChild(node);
    });
}

// ---------- Cart Functions ----------
function addToCart(id) {
    const cart = getCart();
    cart[id] = (cart[id] || 0) + 1;
    setCart(cart);
    alert('Added to cart');
}

// Cart page rendering
function renderCartPage() {
    const container = document.getElementById('cartContent');
    if (!container) return;
    const cart = getCart();
    if (Object.keys(cart).length === 0) {
        container.innerHTML = '<p>Your cart is empty.</p>';
        return;
    }
    let html = '<table><tr><th>Product</th><th>Qty</th><th>Price</th></tr>';
    Object.keys(cart).forEach(id => {
        // Use fetch_products.php or local PRODUCTS array
        const p = PRODUCTS ? PRODUCTS.find(x => x.id == id) : { name: 'Product ' + id, price: 0 };
        html += `<tr><td>${p.name}</td><td>${cart[id]}</td><td>${formatPrice(p.price * cart[id])}</td></tr>`;
    });
    html += '</table>';
    container.innerHTML = html;
}

// Checkout function
function checkout() {
    const cart = getCart();
    if (Object.keys(cart).length === 0) { alert('Cart is empty'); return; }
    if (!confirm('Proceed with Cash on Delivery?')) return;

    fetch('checkout.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(cart)
    })
    .then(res => res.text())
    .then(msg => {
        alert(msg);
        localStorage.removeItem('waggy_cart');
        renderCartPage();
        updateCartCount();
    });
}

// ---------- Category Filters ----------
const chips = Array.from(document.querySelectorAll('.chip'));
chips.forEach(c => c.addEventListener('click', e => {
    chips.forEach(x => x.classList.remove('active'));
    e.target.classList.add('active');
    const cat = e.target.dataset.cat;
    const searchInput = document.getElementById('search');
    renderProducts(cat, searchInput ? searchInput.value.trim() : '');
}));

// ---------- Search ----------
const searchInput = document.getElementById('search');
if (searchInput) {
    searchInput.addEventListener('input', () => {
        const active = document.querySelector('.chip.active').dataset.cat;
        renderProducts(active, searchInput.value.trim());
    });
}

// ---------- View All ----------
const viewAllBtn = document.getElementById('viewAllBtn');
if (viewAllBtn) {
    viewAllBtn.addEventListener('click', () => {
        renderProducts('all', '');
        if (searchInput) searchInput.value = '';
        chips.forEach(x => x.classList.remove('active'));
        chips[0].classList.add('active');
    });
}

// ---------- Cart Button ----------
const cartBtn = document.getElementById('cartBtn');
if (cartBtn) {
    cartBtn.addEventListener('click', () => {
        renderCartPage();
        alert('Check your cart page for items.');
    });
}

// ---------- Initial Render ----------
document.addEventListener('DOMContentLoaded', () => {
    renderProducts();
    renderCartPage();
    updateCartCount();
});