-- pet_store.sql
-- Database: pet_store

-- Create database
CREATE DATABASE IF NOT EXISTS pet_store;
USE pet_store;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    is_admin TINYINT(1) DEFAULT 0
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    description TEXT,
    image VARCHAR(255)
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Admin table
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL
);

-- Insert demo products
INSERT INTO products (name, category, price, description, image) VALUES
('Premium Dry Dog Food - 5kg','food',1999,'Complete nutrition for adult dogs.','https://picsum.photos/id/1025/600/400'),
('Chicken Wet Food - 400g','food',149,'Tasty wet food for small dogs and cats.','https://picsum.photos/id/1020/600/400'),
('Plush Squeaky Toy','toys',249,'Soft toy with built-in squeaker.','https://picsum.photos/id/237/600/400'),
('Rubber Chew Bone','toys',199,'Durable chew toy for teething pups.','https://picsum.photos/id/1080/600/400'),
('Adjustable Nylon Collar','accessories',349,'Comfortable collar with quick-release.','https://picsum.photos/id/1011/600/400'),
('Foldable Travel Bowl','accessories',299,'Silicone bowl for feeding on-the-go.','https://picsum.photos/id/1005/600/400'),
('Cat Grass Kit','accessories',179,'Grow fresh grass for indoor cats.','https://picsum.photos/id/1062/600/400'),
('Interactive Laser Toy','toys',399,'Keeps cats active with random movements.','https://picsum.photos/id/1060/600/400');

-- Insert admin user
INSERT INTO users (username, password, is_admin) VALUES 
('admin', '$2y$10$e0NRk4RIz5l5H45Ro4NjuuXgL7rBqJr1vB8bzf7iPz1Pm5jHn2yPi', 1);
-- password is: admin123

INSERT INTO admin (id, username, password, email) VALUES
(1, 'Gaurang', 'Gaurang', 'gaurang@gmail.com') ;