<?php
session_start();
include 'db.php';

// check if admin logged in
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// fetch products
$result = mysqli_query($conn, "SELECT * FROM products ORDER BY id DESC");
?>
<!doctype html>
<html>
<head>
    <title>Admin Dashboard - Pet Store</title>
    <link rel="stylesheet" href="styles.css">
    <style>
        body { font-family: Arial, sans-serif; margin:20px; background:#f5f7fb; }
        h1 { text-align:center; color:#2b8aef; }
        .top-bar { text-align:center; margin:20px; }
        .btn {
            background:#2b8aef; color:#fff; padding:8px 16px;
            text-decoration:none; border-radius:6px; margin:5px; display:inline-block;
        }
        .btn:hover { background:#1a6ed8; }
        table {
            width:100%; border-collapse:collapse; background:#fff; border-radius:8px;
            box-shadow:0 2px 8px rgba(0,0,0,0.1); overflow:hidden;
        }
        table th, table td {
            padding:12px; border-bottom:1px solid #ddd; text-align:center;
        }
        table th { background:#2b8aef; color:#fff; }
        img { max-width:60px; border-radius:6px; }
        .msg { text-align:center; margin:10px; color:green; }
    </style>
</head>
<body>
    <h1>Admin Dashboard</h1>
    <div class="top-bar">
        <a href="add_product.php" class="btn">➕ Add Product</a>
        <a href="logout.php" class="btn" style="background:#e74c3c;">🚪 Logout</a>
    </div>

    <?php if (isset($_GET['msg'])): ?>
        <p class="msg"><?php echo htmlspecialchars($_GET['msg']); ?></p>
    <?php endif; ?>

    <table>
        <tr>
            <th>ID</th><th>Image</th><th>Name</th><th>Description</th>
            <th>Price</th><th>Category</th><th>Actions</th>
        </tr>
        <?php while($row = mysqli_fetch_assoc($result)): ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td>
                <?php if ($row['image']): ?>
                    <img src="<?php echo $row['image']; ?>" alt="">
                <?php else: ?>
                    No Image
                <?php endif; ?>
            </td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo htmlspecialchars($row['description']); ?></td>
            <td>$<?php echo number_format($row['price'],2); ?></td>
            <td><?php echo htmlspecialchars($row['category']); ?></td>
            <td>
                <a href="edit_product.php?id=<?php echo $row['id']; ?>" class="btn">✏️ Edit</a>
                <a href="delete_product.php?id=<?php echo $row['id']; ?>" class="btn" style="background:#e74c3c;" onclick="return confirm('Delete this product?')">🗑️ Delete</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</body>
</html>