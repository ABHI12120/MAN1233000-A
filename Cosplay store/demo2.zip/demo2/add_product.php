<?php
session_start();
include 'db.php';

// Only admin should access this page
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

$msg = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $desc = mysqli_real_escape_string($conn, $_POST['description']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $category = mysqli_real_escape_string($conn, $_POST['category']);
    
    // File upload
    $image = "";
    if (isset($_FILES['image']) && $_FILES['image']['error'] == 0) {
        $target = "images/" . basename($_FILES["image"]["name"]);
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target)) {
            $image = $target;
        }
    }

    $sql = "INSERT INTO products (name, description, price, image, category) 
            VALUES ('$name','$desc','$price','$image','$category')";
    if (mysqli_query($conn, $sql)) {
        $msg = "Product added successfully!";
    } else {
        $msg = "Error: " . mysqli_error($conn);
    }
}
?>
<!doctype html>
<html>
<head>
    <title>Add Product</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
<!--<h2>Add Product</h2>-->
<p style="color:green;"><?php echo $msg; ?></p>
<form method="post" enctype="multipart/form-data">
<h2>Add Product</h2>
    <input type="text" name="name" placeholder="Product Name" required><br>
    <textarea name="description" placeholder="Description"></textarea><br>
    <input type="number" step="0.01" name="price" placeholder="Price" required><br>
    <input type="text" name="category" placeholder="Category" required><br>
    <input type="file" name="image" accept="image/*"><br>
    <button type="submit">Add Product</button>
</form>
</body>
</html>