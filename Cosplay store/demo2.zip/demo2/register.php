<?php
session_start();
include 'db.php';
$msg = '';
if($_SERVER['REQUEST_METHOD']=='POST'){
    $name = mysqli_real_escape_string($conn,$_POST['name']);
    $email = $_POST['email'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $res = mysqli_query($conn,"INSERT INTO users (username,email,password) VALUES ('$name','$email','$pass')");
    if($res){ $msg="Registration successful! <a href='login.php'>Login here</a>"; }
    else{ $msg="Error: ".mysqli_error($conn); }
}
?>
<!doctype html>
<html>
<head>
<title>Register - Cosplay Coustmes store</title>
<link rel="stylesheet" href="styles.css">
	<style>
		.in-box {
            max-width: 400px;
            margin: 80px auto;
            padding: 20px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }
        .in-box h2 {
            margin-bottom: 20px;
        }
        .in-box input {
            width: 90%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        .in-box button {
            width: 95%;
            padding: 10px;
            background: #2b8aef;
            color: #fff;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }
        .in-box button:hover {
            background: #1a6ed8;
            }
		</style>
</head>
<body>
<div class="in-box">
<h1>Register</h1>
<?php if($msg) echo "<p style='color:green;'>$msg</p>"; ?>
<form method="post">
<input type="text" name="name" placeholder="username" required><br>
	<input type="email" name="email" placeholder="email" required><br>
<input type="password" name="password" placeholder="password" required><br>
<button type="submit" class="btn">Register</button>
</form>
<p>Already have an account? <a href="login.php">Login here</a></p>
</div>
</body>
</html>