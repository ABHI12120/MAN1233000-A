document.querySelector("form").addEventListener("submit", function(e) {
    const terms = document.getElementById("terms");
    const container = document.querySelector(".custom-checkbox"); // ✅ updated selector
    
    if (!terms.checked) {
        e.preventDefault(); // Prevent form submission
        container.style.border = "1px solid"; // Highlight container
        container.style.padding = "8px";
        // Keep box visible
        container.style.width = "95%";
        alert("You must agree to the Terms and Conditions.");
    } else {
        container.style.border = "none"; // Remove highlight if checked
        container.style.padding = "0";   // Reset padding
    }
});

document.addEventListener("DOMContentLoaded", () => {
  const cartLink = document.querySelector("a[href='cart.php']");

  document.querySelectorAll(".add-to-cart").forEach(button => {
    button.addEventListener("click", () => {
      const productId = button.getAttribute("data-id");

      fetch("add_to_cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "product_id=" + encodeURIComponent(productId)
      })
      .then(res => res.text())
      .then(cartCount => {
        cartLink.textContent = `Cart (${cartCount})`; // update cart number in header
      })
      .catch(err => console.error("Error:", err));
    });
  });
});

document.addEventListener("DOMContentLoaded", () => {
  const cartLink = document.querySelector("a[href='cart.php']");

  // Update quantity in cart
  document.querySelectorAll(".qty-input").forEach(input => {
    input.addEventListener("change", () => {
      const productId = input.dataset.id;
      const quantity = input.value;

      fetch("cart.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "product_id=" + encodeURIComponent(productId) + "&quantity=" + encodeURIComponent(quantity)
      })
      .then(res => res.text())
      .then(cartCount => {
        if (cartLink) {
          cartLink.textContent = `Cart (${cartCount})`;
        }
      })
      .catch(err => console.error("Error:", err));
    });
  });
});