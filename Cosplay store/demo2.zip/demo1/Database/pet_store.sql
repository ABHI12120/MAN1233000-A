-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 10, 2025 at 06:55 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'Gaurang', 'Gaurang', 'gaurang@gmail.com'),
(2, 'admin', '$2y$10$x/6UwNWXuY30nkhjp8WCeO5jgisGQwKKCsC7rvGRzP1cBRNit5C5K', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 'Gaurangk', 'gaurangk@gmail.com', 'Dhhendndbnd', '2025-09-09 10:52:45');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `status`, `created_at`) VALUES
(1, 1, 8, 1, 'pending', '2025-08-28 17:18:56');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `description`, `image`) VALUES
(1, 'Itachi Uchiha Costume', 'anime', 1599.00, 'High-quality Akatsuki cloak with red cloud design. Perfect for Naruto fans.', 'images/Itachi_chiha.jpeg'),
(2, 'Jacob Frye Cosplay', 'games', 2499.00, 'Authentic Victorian-era styled coat, vest, and accessories inspired by Assassin\'s Creed Syndicate.', 'images/jacobfrye.jpeg'),
(3, 'Luffy Cosplay Outfit', 'anime', 1399.00, 'One Piece Monkey D. Luffy red vest, shorts, and straw hat costume.', 'images/LuffyCosplay.jpeg'),
(4, 'Smoke Cosplay', 'games', 1899.00, 'Inspired by Mortal Kombat character Smoke, includes ninja suit and mask.', 'images/smoke.jpeg'),
(5, 'Red Ranger Costume', 'movies', 2199.00, 'Classic Power Rangers red ranger jumpsuit with helmet.', 'images/red_ranger.jpeg'),
(6, 'Homelander Cosplay', 'movies', 2999.00, 'The Boys inspired Homelander costume with cape and muscle suit.', 'images/homelander.jpeg'),
(7, 'Blue Ranger Costume', 'movies', 2199.00, 'Power Rangers Blue Ranger jumpsuit with helmet.', 'images/blue_ranger.jpeg'),
(8, 'Spider-Man Suit', 'movies', 2799.00, 'Full-body Spider-Man costume made from stretchable fabric.', 'images/spiderman.jpeg'),
(9, 'Wolverine Cosplay', 'movies', 2599.00, 'Leather jacket and claw set inspired by X-Men Wolverine.', 'images/wolverine.jpeg'),
(10, 'Zenitsu Agatsuma Costume', 'anime', 1699.00, 'Demon Slayer Zenitsu cosplay with detailed kimono and accessories.', 'images/zenitsu.jpeg'),
(11, 'Tanjiro Kamado Costume', 'anime', 1799.00, 'Demon Slayer Tanjiro cosplay with signature checkered haori and sword.', 'images/tanjiro.jpeg'),
(12, 'Batman Costume', 'movies', 3199.00, 'Dark Knight inspired full suit with mask and cape.', 'images/batman.jpeg'),
(13, 'Geo Cosplay', 'games', 1999.00, 'Inspired by Genshin Impact Geo traveler costume.', 'images/geo.jpeg'),
(14, 'Captain America Suit', 'movies', 2899.00, 'Marvel Captain America full costume with shield.', 'images/captain_america.jpeg'),
(15, 'Satoru Gojo Costume', 'anime', 1899.00, 'Jujutsu Kaisen Gojo cosplay with blindfold and black uniform.', 'images/SatoruGojo.jpeg'),
(16, 'Green Ranger Costume', 'movies', 2299.00, 'Classic Power Rangers Green Ranger suit with helmet.', 'images/green_ranger.jpeg'),
(17, 'Obanai Iguro Costume', 'anime', 1799.00, 'Demon Slayer Obanai cosplay with striped haori and snake accessory.', 'images/obenai_iguro.jpeg'),
(18, 'Deadpool Suit', 'movies', 2999.00, 'High-quality Deadpool full-body costume with belt and accessories.', 'images/deadpool.jpeg'),
(19, 'God of War Kratos Cosplay', 'games', 3299.00, 'Detailed Kratos costume with armor pieces and body paint.', 'images/god_of_war.jpeg');
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `address`, `state`, `pincode`) VALUES
(1, 'Gaurangk', 'gaurangk@gmail.com', '$2y$10$sOLx7Eu2ACERvYRY3ZBS7uSbV0lRre0SzC9sNDf1Wo8lOEPvLJDNG', '', '', '', ''),
(2, 'Gaurang', 'gaurangh@gmail.com', '$2y$10$Hi3sC/wlAqzK3xFxwrkupeH8R5j0F7Vd37VlffDNgeQDgjxdMt1DS', '7878787878', '21 jump street, new York', 'New york', '11354');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
