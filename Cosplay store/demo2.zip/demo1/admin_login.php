<?php
session_start();
include 'db.php';

if (isset($_SESSION['admin'])) {
    header("Location: admin_dashboard.php");
    exit();
}

$msg = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $res = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username' LIMIT 1");
    if (mysqli_num_rows($res) > 0) {
        $row = mysqli_fetch_assoc($res);
        
        if (password_verify ($password, $row['password'])) {
            $_SESSION['admin'] = $row['id'];   // store admin id in session
            header("Location: admin_dashboard.php");
            exit();
        } else {
            $msg = "Invalid password!";
        }
    } else {
        $msg = "Admin not found!";
    }
}
?>
<!doctype html>
<html>
<head>
    <title>Admin Login - Pet Store</title>
    <link rel="stylesheet" href="styles/styles.css">
    <style>
        body { background:#f5f7fb; font-family: Arial, sans-serif; }
        .in-box {
            max-width: 400px; margin: 80px auto; padding: 20px;
            background: #fff; border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1); text-align: center;
        }
        .in-box h2 { margin-bottom: 20px; color:#2b8aef; }
        .in-box input {
            width: 90%; padding: 10px; margin: 10px 0;
            border: 1px solid #ccc; border-radius: 8px;
        }
        .in-box button {
            width: 95%; padding: 10px; background: #2b8aef;
            color: #fff; border: none; border-radius: 8px;
            cursor: pointer; margin-top:10px;
        }
        .in-box button:hover { background:#1a6ed8; }
        .error { color:red; margin:10px; }
    </style>
</head>
<body>
    <div class="in-box">
        <h2>Admin Login</h2>
        <?php if($msg): ?>
            <p class="error"><?php echo $msg; ?></p>
        <?php endif; ?>
        <form method="post">
            <input type="text" name="username" placeholder="Admin Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Login</button>
        </form>
        <p><a href="admin_register.php">Register here</a> or</p> 
        <p><a href="index.php">← Back to Store</a></p>
    </div>
</body>
</html>