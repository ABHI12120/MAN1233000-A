<?php
session_start();
include 'db.php';
 
$msg = "";

// If already logged in, redirect to home
if(isset($_SESSION['user_id'])){
    header("Location: index.php");
    exit;
}

// Handle login
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $user = $_POST['username'];
    $password = $_POST['password'];

    $res = mysqli_query($conn, "SELECT * FROM users WHERE username='$user' LIMIT 1");
    if($res && mysqli_num_rows($res) > 0){
        $row = mysqli_fetch_assoc($res);

        
        if(password_verify($password, $row['password'])){
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['user_name'] = $row['username']; // use correct column name

            // Redirect back if redirect param exists
            if(isset($_GET['redirect']) && !empty($_GET['redirect'])){
                header("Location: " . $_GET['redirect']);
            } else {
                header("Location: index.php");
            }
            exit;
        } else {
            $msg = "Invalid password!";
        }
    } else {
        $msg = "User not found!";
    }
}
?>
<!doctype html>
<html>
<head>
    <title>Login - Pet Products Store</title>
    <link rel="stylesheet" href="styles/styles.css">

</head>
<body>
<div class="in-box">
    <h2>User Login</h2>

    <?php if(isset($_GET['redirect'])): ?>
        <p class="redirect-msg">Please log in to continue to checkout.</p>
    <?php endif; ?>

    <?php if($msg): ?>
        <p class="error"><?php echo $msg; ?></p>
    <?php endif; ?>

    <form method="post">
    	<label>Name:</label><br>
        <input type="text" name="username" placeholder="username"><br>
        <label>Password:</label><br>	
        <input type="password" name="password" placeholder="Password" required><br>
        <button type="submit">Login</button>
    </form>
    <p>Don't have an account? <a href="register.php">Register</a></p>
    <p><a href="index.php">← Back to Store</a></p>
</div>
</body>
</html>