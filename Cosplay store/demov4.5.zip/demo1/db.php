<?php
$host = 'localhost';
$db   = 'pet_store';
$user = 'root';
$pass = ''; // your MySQL password
$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) die("Database connection failed: ".mysqli_connect_error());
?>