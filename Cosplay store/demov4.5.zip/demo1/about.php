<?php
session_start();
?>
<!doctype html>
<html>
<head>
<title>About Us - Pet Products Store</title>
<link rel="stylesheet" href="styles/styles.css">
</style>
</head>
<body>
	<header>
  <div class="container top">
    <div class="brand">
      <div class="logo"><a href="index.php">PS</a></div>
      <div>
        <div style="font-weight:700">Pet Products Store</div>
      </div>
    </div>

    <nav class="navbar">
      <ul>
        <li><a href="login.php">Login</a></li>
        <li><a href="logout.php">Logout</a></li>
        <li><a href="cart.php">Cart (<?php echo isset($_SESSION['cart']) ? array_sum($_SESSION['cart']) : 0; ?>)</a></li>
      </ul>
    </nav>
  </div>
</header>
  <div class="content">
    <h1>About Us</h1>

    <p>Welcome to <strong>Pet Products Store</strong>! We are passionate about pets and dedicated to providing the best products for your furry friends. From nutritious food to fun toys, our store is a one-stop destination for all pet needs.</p>

    <div class="highlight">
      <h2>Our Mission</h2>
      <p>To ensure every pet has access to high-quality products that promote health, happiness, and well-being. We aim to make pet care easy and enjoyable for pet owners everywhere.</p>
    </div>

    <div class="highlight">
      <h2>Our Vision</h2>
      <p>To become the most trusted and convenient pet products store, fostering strong relationships with our customers and their beloved pets.</p>
    </div>

    <div class="highlight">
      <h2>Why Choose Us?</h2>
      <ul>
        <li>Wide variety of products for dogs, cats, birds, and more.</li>
        <li>High-quality, trusted brands.</li>
        <li>Fast and reliable service.</li>
        <li>Customer satisfaction is our priority.</li>
      </ul>
    </div>
  </div>
<footer>
<p>© Pet Products Store | <a href="index.php">Home</a> | <a href="about.php">About</a> | <a href="contact.php">Contact</a></p>
</footer>
</body>
</html>