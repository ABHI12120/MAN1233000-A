-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Sep 10, 2025 at 06:55 AM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pet_store`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `email`) VALUES
(1, 'Gaurang', 'Gaurang', 'gaurang@gmail.com'),
(2, 'admin', '$2y$10$x/6UwNWXuY30nkhjp8WCeO5jgisGQwKKCsC7rvGRzP1cBRNit5C5K', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
CREATE TABLE IF NOT EXISTS `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`, `created_at`) VALUES
(1, 'Gaurangk', 'gaurangk@gmail.com', 'Dhhendndbnd', '2025-09-09 10:52:45');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `product_id` (`product_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `product_id`, `quantity`, `status`, `created_at`) VALUES
(1, 1, 8, 1, 'pending', '2025-08-28 17:18:56');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `description` text,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `category`, `price`, `description`, `image`) VALUES
(1, ' Adult Dog Food - 10kg', 'food', 1090.00, 'A balanced Adult Dog Food maintains an ideal weight of your pet keeping them active and agile.', 'images/dog_food.jpeg'),
(2, 'Cat Food Bowl', 'accessories', 229.00, 'A Double Bowl Water and Food Cat Feeder Detachable Stainless Steel Bowl and Automatic Water Dispenser Bottle for Kitten, Puppies and Small Cat Dog Set of 1', 'images/cat_food_bowl.jpg'),
(3, 'Sandwich Plush Toy', 'toys', 249.00, 'This is a Sandwich dog Toy that your puppy could also enjoy with treats. Made of soft and high-quality material, your furry friend will be entertained during the playtime.', 'images/sandwich_plush_toy.jpeg'),
(4, 'Rubber Chew Bone', 'toys', 199.00, 'Durable chew toy for teething pups.', 'images/bone_chew.jpeg'),
(5, 'Depets Self Cleaning Slicker Brush', 'accessories', 159.00, 'Clean Pets, Clean House. emily cat & dog brush for shedding can easily remove loose hair, shedding mats, tangled hair, dander and dirt of your lovely pet', 'images/deep_self_cleaning_brush.jpeg'),
(6, 'Shower Sprayer and Scrubber', 'accessories', 378.00, 'The innovative design of the glove helps to clean up the dirt of your pets easily and effectively in the bath.', 'images/shower_sprayer.jpeg'),
(7, 'Cat Grass Kit', 'accessories', 316.00, 'Grow fresh grass for indoor cats.', 'images/cat_grass_kit.jpeg'),
(8, 'Interactive Laser Toy', 'toys', 399.00, 'Keeps cats active with random movements.', 'images/laser_toy.jpeg'),
(9, 'Bone chew', 'toys', 299.00, 'This sky blue swan plush toy features a built-in squeaker that grabs your dog\'s attention and keeps them engaged', 'images/blue_swan_dog_toy.jpeg'),
(12, 'Dry Cat food - 5kg', 'food', 984.00, 'Whiskas Dry Cat Food provides complete & balanced nutrition. cat food - 5kg', 'images/dry_cat_food.jpeg'),
(13, 'Chew Ball Toy', 'toys', 199.00, 'Durable Ball toy for the Dogs', 'images/chew_ball_toy.jpeg'),
(14, 'Kitten Leash', 'accessories', 299.00, 'Strong retractable leash for the cats. ', 'images/leash_for_kittens.jpeg'),
(15, 'Catnip Balls', 'food', 299.00, 'Catnip Balls Catnip Wall Toys for Cats Rotatable Edible Mint Natural Healthy Teeth Cleaning Chew Claw Toy for Cat/Kitten (Green)', 'images/catnip.jpeg'),
(16, 'Adult Cat Food - 1kg', 'food', 189.00, 'Dry Cat Food, Complete and Balanced Diet, Formulated with Finest Natural Ingredients, Vitamins and Minerals', 'images/cat_fish_foodd.jpeg'),
(17, 'Adjustable Dog Collar', 'accessories', 209.00, 'Made from sturdy nylon, designed to withstand the rigors of daily wear, play, and outdoor adventures. ', 'images/dog_collar.jpeg');
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `email` varchar(35) NOT NULL,
  `password` varchar(255) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `state` varchar(50) NOT NULL,
  `pincode` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `phone`, `address`, `state`, `pincode`) VALUES
(1, 'Gaurangk', 'gaurangk@gmail.com', '$2y$10$sOLx7Eu2ACERvYRY3ZBS7uSbV0lRre0SzC9sNDf1Wo8lOEPvLJDNG', '', '', '', ''),
(2, 'Gaurang', 'gaurangh@gmail.com', '$2y$10$Hi3sC/wlAqzK3xFxwrkupeH8R5j0F7Vd37VlffDNgeQDgjxdMt1DS', '7878787878', '21 jump street, new York', 'New york', '11354');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
